# Skin Deep: Enemy Brains

- 分类：感知、注意力与决策上下文。
- 资料标识：`identity-limited-unit:0ed015606c87eb34c24461e913214a7ce2502d17428fa37cf5dc8614e025aafa`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Brendon Chung。
- 原目录日期：2025-07-07（沿用已有记录）。
- 主要来源：[https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/](https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/)

## 概要与项目参考

Domino建议：共享只读扰动定义与有限实例池/局部空间索引分离，个人感知形成观察事件和调查任务，世界扰动存在不等于全人口知道。
事件合并、注意切换门槛和有界寿命能降低重复唤醒；优先级结合个人需求、承诺与风险，不能每次微小扰动无条件取消当前任务。
共享调查活动只协调角色与目标，每人仍有意愿/任务与可中断进度；主调查者取消/离场需释放角色，由本地活动版本重新选人。

## 已有机制分析

Interest Point把可察觉扰动作为有位置/类型/寿命的实例：茶壶落地生1秒noise并附永久visual；臭味每1秒在玩家当前位置生8秒点，局部感知后调查，自然形成沿迹追踪。
多人察觉同点时最近者为Investigator接近，其他人Overwatch接近至首次获得该点视线即停，避免全体堆在一点；Ownership避免同点被多次重复调查。
DuplicateRadius让附近重复点不重复抢注意，1秒switch cooldown限制频繁切换，priority 0..10将枪声置于茶壶声之上；文本definition共享noticeRadius、duplicateRadius、lifetime及显示key。
声音与气味共用非视线感知，关闭门会阻声而气味可穿门；视觉从难调cone改带近端斜边rectangle，再补始终前向half-circle，避免NPC抬头就看不见眼前玩家。
非警戒与战斗调整blind spot，警戒后更难逃；IdleTasks给受伤闲置敌人治疗目标，作者回顾认为可与Interest Point整合但承认独立系统的取舍。

## 后续行为与玩法启发

诱饵、声东击西、气味尾迹、销毁物证、潜入、追捕和监视配合有可观察的原因；玩家可关门、制造新声音、改变可见物或清除味源。

犯罪发生、噪声存在、NPC察觉、调查、归因、举报、制度裁决和实际惩罚仍分状态；茶壶声不会自动证明玩家犯罪，调查ownership不应向未观察者广播完整事实。

非警戒宽盲区与警戒缩盲区让玩家选择造成真实警报后果，关系/证词系统可在后续扩展而无需改通用感知实例生命周期。

## 适用范围与局限

每秒臭味点8秒寿命说明此例单源活跃点数可有界，但永久visual点需随实体删除/变化清理；本文未给总敌人数、CPU或10,000人测量。

万人项目按局部区域检索点与邻近观察者，按点合并同类事件，避免全员扫描所有点或全员互配选择Investigator。

最短寿命/集中爆炸仍会产生峰值，合并不得丢掉新高优先或不同因果事件；注意cooldown按现实_ms而非显示日历。

定义中的有限数值参数容易内容制作与调试，统一察觉/响应/终结入口可扩新感官和扰动类型，无需通用DSL。

必须记录同点去重键、注意原因、Owner与角色revision、寿命deadline，以及个人最后观察；存档持久必要证据/调查进度，重建可丢弃感知队列。

作者对IdleTask与Interest Point重复的反思有维护价值，但任务目的与感知证据语义仍需区分，不能因合并代码就混淆事件与意图。

距离最近不一定能到达或愿意调查，楼层/权限/伤势/已承诺任务可能限制；协调须过滤物理能力并保留个人选择。

DuplicateRadius若只按位置消重，会把随后杀人或不同目标的关键证据吞掉，不能简单让第一噪声遮蔽所有后续事实。

一人调查过不等于所有人已知道结果；共享ownership避免动作重复，个人信念必须经实际观察或消息更新。

感知box补half-circle是作者玩法折中，不是生理视觉真实性；远处业务LOD不可凭可见问号补造目击。

不可达Interest Point与永久视觉点若不终结/清理会形成无限追踪和内存积累。

8,417字符文章全文实际显示；首个同range工具output为空未计，随后补读成功，不因receipt自动声明。

未核看图片/视频、审Skin Deep源码或复现游戏；这是作者实现回顾，未提供万人性能和完整任务保存/恢复协议。

两个text alias为同一作品，提名其扰动实例、注意稳定和局部多人调查机制。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [041f77568bc3513d3b60a46f.txt](../texts/21/216e1aa5ea5294aa5d8f641c3861c209e16ddd3463fa58ecdc23ac1e3179d26f.md) | 文章/文档正文 | [0, 8417) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/02-perception-attention.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/02-perception-attention.md)
- [https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/](https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/)
- [https://www.youtube.com/watch?v=RFWrKHM0vAg](https://www.youtube.com/watch?v=RFWrKHM0vAg)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
