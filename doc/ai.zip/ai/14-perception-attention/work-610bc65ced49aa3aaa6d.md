# Unreal Engine 5 AI - Search last Seen Location - Action RPG #70

- 分类：感知、注意力与决策上下文。
- 资料标识：`youtube:vRTpX9dE89c`。
- 已有内容：字幕/转录文本。
- 原目录作者：Thilina Premasiri / CodeLikeMe。
- 原目录日期：2024-07-12（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=vRTpX9dE89c](https://www.youtube.com/watch?v=vRTpX9dE89c)

## 概要与项目参考

Domino追踪只依最后观察地点，失去目标不继续使用全知当前位置；调查阶段的到期只结束搜索并选择恢复任务，不宣称抓获成功。
失效线索消费后清理及失焦释放可借鉴，但项目应保留原日常任务的挂起/进度，再恢复该任务而不是一律回初始点。
给线索附人物ID/观察时刻/修订号，旧搜索终止只清其消费的版本，避免较新目击被旧等待覆盖；这是项目建议。

## 已有机制分析

失去视觉目标的perception更新false分支把stimulus location写入last-seen vector；行为树在该key已设置时MoveTo最后目击点、等待约5秒、清key，然后无noise/last-seen候选时收剑回初始位置。
noise location也在访问后等待并清除，避免同节点反复执行；单独Blueprint clear Blackboard task负责清选定key并finish execute。
回归时发现仍锁目标导致朝向错误，增加lock-off接口、清lock target及相关ability状态，再finish task；行动与表现残留必须一起释放。

## 后续行为与玩法启发

玩家躲藏/制造声响/改变路线让NPC根据最后看到或听到的位置搜索，失败后继续日常，存在可观察的骗过守卫因果。

多个证人/嫌犯需独立目标ID、时间、来源和可信度，传言线索不能直接成为真实坐标。

玩家躲藏、发噪音引开守卫、改变追捕路线具有清楚因果；搜索到场仍需重新感知/验证才能定位盗贼。

该教程未实现报警传播、多目标证人或法律归因；不能将被视觉看到等同确认犯罪。

## 适用范围与局限

每人保留少量目标记录并由感知事件/到期唤醒；只有相关局部场景精细搜索，不能全员全目标扫描。

视频只单target、少量角色，无10000性能、并发感知或多人证明；感知成本另需评估。

作者[3:09]明确仅一个目标，未考虑多人/多敌，末尾未来才讨论multiplayer；没有万人规模或tick预算。

每NPC有界最近线索与事件唤醒可降低成本；万人全员BT每帧perception/MoveTo仍需额外预算，字幕未解释。

可用C任务模板+类型ops实现 move/wait/search-result/cleanup，无需UE Blackboard/BT/GAS。

搜索wait使用Domino累计现实ms；与挂起恢复、取消确认、占用释放、效果提交分层。

通用clear-key/lock-off任务减少重复Blueprint，可对应C生命周期release；领域的搜索地点/超时由类型参数。

last-seen与noise优先级、多目标选择、任务取消、重入/加载未给合同，不能把5秒固定Wait节点扩成完整持久执行器。

作者明确仅一个player/enemy，多目标共用一key会覆写线索或追错目标。

无条件clear会删掉等待期间的新观察；到点等待到期不等于调查成功。

返回固定spawn地点不能处理原工作任务、合同或部分收益恢复；教程只处理朝向lock cleanup。

搜索期间新目击到达，旧等待结束无版本清key可能丢新线索；需要区分更新及完成所属实例。

一直回初始点会破坏NPC日常任务与工作进度；未到达/路径失败也不能把Wait到期当搜索成功。

清blackboard没有清目标锁/ability，作者现场出现朝向残留，说明只换树分支不等于停止确认。

完整读本地自动字幕0:00–12:24；未观看实际演示、查看Blueprint源码或取得Patreon项目。

不要把教程测试描述当本轮运行证明；多人/多目标为作者未来工作。

7373字符字幕[0:00–12:24]完整读取；未核Blueprint画面、原项目或运行演示。

lookup错误混入madzqBGs7nw/Alert Nearby Enemies，按本载体header与内容仅关联vRTpX9dE89c；不继承另片机制。

作为最后目击点小模式有效但范围窄，低于更全面感知/知识/执行材料，不单独前100提名。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [browser-export.txt](../texts/7d/7d6d1976854203e9a19d29facf1718e6b8942b2e6ea25d3e8ef70fb3e04fba75.md) | 字幕/转录文本 | [0, 7373) |
| [transcript.txt](../texts/e6/e6ac619fa6622ccdddbb2d61ba3e882bdd2383d861214b3dfa307da5002dae93.md) | 字幕/转录文本 | [0, 7294) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/03-beliefs-information.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/03-beliefs-information.md)
- [https://forums.unrealengine.com/t/how-do-i-get-ai-to-look-for-me-at-last-known-posistion/311965/7](https://forums.unrealengine.com/t/how-do-i-get-ai-to-look-for-me-at-last-known-posistion/311965/7)
- [https://www.patreon.com/posts/unreal-engine-ai-62366571](https://www.patreon.com/posts/unreal-engine-ai-62366571)
- [https://www.reddit.com/r/u_codelikeme/comments/soz7ok/](https://www.reddit.com/r/u_codelikeme/comments/soz7ok/)
- [https://www.youtube.com/watch?v=madzqBGs7nw](https://www.youtube.com/watch?v=madzqBGs7nw)
- [https://www.youtube.com/watch?v=vRTpX9dE89c](https://www.youtube.com/watch?v=vRTpX9dE89c)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
