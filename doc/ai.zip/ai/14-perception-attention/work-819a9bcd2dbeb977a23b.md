# Modeling AI Perception and Awareness in Splinter Cell: Blacklist — Martin Walsh

- 分类：感知、注意力与决策上下文。
- 资料标识：`youtube:RFWrKHM0vAg`。
- 已有内容：字幕/转录文本。
- 原目录作者：Martin Walsh。
- 原目录日期：2018-02-08（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=RFWrKHM0vAg](https://www.youtube.com/watch?v=RFWrKHM0vAg)

## 概要与项目参考

Very strong crime, stealth, witness knowledge, local spatial structure and cooperative interruption reference. Supplies clear causal mechanisms missing from current WITNESS role and contact arrays.

## 已有机制分析



















## 后续行为与玩法启发

盗窃制造噪音、故意开门诱导调查、破坏灯光、欺骗喊话、打断伙伴对话及躲上不可达屋顶，形成玩家可干预的侦测→调查→告警→搜索链。

保存目击与传言差别；玩家可在告警传播前制止/误导报告，后续调查/惩罚仍须独立执行；被发现不是失败重置。

Door/light manipulation creates investigable traces; players can lure attention, interrupt conversations, isolate a witness or stop communication before others learn.

The same non-walkable portal can transmit noise while preventing pursuit, enabling barricades, roofs, ambushes and coordinated containment.

Search after combat retains knowledge that a threat existed; a vanished suspect is different from nobody ever being present.

Barks and group discussions let players infer which cue exposed them and interfere before detection/report/investigation completes.

## 适用范围与局限

讲者由旧4个active NPC扩至12个，并非万人证据；8-bone one-per-frame循环已体现分摊，不能给每万NPC对万目标照搬raycast。

Domino建议：地域订阅和短寿命stimulus、局部多级筛选、稀疏伙伴关系、阈值唤醒；共享门户图/缓存须随门和封锁版本失效。

一名changed actor事件claim可减少重复调查，但世界事实/其他目击证据不可被claim删除；密集门/噪声暴发要合并通知和限预算。

The speaker contrasts four active NPCs in older games with twelve in this implementation; no evidence for 10,000 agents.

Eight-bone raycasts are distributed over frames per target, but all-NPC/all-target selection cost is not stated; Domino needs bounded local candidates and active-scene budgets.

Shared lifetime events and a claimed investigator limit redundant reaction work; broad graph audio routing and director scans still require measured bounds.

复杂shape×姿态×难度×archetype参数调试经历大量playtest；明确源图形、阈值和原因比不断加特例更可维护。

分层bark减少重复同时反馈原因，Domino可用有界解释码与玩法提示；组协议明确离开/返回和伙伴超时。

TEAS自动生成仍允许编辑，音频数据与关卡不同步曾导致false positive，区域连接应有统一来源与校验。

The speaker describes extensive tuning per stance/archetype/difficulty and repeated playtests, plus a large dialogue matrix; content cost is material.

Simpler changed-actor events reportedly produced noticeable value while a large spatial model received little explicit review attention; adopt mechanisms according to marginal usefulness.

Separate local domain facts and shared group activity from a central executor; avoid importing every special cover, flashlight or off-screen case into generic business lifecycle.

源游戏对offscreen且足够远者部分事件hearing减半以改善体验，这是玩家视点规则；不能作为Domino持久世界真实观察/法律证据悄悄切换。

flashlight特例覆盖掩体忽略代码是作者承认的补丁，不应推广为通用真实性模型。

环境噪声相对听觉没有通用实现，Q&A明确只局部special stuff；不能补称噪声遮蔽系统。

战斗告警传播只使他人进入combat，不证明收到精确玩家位置；不能用组合作战当永久共享全世界知识。

The transcript explicitly reports an exception added atop a cover exception for flashlight plausibility; accumulated special cases can make observations inconsistent.

A group automatically knowing other members is fine for this authored conversation model but does not establish how a free NPC learns arbitrary distant facts.

Straight-line audio distance can cross walls incorrectly; a movement-only path misses sound paths between inaccessible balconies.

Off-screen hearing reduction would make saved witness history depend on camera placement if copied uncritically.

Ambient noise masking was considered but not generally implemented; transcript says only a few engineering special cases.

40850字符4窗口，完整本地字幕到31:35致谢；未观看演示片段/图形，自动转写TEAS为t’s等误词。

source-map另关联Skin Deep: Enemy Brains及BlendoURL是污染，本字幕不救该作品/不计第二作品。

没有万人性能、犯罪取证/法律裁决、取消存档或分摊raycast一致性实现。

Complete 0:02–31:35 auto-generated transcript carrier read; no full video viewing, slide/image inspection or source implementation audit.

Auto-caption terminology is imperfect (e.g. TEAS-like name); only mechanism descriptions supported by readable surrounding language are retained.

The exact-path lookup also listed Skin Deep: Enemy Brains and its URL, but this carrier explicitly identifies only RFWrKHM0vAg/Splinter Cell. Those unrelated lookup identities are excluded from source evidence.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [transcript.txt](../texts/c0/c0887fa6436a3d42a648d6fa6a49f04fadd62d0d39aa2268e554479b73f53b50.md) | 字幕/转录文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 40850) |
| [browser-export.txt](../texts/c1/c131214aa92100b0a6aa6a7a46175f356d53f1f6f22d24dfdd0f93ec68364c5f.md) | 字幕/转录文本 | [0, 11000)、[11000, 22000)、[22000, 33000)、[33000, 40929) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/02-perception-attention.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/02-perception-attention.md)
- [https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf](https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf)
- [https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/](https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/)
- [https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter28_Modeling_Perception_and_Awareness_in_Tom_Clancy%27s_Splinter_Cell_Blacklist.pdf](https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter28_Modeling_Perception_and_Awareness_in_Tom_Clancy%27s_Splinter_Cell_Blacklist.pdf)
- [https://www.gdcvault.com/play/1021236/Modeling-AI-Perception-and-Awareness](https://www.gdcvault.com/play/1021236/Modeling-AI-Perception-and-Awareness)
- [https://www.youtube.com/watch?v=RFWrKHM0vAg](https://www.youtube.com/watch?v=RFWrKHM0vAg)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
