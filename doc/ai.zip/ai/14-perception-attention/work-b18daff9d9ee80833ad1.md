# Modeling AI Perception and Awareness in Splinter Cell Blacklist — Martin Walsh

- 分类：感知、注意力与决策上下文。
- 资料标识：`identity-limited-unit:69ae78aba9a8a8fa65c8e49ce2f2a28dbfbe9263ce883edc7e5e0ca3c63c1036`。
- 已有内容：论文/讲义提取文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Martin Walsh。
- 原目录日期：2018-02-08（沿用已有记录）。
- 主要来源：[https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf](https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf)

## 概要与项目参考

Domino 犯罪/潜入可从真实动作事件建立不同感知通道和个人certainty/位置假设，口头/HUD反馈引用真实采样结果；法庭认定仍分开。
环境状态如门/死尸与记忆差异、可达区域连接影响发现和调查候选；必要局部场景可细化建筑区域，常态维持建筑级模拟。
有限事件distance/priority和地域索引先筛听者，视线昂贵检查后置；不采用全知世界事实直接更新所有NPC记忆。

## 已有机制分析

source_fact: 幻灯片把感知分为Visual、Environmental、Auditory、Social/Contextual；目标包括fair、反馈一致和可信智能；反应动画、barks、HUD给出感知反馈。
boundary: 完整2103字符的稀疏讲义提取，缺很多图像/讲述细节。
source_fact: 视线调参经历cover特例、远处过易detect和总体过易；作者列switch to coffin-shaped boxes及继续调整。环境认知包含layout connectivity与门是否留开；声音事件有distance/priority并以TEAS求距离。
boundary: 未给coffin几何/TEAS算法或参数，不能据标题补造实现。
source_fact: 音效难让玩家看见谁听到、也不能直接控制动作声音；解决方案off-screen NPC听力降低，barks逐渐从听见脚步转到有人在附近。
boundary: 作者特定玩法经验，非真实感知或持久世界普遍法则。

## 后续行为与玩法启发

玩家开门、制造声响、隐藏死尸、潜行避开视线或切断区域连接，NPC产生怀疑/搜查/交流而非自动定罪。

同伴谈话与突然消失可触发情境认知；原文标题未定义其归因过程，需另写观察→报告→调查的状态。

调查中的barks可明确只是脚步/大致位置/有人三种知识强度，让玩家能听见风险升级。

## 适用范围与局限

源未给NPC数量/几何cost，TEAS距离和优先级只是架构线索；需要本地发声事件听众索引与节流合并，避免N×events全场扫描。

离屏降低听力是玩家感知公平取舍，不能用于远处未经验证的犯罪事实/资源LOD；同一世界知识规则应可解释。

感知调参nightmare和special case累积是维护反例；使用可视化感知采样、距离曲线与明确原因记录来定位，而非不断加隐藏特例。

世界事实/个人记忆/谈话线索/机构裁决分离；反馈文字不能提升certainty或补造未听见事件。

off-screen听力人为较弱会造成镜头改变NPC知情，适合特定潜行反馈设计而不必适合自主持久世界。

远处detect过强、cover大量例外会让玩家感觉不公平；仅HUD显示不能修复底层不一致。

门没关或同伴消失只表明异常，不证明谁犯罪；直接自动归因会抹掉欺骗/调查玩法。

Entire local extracted lecture text read; many slides appear as headings only, no diagrams/slides images or talk video inspected.

Nomination emphasizes perception/feedback and tuning counterexamples, not a complete stealth awareness algorithm.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [64fd4661d40a1500ca017b21.txt](../texts/80/803530defbd7afded42735c36e82a14018b164f4503af3017c1aa3e3a28343e3.md) | 论文/讲义提取文本 | [0, 2103) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/02-perception-attention.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/02-perception-attention.md)
- [https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf](https://media.gdcvault.com/GDC2014/Presentations/Walsh_Martin_Modeling_AI_Perception.pdf)
- [https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/](https://www.blendogames.com/news/post/2025-07-07-skindeepenemybrains/)
- [https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter28_Modeling_Perception_and_Awareness_in_Tom_Clancy%27s_Splinter_Cell_Blacklist.pdf](https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter28_Modeling_Perception_and_Awareness_in_Tom_Clancy%27s_Splinter_Cell_Blacklist.pdf)
- [https://www.gdcvault.com/play/1021236/Modeling-AI-Perception-and-Awareness](https://www.gdcvault.com/play/1021236/Modeling-AI-Perception-and-Awareness)
- [https://www.youtube.com/watch?v=RFWrKHM0vAg](https://www.youtube.com/watch?v=RFWrKHM0vAg)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
