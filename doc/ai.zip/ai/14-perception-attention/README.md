# 感知、注意力与决策上下文

本类收录 36 条已有资料记录。当前前100中的条目优先列出，随后按题名排列。依据资料题名、来源主题与已有正文机制分析归类；跨领域资料在详情页保留关联链接。

[资料总目录](../README.md)

| 资料与概要 | 已有内容范围 | 当前前100 |
|---|---|---:|
| [Modeling AI Perception and Awareness in Splinter Cell: Blacklist](work-ab1a9517758f0e9c19b5.md) | 论文/讲义提取文本 | 65 |
| [A Generative Model of the Mutual Escalation of Anxiety Between Religious Groups](work-ac9973dfad4a4f5cdd67.md) | 论文/讲义提取文本 |  |
| [AI感知](work-695664a1f7446916efe1.md) | 文章/文档正文 |  |
| [An agent-based model of cooperation with cross-cutting identity dimensions](work-5f24ee492553de4fd6d9.md) | 论文/讲义提取文本 |  |
| [Build a Distraction System Throwable Objects, Noise, and AI Hearing](work-4e68632fc10230d4eeed.md) | 字幕/转录文本 |  |
| [Build a Distraction System Throwable Objects, Noise, and AI Hearing](work-9f6390bb00c7f06f8712.md) | 文章/文档正文 |  |
| [Building a game where you talk to NPCs using Llama 3.1-8B-q4, optimized for 6GB VRAM : r/LocalLLaMA](work-9c9b4873aef8f5a4857b.md) | 正文/源码节选 |  |
| [Cliff Harris, October 2020 archive — Democracy 4 voting analysis and development posts](work-174df31902749bf4ad20.md) | 文章/文档正文 |  |
| [CppCon 2015 component-based entity system example 0_ECS/p7.cpp](work-b88a293d95e2a9748ce8.md) | 源码/工程文本 |  |
| [Crytek’s Target Tracks Perception System](work-1608cc53490fdd181703.md) | 论文/讲义提取文本 |  |
| [Developer Blog: New Audio](work-2c2effe58e12aa038802.md) | 文章/文档正文 |  |
| [Dynamic Bounding Volume Hierarchies — Erin Catto, GDC 2019](work-9b795c4809221a4773fe.md) | 论文/讲义提取文本 |  |
| [Field of view visualisation — E02](work-6b437c069f9ead426c48.md) | 字幕/转录文本 |  |
| [GDS 2022: Leszek Szczepański - Ideals vs. Reality - Procedural Encounters in Horizon Forbidden West](work-942eeb9030f43ba9d9f8.md) | 字幕/转录文本 |  |
| [How to Build Realistic AI Perception and Memory in Unity](work-c1a8b366f433de0f1b95.md) | 字幕/转录文本 |  |
| [Last-Known-Position Search Behavior for Enemy AI in Unity \| XESOFT](work-0467b168e51f604a9948.md) | 文章/文档正文 |  |
| [Modeling AI Perception and Awareness in Splinter Cell Blacklist](work-e551881363a7e5920a21.md) | 字幕/转录文本 |  |
| [Modeling AI Perception and Awareness in Splinter Cell Blacklist — Martin Walsh](work-b18daff9d9ee80833ad1.md) | 论文/讲义提取文本 |  |
| [Modeling AI Perception and Awareness in Splinter Cell: Blacklist — Martin Walsh](work-819a9bcd2dbeb977a23b.md) | 字幕/转录文本 |  |
| [Perception AI: The Most Overlooked System in NPC Behavior (Deep Dive)](work-7b347e13eef01be8741a.md) | 讨论正文/已载入评论 |  |
| [ReGoap中文文档 — 烟雨迷离半世殇](work-1081719853d20a8cbefa.md) | 文章/文档正文 |  |
| [Simulating Natural Selection — natural_selection.py Blender scene script](work-60c6039b1ed540ada28f.md) | 源码/工程文本 |  |
| [Skin Deep: Enemy Brains](work-94d97dab6a556dd577dc.md) | 文章/文档正文 |  |
| [Smart Enemy AI (Part 3: Perception) – Tutorial in Unreal Engine 5](work-ed56db8950449b153105.md) | 字幕/转录文本 |  |
| [Stop fighting Unreal AI Perception System](work-6876711d3de1374cc9a3.md) | 文章/文档正文 |  |
| [Supporting Thousands of Simulated NPCs in Kingdom Come Deliverance 2 \| AI and Games Conference 2025](work-84831085d158f5cba30a.md) | 字幕/转录文本 |  |
| [Target Tracks Perception System / PerceptionAgent.cs](work-229e62143047307ca19f.md) | 源码/工程文本 |  |
| [The AI Systems of Left 4 Dead](work-e8a3e30af7e196a37782.md) | 论文/讲义提取文本 |  |
| [Tick Optimization Toolkit tutorial — actor tick events and timelines (5nKbXJLnDgs)](work-fed9210590208fbd08ed.md) | 字幕/转录文本、文章/文档正文 |  |
| [Tutorial_SpatialHashGrid_Optimized/src/spatial-grid.js (commit76973b671bfe1dee7bfe9e7db733d059134087dc)](work-9049f6017f943f5fe042.md) | 源码/工程文本 |  |
| [Unity Squad AI: Fair Alert Propagation](work-5ba18146791a68de6eb7.md) | 文章/文档正文 |  |
| [Unity enemy last-known-position search guide (Argus)](work-225ab2331a6b14d036ac.md) | 文章/文档正文 |  |
| [Unreal Engine 5 AI - Search last Seen Location - Action RPG #70](work-610bc65ced49aa3aaa6d.md) | 字幕/转录文本 |  |
| [Wise Feline Influence Maps module](work-1c992d33a087015995fa.md) | 文章/文档正文 |  |
| [\[game\]十字链表的AOI算法实现 — Ron Ngai,转载2017-11-08](work-57931aa1145c62cc8c13.md) | 源码/工程文本 |  |
| [直击GDC 2024（二）：网易智企首次揭秘篮球游戏AI智能体！](work-03401aa0d4e53755d0a6.md) | 文章/文档正文 |  |
