# A Generative Model of the Mutual Escalation of Anxiety Between Religious Groups

- 分类：感知、注意力与决策上下文。
- 资料标识：`identity-limited-unit:1213d5d89385b799123444f966223e00a301e38b9200657569b3bc13de02d1bb`。
- 已有内容：论文/讲义提取文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：F. LeRon Shults; Ross Gore; Wesley J. Wildman; Christopher Lynch; Justin E. Lane; Monica Toft。
- 原目录日期：2018-10-31（沿用已有记录）。
- 主要来源：[https://www.jasss.org/21/4/7.html](https://www.jasss.org/21/4/7.html)

## 概要与项目参考

Domino建议：将威胁事件、个人阈值/认识、情绪状态和寻求同伴任务分开；情绪跨阈值触发有界近期目标，不给每帧全员重规划。
Domino建议：共享集会/援助/组织活动记录协调占用与完成，成员各保留自愿、退出与个人进度；现有8人Behavior参与者数组不能代替整个组织活动。
Domino建议：参数谓词/短轨迹可用于解释为何出现集会或报复倾向，但无需永久全量事件日志。

## 已有机制分析

源论文：自然、捕食、社会、传染四类随机危害分别与个人阈值比较；社会/传染还要求半径内有外群体成员。焦虑按Rescorla-Wagner更新，感知时向1收敛，未感知时以较低速率向0衰减。
超过hyper-vigilance阈值的人先查自己的组内关系再查二跳关系，寻找同样超阈值且未被占用的参与者；达到最小人数成立排他仪式簇，逐步降焦虑，所有人低于阈值才解散。
仪式提高AP（以簇/全组均值比）和SP（本组/另一组均值比）；关系仅组内，局部互助降低当下焦虑又强化之后的群体解释/边界，产生反馈。
作者用20000次、每次250步参数扫描，按连续两组均焦虑上升的区间抽取谓词；相关率与覆盖率的调和均值suspiciousness定位模型内输入条件，长区间最强条件为多数≤70%且社会与传染强度达到阈值。

## 后续行为与玩法启发

未来帮派、公司、政治组织可从感知威胁→寻求支持→关系强化→回避/合作/冲突形成反馈。玩家援助、缓解资源短缺、公开证据或挑拨传言可改变输入。

焦虑/外群体接触只影响意愿与风险预期，不能自动产生罪行、受害者、司法判决；调查需分别记录真实行为、谁看见、传播的证词和机构执行。

协作集会可中断/拒绝，犯罪仍需物理位置、真实能力与资产约束；不复制按宗教/群体身份必然违法的规则。

## 适用范围与局限

源模型用社会网络二维矩阵、5N×5N景观，若按密集载体配置万人会有O(N²)甚至25N²存储风险；关系二跳与半径搜索若朴素亦会膨胀。

20000次扫描/500万步是分析规模，未给万人NPC吞吐、复杂行为、真实路线或持久化成本证明。

Domino用稀疏邻接、地域候选、有界二跳、增量群体均值与事件唤醒；共享灾害发生一次再发布给实际观察者，不为每人随意造独立世界灾害。

普通C可实现少量情绪字段、类型化事件和可恢复集会状态；研究的AP/SP可作为可选领域参数，避免把其宗教理论固化入通用执行器。

谓词条件可形成调试视图和小型采样轨迹；新增玩法需校准实际因果和设计目标，不能把相关排名当自动调参正确性。

论文明确不模拟暴力、不能预测具体真实冲突。原模型所有危害独立按人产生，仪式/寻找期间完全免危害，随机跳到任意位置；这些简化不能成为潜入/灾害/追捕的真实世界规则。

网络固定、只有两群体且无跨群体关系，遗漏政治动员；用群平均掩盖个体经历、证词差异与多重身份。

伪代码move循环/坐标赋值疑有笔误，正文阈值≥与伪码>、少数组大小表格也有不一致；AP/SP均值比例潜在零分母与无界增长需自行定义。

完整读本地论文文字载体含附录/参考文献，图像只见图注，未审AnyLogic源码或复现结果。

这是特定理论的模型内生成机制，不是现实群体的可推广判定；Domino设计映射是独立建议。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [8f1a5273da09b0c7e07955b2.txt](../texts/95/951df96fb1ba1cb46fe31d40c7232ac30fc8349d1f672cc6595cace512ddc5eb.md) | 论文/讲义提取文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 46000)、[46000, 57500)、[57500, 69000)、[69000, 80500)、[80500, 88667) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/05-organizations-institutions/08-religion-culture-groups.md](../../ai-reference/13-youtube-2011-2026/05-organizations-institutions/08-religion-culture-groups.md)
- [https://doi.org/10.18564/jasss.3840](https://doi.org/10.18564/jasss.3840)
- [https://github.com/SimRel/Merv1.0](https://github.com/SimRel/Merv1.0)
- [https://jasss.org/21/4/7.html](https://jasss.org/21/4/7.html)
- [https://jasss.soc.surrey.ac.uk/21/4/7.html](https://jasss.soc.surrey.ac.uk/21/4/7.html)
- [https://leronshultsblog.com/2021/03/26/24-march-2021-ai-and-religion-webinar-predicting-and-preventing-religious-conflict-using-maai-models/](https://leronshultsblog.com/2021/03/26/24-march-2021-ai-and-religion-webinar-predicting-and-preventing-religious-conflict-using-maai-models/)
- [https://www.jasss.org/21/4/7.html](https://www.jasss.org/21/4/7.html)
- [https://www.youtube.com/watch?v=JaCDDwkJTsw](https://www.youtube.com/watch?v=JaCDDwkJTsw)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
