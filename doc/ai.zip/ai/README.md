# NPC 行为模拟资料库

按主题整理 `doc/ai-reference` 中已经获取的正文、现成纯文本、来源链接与已有研究概要。围绕万级 NPC 的日常模拟、后续犯罪及互动玩法，兼顾调度性能、可扩展行为和维护成本。

共整理 **2,537 条资料记录**：其中 **2,469 条含正文、字幕、源码或可用节选**，52 条只有摘要/简介文本，16 条保留相关链接及缺口说明。已保存 **6,111 份去重文本**，原始文本合计 **97.8 MiB**。这些数目包括限定片段与不同文本版本，不代表同样数量的独立完整作品。

目标目录只包含 `.md` 文件。正文实际转存于本目录的 `texts/`，不是仅链接到原来的 `.txt`；重复正文共享一份 Markdown。图片、音视频、PDF、HTML 原件与其他附件保留为链接，未新增下载、识别或解析。

[当前前100入口](TOP100.md) · [保存范围与方法](METHOD.md) · [核验结果](VALIDATION.md) · [仅链接的页面与附件](LINKS_ONLY.md) · [原资料目录](../ai-reference/README.md)

| 类别 | 资料概要与正文入口 | 资料记录 | 配套归档文本入口 |
|---|---|---:|---:|
| 日常需求、效用与自主选择 | [01-needs-utility](01-needs-utility/README.md) | 194 | 6 |
| 任务规划、GOAP 与 HTN | [02-planning-goap-htn](02-planning-goap-htn/README.md) | 175 | 3 |
| 行为树、状态机与执行维护 | [03-execution-bt-fsm](03-execution-bt-fsm/README.md) | 233 | 6 |
| 调度、事件、时间与仿真细节分级 | [04-scheduling-events-lod](04-scheduling-events-lod/README.md) | 111 | 2 |
| ECS、数据布局、多线程与系统性能 | [05-data-concurrency-performance](05-data-concurrency-performance/README.md) | 219 | 8 |
| 导航、人群、交通与空间协调 | [06-navigation-crowds](06-navigation-crowds/README.md) | 210 | 2 |
| 物体可供性、资源占用与并发交互 | [07-affordances-resources-interactions](07-affordances-resources-interactions/README.md) | 26 | 0 |
| 社会关系、信念、信息与群体行为 | [08-social-knowledge-groups](08-social-knowledge-groups/README.md) | 286 | 0 |
| 犯罪、法律、对抗与后果系统 | [09-crime-law-conflict](09-crime-law-conflict/README.md) | 58 | 0 |
| 经济、工作、家庭与城市生活 | [10-economy-work-households](10-economy-work-households/README.md) | 280 | 3 |
| 涌现玩法、叙事、玩家互动与游戏设计 | [11-gameplay-narrative-player](11-gameplay-narrative-player/README.md) | 151 | 0 |
| 机器学习、强化学习与适应性 | [12-learning-adaptation](12-learning-adaptation/README.md) | 94 | 0 |
| 语言模型、认知记忆与可控代理 | [13-llm-memory-agents](13-llm-memory-agents/README.md) | 109 | 1 |
| 感知、注意力与决策上下文 | [14-perception-attention](14-perception-attention/README.md) | 36 | 0 |
| 多代理研究、模型验证与科学工具 | [15-modeling-validation-tools](15-modeling-validation-tools/README.md) | 160 | 1 |
| 工程案例、开源实现与边界材料 | [16-engineering-open-source](16-engineering-open-source/README.md) | 195 | 88 |

资料页区分已有机制分析、项目参考、玩法启发和适用范围，保留来源身份与字符节选范围。原有研究结论按已有记录转存；此轮分类保存未新增全文通读、媒体观看或运行性能验证。
