# PathFinding.js — BiAStarFinder.js

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-repository-bundle:qiao/pathfinding.js@2904a9afba483c02b5a61eb60fefd63e9b2db78c`。
- 已有内容：源码/工程文本。
- 主要来源：[https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/BiAStarFinder.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/BiAStarFinder.js)

## 概要与项目参考

局部格网机制可读，但非NPC目标/执行生命周期资料，Domino全局路网语义不同。

## 已有机制分析

source_facts: 起终点各一个按f排序的heap，交替弹最小节点；opened用BY_START/BY_END，共享closed与parent；相邻节点已在另一方向open即biBacktrace合路径。
轴向成本1/斜向SQRT2；diagonal模式选manhattan或octile，weight可放宽最优性；更小g时更新heap item。
无路返回空数组，直接在grid node写g/h/f/opened/closed/parent。
domino_recommendations: 仅作为将来需要局部室内格网搜索时的参考，搜索临时状态独立于世界节点/每请求版本。
当前道路Floyd不因此换算法；定向路网的反向扩展需反邻接而非照抄同getNeighbors。

## 后续行为与玩法启发

局部追逐/逃跑和绕障碍可用合适启发降低搜索成本，但这些纯函数本身没有犯罪/观察/任务机制。

潜入、障碍绕行与载具/步行的移动能力需明确对角穿越规则，但本文件没有动态犯罪、追逐或避让机制。

追逐、逃逸和封路可需要短期局部路径；可通行区域仍要根据实体权限和最新道路事实验证。

玩家封门/挪障碍让潜入、追捕与目击路线改变；普通移动、绕角、身体可通过尺寸须选清楚语义。

walkable不表达法律许可，受限房间仍可能物理可达，犯罪候选应区分入侵意愿/风险。

可供局部潜入/追捕的物理路线查询，门权限与犯罪主观风险仍独立于启发式成本。

室内封锁/追逐/潜入的角落通行规则，玩家关门或障碍改变可达性。

角色已知危险、权限与实际物理 walkability 应独立，本文件未提供这些领域条件。

Domino 推论：潜入或局部追逐可在必要网格中生成精细路线；门改变和破墙后必须失效旧路线。

物理路径查询不推断人物已知门状态、犯罪风险或目标合法性。

封路或障碍可影响物理可达；越界或非法进入还需独立权限/风险与个体选择，不能由此构造器推导。

未来人物不同移动能力/障碍条件可选物理模式；犯罪无权进入不代表物理上不能通行。

玩家放置障碍可影响实际路线，但本工厂没有感知、动态障碍、协作避让或行动到达语义。

玩家封锁窄门、建筑内追捕须按实体尺寸/权限/障碍规则算路径，避免穿角；本文件只几何可达，不处理违法许可或观察。

source_fact:
代码无玩家/犯罪规则。

domino_recommendation:
封门、障碍和狭角影响潜入/追逐路线，空间可走不等于区域制度许可或人物知道通道；目击仍需视线判断。

潜入/室内追逐需要门、墙、权限、目击区域，格网能支撑局部几何；不能把路径存在当合法或无人看见。原文无这些玩法。

未来局部室内潜入/追捕网格可参考跳点减少展开，但动态障碍、权限、追踪行为与真实移动执行仍另需领域规则。

潜入绕障、玩家封路、追捕逃逸可用局部可达性及明确空路径失败，执行期间仍校验真实位置/路线版本。风险、权限和NPC是否知道障碍不应混进统一物理过滤。

为追踪、逃跑或配送提供路线候选的局部数学工具；没有门禁、物品消耗、犯罪风险或动作效果。

## 适用范围与局限

每次启发计算O(1)，不证明整个路径规划器或10000NPC成本。主开销取决于展开节点、动态变更和候选请求数。

本工厂没有JPS剪枝、搜索复杂度、缓存或基准；无法以1191字符dispatch文件证明万人寻路效率。

堆与邻接扩展的工作量受探索节点影响，源码没有硬预算或万级 benchmark；需明确取消/继续与扫描上界。

每人clone全图O(width×height)时间/空间；源码先new Grid又构造新Nodes，可能有重复初始化成本。

万人应共享拓扑并局部有界查路或worker临时scratch；没有性能基准、路径算法或动态缓存失效。

无最坏复杂度、实测或万级NPC预算；两堆与每节点状态仍可全图增长，无路径时昂贵。

每次独立scratch/克隆有内存成本，复用节点状态则有清零/跨搜索污染风险。

剪枝减少搜索邻居但递归仍可走长直线/大量网格，未给复杂度/吞吐基准。

每 NPC 独立动态 grid/full重置在10k成本高；共享静态局部图与有限查询，不能每次全世界重建。

跳点是否减少访问取决于未读子类与地图；此文件没有任何 10000 NPC 基准。

finder 与 grid 节点状态可变，万人查询不能直接多线程共享；重置/独立状态的内存与成本须另计。

无寻路算法、复杂度、缓存或万人测量；JS逐节点对象的内存布局不能直接移植到C23数组。

本文件分派O(1)，实例分配和实际findPath成本未知；不能把常数工厂成本当寻路成本。

10k并发搜索、图维护和缓存复用均未出现；四种grid策略与当前道路图分组不是同一拓扑。

JPS减少规则网格扩展但递归可扫描长走廊；每NPC查询仍有成本，无万级benchmark。

source_claim:
未包含benchmark。

domino_assessment:
getNeighbors常数最多8；构建/clone为O(W*H)，clone先new Grid分配再另分配整格，临时内存更高；N个人重复clone全图不可用于万人。

每请求双heap/节点更新成本随搜索范围增长；同grid mutable状态不能万级请求并发复用，本文件也无重置/时间切片/缓存失效接口或规模基准。

同步循环直到成功/耗尽，无展开预算或取消检查；万人同时寻路会峰值。

本文件依赖子类jump/邻居过程，未见复杂度或实测；每个finder和节点状态拷贝可能增加内存。

按目标启发式探索可减少节点展开，worst case仍可能扫描大grid；每NPC独立搜索/完整clone成本会放大10000次请求。源码无时间片或节点预算、缓存及性能实测。

每次函数O(1)，并不证明整个A*搜索或10000NPC调用成本；不可达搜索的展开数仍由图决定。

保留输入非负前提与步进代价配置，启发变化要验证可采纳性/一致性；本文件未审调用者与求解器。

opt整对象转发方便一致配置；默认分支会把未知值也当IfAtMostOneObstacle，项目若暴露外部输入应明确其校验边界。

采用稳定实体 ID / grid revision，清理每次 query 状态；相同 f 的 tie 与重复使用并发限制要明确。

角向策略枚举简洁可测试/解释，新增门、尺寸和方向不能藏于一个bool。

矩阵检查只看行数及第一行长度，不能由此称完整输入校验；地图更新需单独版本和计划失效。

start==end及节点状态reset未在文件中处理，需调用方合同；此代码无完整正确性证明。

返回第一相遇及weight启发式不能无证据承诺最短路；方向图需要逆邻接及双向停止条件另设。

父方向及二值通行规则可解释； base class 的 open/closed、路径恢复、成本和 grid mutation 生命周期另需审阅。

C 移植宜迭代或限深避免长走廊栈耗尽；规则变化后 pruning/缓存须同版本。

Manhattan 默认启发式与 octile 边代价、DiagonalMovement 和子类邻居策略须组成明确契约。

h = h || heuristic 会复用已有非零 h；旧目标与旧搜索字段的管理必须由调用者或其他文件保证。

默认true是该库接口选择，不适用于未经加载/校验的Domino道路。

各算法自加属性可能混入上次搜索状态；本文件没有清理契约，不能据此宣称并行查询安全。

C23若需要少量模式可用enum和函数表/分支保持清晰，不引入JS依赖或通用插件层。

未识别的diagonalMovement落入默认分支，外部输入与预期默认需在调用契约明确。

代码注释说one neighbor open而实际&&要求both，采用时以当前实现契约和场景明确对齐；父方向需非零有效，图状态改动失效另定义。

只有通行bool，不能表达坡度、容量、边权、预计时间或动态预约。格式化修复载体已保留完整分支；外部矩阵空/不规则行和坐标输入需项目定义入口契约。

共享closed、h缓存和parent需调用者保证每次干净状态；自定义heuristic/weight改变保证，不能仅凭A*名字声称最短。

findPath非可重入，不能多线程共用finder/grid；明确新查询重置或使用epoch。

保留路径权重、几何距离和实际ETA的区别；需核全部JPS子类才能判断允许的移动模式。

移动规则与heuristic匹配，目标/拓扑变化必须隔离旧h、opened、parent。C实现可复用有界work buffer和代际scratch索引，保持公共图只读。

小型公式可独立检查，需统一调用者dx/dy与边成本约定；注释与实现不一致应在实际采用时处理。

带负差调用manhattan/chebyshev会产生错误下界；代码没有内部abs。

对允许对角移动的图直接manhattan可能高估，任意路权也不保证euclidean适用。

工厂分支正确不保证返回算法对任意权重、动态图或道路网络正确；具体JPF实现未读。

注释默认heuristic不等于本文件实现了启发式，也不保证对各对角政策的适配。

未重置 opened/closed/h 后重复用同 grid 会污染下一次搜索；同 grid 并发读写有竞争风险。

closed 节点不重新打开，在不一致 heuristic 下不能由此保证最优；weight 大于 1 可牺牲最优性。

Always可穿两侧都阻挡的角，是否合理取决局部场景；walkable只看目标点可能忽略身体半径。

全NPC深clone导致内存/初始化放大，动态障碍和老结果没有revision校验。

Grid没有方向道路、权重、ETA、预约或动态实体避免。

复用旧h/closed/parent会给错误路径；shared scratch并发查询会交叉污染。

有向道路反向沿getNeighbors找不到真正前驱，不能等同有向双向搜索。

first meet与weighted heuristic可能给次优路径，不能把路径权重当真实ETA。

注释 one 与实际 && 不同，若按注释改 OR 会允许穿角。

无父/零方向/越界处理依赖未读 base/grid 契约；不能独断声明完整算法正确。

本文件无非均匀风险成本处理，不能宣称适用危害加权路线或道路网络。

同 grid 换目标或并发搜索若没有外部重置/独占，可复用 closed 或 parent 并得到错误结果；本文件不足以证明调用者有无保障。

非均匀权重、单向道路、动作代价和时间不等于 octile 距离，误套会破坏最优性或业务计时。

Node对象存在不代表路径存在。

把禁入规则等同不能行走会掩盖潜入、逃捕等强玩法的物理可能性。

将此文件阅读等同JPS全文或性能优势会过度推断。

认为注释默认manhattan已在此实现、或非法模式会被拒绝，均与实际分派不符。

路径返回不代表人物已到达、避开其他NPC或完成服务。

非均匀权重、有向道路、动态实体半径或权限变化不满足普通规则网格JPS的假设；递归深度与tested标记共享未在文件处理。

Always可在两侧均障碍时穿斜角，可能违背实体半径。

matrix仅检查首行宽度，ragged后续行或空矩阵不是安全输入。

setWalkableAt不检查边界，按API前置契约使用；本文件无路径缓存失效，不能推断整仓无处理。

clone不保留其他Node搜索字段，读者须分清拓扑复制与完整运行状态复制。

重复搜索未清node状态可沿旧closed/parent/h。

起点等于终点未显式处理，需上层契约。

最先前沿相遇立即返回不在此文件证明全局最优；directed graph反向使用同邻接不正确。

重用有closed或旧h的grid可能直接跳过可达点或使用上一终点启发值。

Manhattan默认与octile跳段/允许对角移动的可采纳性需看子类规则，当前文件不证明。

二维网格JPS前提不适合任意方向/权重道路。

同grid重复/并发查询会污染opened/closed/h；本文件没有清理协议，不能当安全并发导航。

weight>1或用户非可采纳heuristic不保证最短；单位网格g不是真实距离/现实ETA，空路径也不判定制度禁止原因。

对允许低价长距传送的图套欧氏下界可能高估，从而损害A*最优性；原文件未校验图条件。

传入带符号dx/dy会让Manhattan/Octile/Chebyshev出现错误结果；此文件不提供参数规整。

全文975字符固定commit源码文件；没有审PathFinding.js完整仓库或运行路径算法。

只提供常见启发公式，NPC机制与规模价值有限。

整个工厂文件全文已读，未读四个JPF实现/整仓源码。

按PathFinding.js作品归并，单个dispatch文件没有独立前100机制价值。

完整 AStarFinder.js 文件已读，heap/grid/Util 不在本 task，未运行或 benchmark。

重复网格/并发与不一致 heuristic 风险为源码推断，依赖调用方约束未核。

完整读Grid.js，未读取Node/DiagonalMovement实现或任何finder，不算PathFinding.js全仓审计。

没有运行路径、格网绘制或万人成本验证；只是局部邻接规则参考。

完整读该文件，未读Heap/Grid/Util及测试；不等于整体仓库或算法正确性验证。

完整读4540字符子类源码，未读此任务之外的 base/grid、未运行或观看关联视频；不是整 PathFinding.js审计。

仅该源码文件全文，未读 _jump/_findNeighbors 子类、Grid/Heap 实现或测试。

未运行寻路或验证启发式契约，不把潜在调用风险当已证实库缺陷。

完整读取该700字源码文件，不是PathFinding.js整仓或算法审计。

没有执行源码、构建或性能验证；转录去缩进不改变这里可见的构造语义。

全文源码是小工厂而非JPS算法正文，直接价值有限，排除前100。

其余import模块、grid/search性能和路径执行未读未测。

完整读取单JS实现，未读base/open heap/成本设置或运行算法；非现有Domino道路图替代证明。

完整Grid.js文件，属于整仓fragment_read；未读Node、实际finder或缓存实现。

不构成全仓审计/运行证明，动态图或并发问题不可由本文件作整体判定。

固定提交单源码文件全文，未读grid/heap/Util实现或运行算法。

不把单文件阅读当整PathFinding.js源码审计。

完整3438字符固定版本单源码文件已读，不等同整仓/完整JPS算法审计。

未读子类_jump/_findNeighbors、Grid/Heap或运行实例，不能声称完整JPS正确性/性能。

完整读单文件4627字符及关联aliases身份；未审Grid/Heap/Util实现或当前Domino导航接口，无运行/性能验证。推荐局部搜索和scratch边界，非直接迁移库。

1092字符固定提交2904a9afba483c02b5a61eb60fefd63e9b2db78c文件全文已读；不是整PathFinding.js搜索器或性能验证。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [01877fcb193080b8249ece4f.txt](../texts/01/015c6ba8430555d5e0299806826eddd1afdfc3902899f3795ba75f91589370e8.md) | 源码/工程文本 | [0, 3796) |
| [7814da3ff16ad4f5f56e31b4.repaired.txt](../texts/0a/0ab4d412626a9e664ca2f2841d80b27f0e8dff707a79389fee78c33f42d52ee2.md) | 源码/工程文本 | [0, 1264) |
| [16d00d5793bfef2020ce0a8b.txt](../texts/0e/0e697b94fbb58027244e19d454c0bc53b555410942a1911fa2cb0dfa497e3dc6.md) | 源码/工程文本 | [0, 4540) |
| [04357f3ec62c8e8fab922091.txt](../texts/1c/1cfb445d8f5e2529e905a90c7d88c4910a639350d387050069d09c68a2d1e3b1.md) | 源码/工程文本 | [0, 975) |
| [73b32f926037b40aa2ba2518.repaired.txt](../texts/1e/1e06e6007bd608cf07046912d8d406e767843b2c21783fa5fae0b4f1734a817e.md) | 源码/工程文本 | [0, 3438) |
| [04357f3ec62c8e8fab922091.repaired.txt](../texts/29/29289856852af721b1cbefcb80d0321d13fe7682966048bacddd8502e03f05cf.md) | 源码/工程文本 | [0, 1092) |
| [b583268a77cb6cb420a6d1e1.txt](../texts/46/46931c972962384c81949d3257428f11772ecf4b98d6bcfe4a15f98434b585b2.md) | 源码/工程文本 | [0, 1191) |
| [16d00d5793bfef2020ce0a8b.repaired.txt](../texts/49/49fd54cbd028e5baeebc6b2ecc3bb9eab9c70c17019255f959f25b90241d5384.md) | 源码/工程文本 | [0, 6004) |
| [20b853493fb90dc51d1a064c.txt](../texts/89/89576fc116778452e8d6083903d4b14c71f678163a74464f9896b3ba0909700a.md) | 源码/工程文本 | [0, 5267) |
| [16cf38402121d4f427485620.txt](../texts/8f/8f8d0a70e9835de5b8ffd47a907924190e45a8882d39e5537f0cf0864be041ae.md) | 源码/工程文本 | [0, 700) |
| [46f4f232e65dbc82d11fd724.txt](../texts/b9/b97006e45f45c59f6aa5224361d6aaabaff985255a4cc07e7ae5df0ef801581d.md) | 源码/工程文本 | [0, 5462) |
| [0aa7846aaf1ebe881418f377.repaired.txt](../texts/c6/c6945eb420c6dafe367ca255343c0658c1c09ce9e47881b219d1e911a3e4a3cd.md) | 源码/工程文本 | [0, 6678) |
| [8e875fd5cc7bcab13044b06e.txt](../texts/cd/cdb860b3335b5f5945fba9b805986a2e1bf3f47bac575fbe18526cdb3189fa98.md) | 源码/工程文本 | [0, 2813) |
| [326cb7d8b4ff3500ad7d6050.repaired.txt](../texts/d0/d0279a397c93f53f0cfae2f404e5e0636164a9607f2823a13031e37d01916608.md) | 源码/工程文本 | [0, 6404) |
| [01877fcb193080b8249ece4f.repaired.txt](../texts/d1/d1e8e12a2c84f8af2175136b08bc435a9ec9854e3c17d84cc17d37533d5633d0.md) | 源码/工程文本 | [0, 4627) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [16cf38402121d4f427485620.repaired.txt](../texts/04/04aca052e76ee3ead35b866d7060d59677cb04f3c330e74a4eff47019d6ed3ee.md)
- [a87111ec4ce9dbc476521642.repaired.txt](../texts/16/1697429bdc23adae9fbf8b3c099b9010e6e615e4c7e9705c424e1a31fe388b32.md)
- [b583268a77cb6cb420a6d1e1.repaired.txt](../texts/5e/5e72b0ed9d9a4a73027fed6baf270c515a746865f2f32865364d00822a899962.md)
- [20b853493fb90dc51d1a064c.repaired.txt](../texts/7f/7fade50f70ba6ca2597e70ff399b17fb263746a9d8c1129014d2d1a2d9fa2d76.md)
- [46f4f232e65dbc82d11fd724.repaired.txt](../texts/9a/9a26470226bce5b8bf49fe7a40141a9eb28c2d6eb4d3ff99c4ca0c44457dd734.md)
- [2f891d1a00cf1522f49eeb18.repaired.txt](../texts/b1/b1dc3644609590c7bbbf2e7930e08728e63c07189ae48b0ba712c7262a74d69b.md)
- [33a2a1985d82f3305faaf3d3.repaired.txt](../texts/b3/b32edabd199f82a787d379641832a47407151ea0f397e3f2fb54a0ca007d2c0c.md)
- [8e875fd5cc7bcab13044b06e.repaired.txt](../texts/cf/cf5e4d2f4d4bb414016ad7dda8ef29508725915e4db673cbb01f8ac137bbbcb2.md)
- [61feb55178f3e072e8bcdcb0.repaired.txt](../texts/e9/e9006df4bbc5bd38de4ba993db05b0eb1ca7e1d3a0eaf015d0d98f011f2527e6.md)

## 原研究概要与相关链接

- [11-open-source-projects/03-navigation-environment/pathfinding-js.md](../../ai-reference/11-open-source-projects/03-navigation-environment/pathfinding-js.md)
- [https://github.com/qiao/PathFinding.js](https://github.com/qiao/PathFinding.js)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/README.md#L253-L264](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/README.md#L253-L264)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Grid.js](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Grid.js)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Grid.js#L223-L242](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Grid.js#L223-L242)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Heuristic.js#L13-L35](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Heuristic.js#L13-L35)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Node.js#L10-L25](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Node.js#L10-L25)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/AStarFinder.js](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/AStarFinder.js)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/AStarFinder.js#L97-L117](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/AStarFinder.js#L97-L117)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/BiAStarFinder.js#L84-L100](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/BiAStarFinder.js#L84-L100)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JPFMoveDiagonallyIfNoObstacles.js#L25-L79](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JPFMoveDiagonallyIfNoObstacles.js#L25-L79)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinder.js](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinder.js)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinder.js#L18-L28](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinder.js#L18-L28)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js)
- [https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js#L79-L108](https://github.com/qiao/PathFinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js#L79-L108)
- [https://github.com/qiao/PathFinding.js/commit/2904a9afba483c02b5a61eb60fefd63e9b2db78c](https://github.com/qiao/PathFinding.js/commit/2904a9afba483c02b5a61eb60fefd63e9b2db78c)
- [https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Grid.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Grid.js)
- [https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Heuristic.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Heuristic.js)
- [https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Node.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Node.js)
- [https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/BiAStarFinder.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/BiAStarFinder.js)
- [https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JPFMoveDiagonallyIfNoObstacles.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JPFMoveDiagonallyIfNoObstacles.js)
- [https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js](https://github.com/qiao/pathfinding.js/blob/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js)
- [https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Heuristic.js](https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/core/Heuristic.js)
- [https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/AStarFinder.js](https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/AStarFinder.js)
- [https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JPFMoveDiagonallyIfNoObstacles.js](https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JPFMoveDiagonallyIfNoObstacles.js)
- [https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js](https://raw.githubusercontent.com/qiao/PathFinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js)
- [https://raw.githubusercontent.com/qiao/pathfinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinder.js](https://raw.githubusercontent.com/qiao/pathfinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinder.js)
- [https://raw.githubusercontent.com/qiao/pathfinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js](https://raw.githubusercontent.com/qiao/pathfinding.js/2904a9afba483c02b5a61eb60fefd63e9b2db78c/src/finders/JumpPointFinderBase.js)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
