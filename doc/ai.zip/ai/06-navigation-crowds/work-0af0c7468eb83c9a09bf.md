# Hierarchical Dynamic Pathfinding for Large Voxel Worlds; https://gdcvault.com/play/1025151/Hierarchical-Dynamic-Pathfinding-for-Large

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://media.gdcvault.com/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf`。
- 已有内容：论文/讲义提取文本。
- 当前前100：第 44 项；[大体素世界动态层级路径：前瞻、失效与局部修复](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/044-0af0c7468eb8.md)。
- 原目录作者：Benoit Alain。
- 原目录日期：2023-11-03（沿用已有记录）。
- 主要来源：[https://media.gdcvault.com/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf](https://media.gdcvault.com/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf)

## 概要与项目参考

对human-ai未来移动执行、中断与动态玩家干预很有价值；导航技术不是任务选择或犯罪制度，作为局部机制引用。

## 已有机制分析

source_fact: 可走体素按父网格内局部连通分组，递归合并父节点；权限不混合、边可不对称。修改只重建变动体素的进出边并逐层传播，批修改合并高层工作。
domino_recommendation: 未来大动态室内/地形图可使用层级连通性；当前稀疏道路Floyd无需立即改成体素树，先借鉴区域失效和分批更新。
source_fact: 层级A*按长度/目标距离/玩法罚值优先，代表子节点估距离，高层权重是近似；靠近目标或存在动态阻挡时下降到低层以避免错误可达。
domino_recommendation: 物理通行能力与主观危险代价分开，非法越界仍可规划；风险权重不是实际距离或ETA。
source_fact: 路径只保留2–3节点前瞻、临近执行再细化；行走中验证失效路径，限距离修补子路径，失败才停止重寻。复用节点用出生时间与路径时间辨旧节点。
domino_recommendation: 移动行为保存路线修订和已走进度，局部修复而不重置全部任务；C记录用ID/代际避免裸指针和复用节点误匹配。

## 后续行为与玩法启发

玩家封路、关门、移动障碍或破墙能让NPC等待、绕行、追捕/逃逸或改用路线。

警戒/恐惧代价影响主观路线，攀爬/体型权限决定物理可行；隐入建筑需必要局部空间精度。

## 适用范围与局限

作者以百万体素/6–8层报告150MB、典型单体素更新<=0.1ms、最坏搜索0.5s；动态图障碍通常少于数百，不能外推10,000同时移动人。

建议按活跃移动者预算切片、合并地图修改和分散细化；万人每帧重寻/动态互避仍有O(N²)风险。

最优性与预算折中明确，重要短路可低层重算；不能将最佳LogN当最坏界。

层级分组、权限一致性、失效代际与路径进度需要清晰合同；共享导航结构与每人路线实例分离。

无限世界、threading、portal和公交是未来工作；不据幻灯片当已实现线程安全方案。

极端/微妙权重使近似路径不最优；代表体素不是实际精化要连接的唯一点。

省略动态障碍仅适用于粗reachability检查，执行必须复核，敌人由战斗AI接管是特定游戏假设。

大体型/挖掘/飞行另需规则，不要全空中/全地底铺节点。

全文通读幻灯片文本载体，未核示意图、原视频讲解或Sauropod源码；含大量仅页眉的视觉页。

性能为作者报告且需其地图/帧预算假设，本轮无复现。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [a65dbb453b898b733b97c4ff.txt](../texts/2e/2e2920f37fb89ff93f3fc5979d594a5085eeea0afbde5620107e63fbe0a7fe3b.md) | 论文/讲义提取文本 | [0, 11500)、[11500, 23000)、[23000, 27610) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md)
- [https://media.gdcvault.com/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf](https://media.gdcvault.com/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf)
- [https://ubm-twvideo01.s3.amazonaws.com/o1/vault/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf](https://ubm-twvideo01.s3.amazonaws.com/o1/vault/gdc2018/presentations/Alain_Benoit_HierarchicalDynamicPathfinding.pdf)
- [https://www.gdcvault.com/play/1025151/Hierarchical-Dynamic-Pathfinding-for-Large](https://www.gdcvault.com/play/1025151/Hierarchical-Dynamic-Pathfinding-for-Large)
- [https://www.youtube.com/watch?v=pG9SoTF1mCI](https://www.youtube.com/watch?v=pG9SoTF1mCI)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
