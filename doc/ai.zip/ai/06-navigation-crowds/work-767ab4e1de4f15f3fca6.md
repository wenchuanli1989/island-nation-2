# Recast Navigation README.md

- 分类：导航、人群、交通与空间协调。
- 资料标识：`github-file:recastnavigation/recastnavigation@9f4ce64458dfae86e1239c525ddc219c4e9e06f1:README.md`。
- 已有内容：文章/文档正文。
- 主要来源：[https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/README.md](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/README.md)

## 概要与项目参考

Domino未来精细局部导航可参考生成/查询/移动三层职责；现有road/Floyd不需仅因README迁移。
物理走不通和制度不允许进入需分开：navmesh几何过滤不能统一取消非法潜入机会，真正移动成功仍由执行器确认。

## 已有机制分析

Recast按三角形→体素化→去除不可走体素→可走区域分组→重三角化生成navmesh，物理可走性处理与运行查询阶段分开。
模块区分Recast生成、Detour运行加载/寻路/query、TileCache流式数据、Crowd移动避障及DebugUtils；single适合简单静态，tiled更复杂但面向大动态环境、rebake/层次规划/streaming。

## 后续行为与玩法启发

动态障碍、室内潜入、追逐、人群避让可接精细区域，对应玩家封堵路线与局部逃逸；此README未提供这些完整玩法系统。

房间、掩体、封锁和动态障碍可支持犯罪/追捕空间玩法；mesh物理可达不是制度许可，非法越界不能简单在全部候选阶段剔除。

局部可走区域/动态封锁有利于潜入、追逐、阻路，许可/目击仍须另建事实与信念。

## 适用范围与局限

Fast/industry standard只是项目声明，没有10000 NPC、地图尺寸、每次rebake或crowd成本数据。

tiled降低更新范围但共享缓存/区块预算仍须另设计，不能每NPC复制mesh或全员每帧全量查询。

README营销性能/行业采用不是10000角色测量；tiled动态更新降低影响范围但复杂度和Crowd上限未在此载体给出。

README 未给 10000 NPC 查询或 Crowd成本；tile/cache有空间局部性启发，不能把 open-world 表述当万人证明。

模块与Demo/Tester入口便于只选所需功能，C++98无其他依赖仍不是C23直接接口。

本地.repaired载体与raw MD别名同内容，按一个作品关联；未读取链接源码或构建指导。

导航生成/运行查询/动态缓存/移动/调试分模块清晰；只有场景精度需求上升才承担C++集成和tile版本维护，避免现在无依据迁移。

模块化/DebugUtils帮助调试；多tile重烘焙与流式加载复杂度高于单网格。

自动从任意几何建mesh不意味着巨大场景能低成本全量烘焙；single static与tiled dynamic成本不同。

导航路径不是距离/ETA或真实到场证明，Crowd移动避让也不处理个人承诺/资源/知识。

navmesh生成成功不证明资源服务可用或人物已移动。

tile更新若未使路线实例失效，NPC仍可能穿过新障碍。

导航可达不等于制度许可或不被发现；以 path 权重替实际 ETA 仍不成立。

4299字符README完整读取，属于原项目文档而非associated分析；未核图像、源码/性能/完整仓库。

短模块说明应关联Recast作品其它实读正文，不独立作为前100实现证据。

完整核读4275字符固定commit README；未读Recast/Detour实现、集成文档、测试或demo。

读完本地 README，未读实现、demo、API链接或复杂场景测量。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [8790543dfd94b27b66a21465.repaired.txt](../texts/3e/3e36443648f6f8888ebd2121663d8848b719c37a3118cfd345ca8242e7583ea3.md) | 文章/文档正文 | [0, 4299) |
| [8790543dfd94b27b66a21465.txt](../texts/69/69994d3a512d5614a8c086a0b66f2ba16bce05b73e9549781f99313465e77f24.md) | 文章/文档正文 | [0, 4275) |
| [e0c97362c2044d802d254724.txt](../texts/ec/ecfc2d2e6050ca77399541e5e313e2c580c93146ed71558eddd9fc6a6b57474c.md) | 文章/文档正文 | [0, 3344) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [e0c97362c2044d802d254724.repaired.txt](../texts/ec/ec11523fe11c575a59b4e3f57428c2b64010e8bf40901adb53842fc161e4287e.md)

## 原研究概要与相关链接

- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/README.md](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/README.md)
- [https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/README.md](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/README.md)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
