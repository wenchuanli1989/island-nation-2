# Helping It All Emerge: Managing Crowd AI in Watch Dogs 2（Roxanne Blouin-Payer）

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://media.gdcvault.com/gdc2017/Presentations/Blouin_Payer_Helping_It_all.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Roxanne Blouin-Payer。
- 原目录日期：2017（沿用已有记录）。
- 主要来源：[https://media.gdcvault.com/gdc2017/Presentations/Blouin_Payer_Helping_It_all.pdf](https://media.gdcvault.com/gdc2017/Presentations/Blouin_Payer_Helping_It_all.pdf)

## 概要与项目参考

Domino建议：空间/建筑提供活动机会而非直接生成持久NPC；人物依据主观关系/已知incident作出反应，实际动作统一启动/提交。
公共生命周期可按观察反应/移动/核心/退出拆分，情绪cooldown用现实_ms，并保持已发生世界效果和记忆，不回默认抹事实。

## 已有机制分析

source_fact: 三系统：对象上的手工Attractors、Event Manager生成greetings/crimes的Dynamic Attractors、stimuli驱动Reaction System。
mechanism: stimulus根据behavior/incident/emitter/target及friend/enemy条件选择ignore/observe/fight/flee；传播刺激形成后续反应链。
source_fact: 行为分reaction→orientation/movement→core→exit→return，包含距离comfort zone、角度、跟随/保持位置、目标消失或X秒、末bark和cooldown mood。
mechanism: 初始反应与实际活动阶段分开，中断后的情绪连续和回到先前状态使反应可信。
source_fact: 课程列ratio而非纯randomness、personality分布、自稳与任务场景civilian detection/warning/interior需求；工具包括Reaction Matrix及repro/understand/control。
mechanism: 大配置集合组合出可观察变化，作者给750logic/200animation/220audio rules和五类personality比例。

## 后续行为与玩法启发

辱骂、目击偷盗、援助/围观/斗殴/逃离、举报与玩家挑衅让criminal事件形成可干预链；friend/enemy是人物主观关系，犯法事件不应在物理候选阶段删除。

玩家通过散播消息、破坏attractor、阻断出口影响后续；机构裁决与处罚不因stimulus matrix命中而自动完成。

## 适用范围与局限

PDF没有NPC数、CPU、内存或长期事件上界；30% more playtime是无控制细节的作者结果，不能外推万人吞吐。

Domino建议：按事件类型/地域/角色编译稀疏rule候选，合并可替代刺激、有限冷却和任务预算；不能每帧每NPC扫描750条规则或全员广播。

reaction matrix把规则/动画/音频分开便于作者ing；需要规则冲突优先级/条件原因、状态转移和debug记录，原文把Rules Competition列未解。

自稳、情绪连续的具体公式未在文字中给出；先做有限可追踪状态及反例，避免无限加全局exceptions。

原世界会spawn活动/群众，其短反应return default并不支持持久合同、资产损失或调查证据自动恢复。

严格按friend/enemy随机反应会把看见/推断/制度惩罚混在一起；应另有observer记录和主动行为。

自稳若只是把冲突回零会抹掉犯罪后果；建议仅限制刺激传播/行为发起，不撤销事实。

文字抽取中逻辑表列/百分比对应不完整，不能恢复所有概率或精确矩阵布局。

5429字符讲义抽取文字全文；图形/视频/表列位置未核看，不把它叫完整讲座观看。

750规则是内容量不是执行频率；full local text是源讲义证据，关联YouTube LHEcpy4DjNc不额外算作品。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [0d2c57d57afc2a69d076a825.txt](../texts/a2/a23d6d03954379535d6bf956804417e28bb39c70ca75c3ff68dfe94fd03182af.md) | 论文/讲义提取文本 | [0, 5429) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/09-game-case-studies/07-hitman-watch-dogs.md](../../ai-reference/13-youtube-2011-2026/09-game-case-studies/07-hitman-watch-dogs.md)
- [https://media.gdcvault.com/gdc2017/Presentations/Blouin_Payer_Helping_It_all.pdf](https://media.gdcvault.com/gdc2017/Presentations/Blouin_Payer_Helping_It_all.pdf)
- [https://www.gdcvault.com/play/1024152/Helping-It-All-Emerge-Managing](https://www.gdcvault.com/play/1024152/Helping-It-All-Emerge-Managing)
- [https://www.youtube.com/watch?v=LHEcpy4DjNc](https://www.youtube.com/watch?v=LHEcpy4DjNc)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
