# Avoiding other pawns during pathfinding

- 分类：导航、人群、交通与空间协调。
- 资料标识：`reddit-post:1atohv7`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：u/Redemption_NL（主帖与修复反馈）；u/Shitscrubber64（建议）。
- 原目录日期：2024-02-18（沿用已有记录）。
- 主要来源：[https://www.reddit.com/r/unrealengine/comments/1atohv7/avoiding_other_pawns_during_pathfinding/](https://www.reddit.com/r/unrealengine/comments/1atohv7/avoiding_other_pawns_during_pathfinding/)

## 概要与项目参考

说明规划可行性/路径成本与执行中的局部避障是不同需求；Domino可给路段封锁或静止障碍明确可达性修订。
只能借鉴按动作/障碍变更更新的触发原则，不能原样将全局选中状态用于多人并发路由。

## 已有机制分析

主帖问题是非网格回合制必须在确认移动前知道绕过静止单位的精确路径长度，RVO运行时避让不满足其距离预算。
评论建议昂贵进入成本/动态导航修饰；作者报告最终使用 Dynamic Modifiers Only、Capsule 与 NavModifier，默认 NavArea_Null，选中单位暂改 NavArea_Default 以去除自身阻挡，取消选择恢复。

## 后续行为与玩法启发

玩家封门、单位包围或阻路可影响真实路径候选；违法追逐也需满足空间约束，违法性不能替代物理封锁判断。

## 适用范围与局限

作者仅报告原型修复，没有人数/耗时数据；动态网格或修饰更新对10000+并发移动不可直接证明。

回合中只有一人行动让临时移除自身障碍安全；持续并发活动需要请求特定忽略自身或快照，不能全局开关。

UE组件/运行时生成配置绑定特定引擎；Domino只需对应障碍变更与自身排除接口，不必移植UE依赖。

若多个单位同时选中或开始移动，全局 Null→Default 切换可能让其他单位也穿过本应被挡区域。

高成本区不等于禁止通过，严格移动距离还需长度/成本区分；主帖没有展示复杂密集人群。

classification_hint为 associated_analysis，但正文是直接引文主帖与本次可见评论，修正为社区原文载体；非全部评论，未读媒体/运行复现。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [S2-reddit-visible-text.md](../texts/88/882596409903b08148e0b3e66603301a766e25db5f004a92fc2a9e6f5122d1c5.md) | 讨论正文/已载入评论 | [0, 3818) |

## 原研究概要与相关链接

- [14-three-sites-2026-10-04/03-world/local-congestion/content/S2-reddit-visible-text.md](../../ai-reference/14-three-sites-2026-10-04/03-world/local-congestion/content/S2-reddit-visible-text.md)
- [https://www.reddit.com/r/unrealengine/comments/1atohv7/avoiding_other_pawns_during_pathfinding/](https://www.reddit.com/r/unrealengine/comments/1atohv7/avoiding_other_pawns_during_pathfinding/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
