# Add a NavigationWorld2D/3D as a navmesh high performance option for large worlds

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:95453cba161f791aa71914f66a93e8abe96f7b17270a56ab1d935db3614491a1`。
- 已有内容：讨论正文/已载入评论。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：smix8（Godot 导航维护者、提案作者）。
- 原目录日期：2025-07-01（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot-proposals/issues/12707](https://github.com/godotengine/godot-proposals/issues/12707)

## 概要与项目参考

domino_recommendations: 若实际Floyd分组过大，先研究道路/区域高层连接与局部图版本，再在需要室内追逐/潜入时细化建筑局部区域。
集中导航修改入口能可靠失效缓存；异步结果应带分组/图revision，不能将旧地图路径用于已封闭路线。
保持粗粒度常态交通与少量局部细化；不因navmesh提案迁移当前道路图体系。

## 已有机制分析

source_facts: 提案认为大几何单次烘焙/全世界长路径及GPU几何读取导致性能陷阱，建议自动分块、局部更新和几何缓存。
NavigationWorld统一持有不同agent类型导航图并控制全部修改，从而维护跨块portal/waypoint层级网络和缓存；没有给出最终代码。
NavigationGeometry把静态/动态几何分别优化，共享几何副本；NavigationSeed激活距离范围内块，未加载区仍依高层连接向正确方向走。
作者称重逻辑由NavigationServer后台完成，nodes只是可选前台把手；demo速度与Horizon示例图片均是提案作者展示/主张。

## 后续行为与玩法启发

玩家封路、建筑局部封锁、潜入与室内追逐可改变局部连通，而不把整栋建筑视为等价位置。

运输/犯罪逃跑/合作护送需真实通路与位置推进，块未加载不代表可跳过路障或目击。

## 适用范围与局限

分块降低单次烘焙与局部查询规模，但10000自主NPC均作为seed会使激活区域并集接近全世界。

原作没有万人吞吐、内存、延迟或大幅变更收敛实测，demo描述无硬件/计数，不能转为Domino性能。

后台异步不消除线程锁、geometry parse与跨块同步成本；当前位置有路图而非GPU navmesh问题。

控制数据修改权限使分层缓存可追踪，这是可借鉴的所有权约束；代价是统一入口和版本管理。

静态/动态模式错误仍工作但更慢，需监测配置与缓存失效原因；公共接口越自由越难保证内层一致。

用player附近流式navmesh套到全世界NPC会丢失远程资源竞争与长期运动事实。

未加载块上的高层方向不等于已经抵达、准确ETA或可安全通过。

同源几何不同agent类型图共享烘焙输入，不意味着各类型通行图相同。

全文10531字符提案主帖已读；未读评论/实现PR、核看图片或运行demo。

适用于有精细动态几何的大世界navmesh；当前Domino道路Floyd的真实瓶颈未测，采用应是条件式。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [0c6fc332ba27d5f27754721c.txt](../texts/9b/9bf4188a4c6a28b0b37390152ad7ebdc1b27c3811967ce732656771d4437381e.md) | 讨论正文/已载入评论 | [0, 10531) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md)
- [https://api.github.com/repos/godotengine/godot-proposals/issues/12707](https://api.github.com/repos/godotengine/godot-proposals/issues/12707)
- [https://github.com/godotengine/godot-proposals/issues/12707](https://github.com/godotengine/godot-proposals/issues/12707)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
