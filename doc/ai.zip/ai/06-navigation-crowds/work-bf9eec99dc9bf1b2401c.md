# Recast Navigation README

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/recastnavigation/recastnavigation`。
- 已有内容：文章/文档正文。
- 主要来源：[https://github.com/recastnavigation/recastnavigation](https://github.com/recastnavigation/recastnavigation)

## 概要与项目参考

当前Floyd路网之外，未来局部建筑内潜入/封锁/追逐可细化可走区域，维持常态建筑级模拟；本README不足以授权全面换导航架构。

## 已有机制分析

原文说明三角网格光栅化voxel，移除不可通行区域，再分polygonal regions并重新三角化为navmesh。
Recast生成网格、Detour运行查询、TileCache流式/局部网格、Crowd移动避碰、DebugUtils可视化分模块。
single mesh适合简单静态，tiled mesh支持动态环境重烘焙、层次路径与数据流式。

## 后续行为与玩法启发

犯罪/调查：室内门、走廊和局部封锁影响潜入/追踪/目击，不默认同楼所有空间等价。

欺骗：个人所知路径与世界网格分开，原作未提供知识。

协作/玩家干预：挪动障碍或封门可局部失效路径，仍要执行到场/占用确认。

## 适用范围与局限

tiled结构具有局部重烘焙/流式方向，但文中没有万人crowd预算、tile大小或cache成本。

不能把Crowd命名或industry standard声称当10k全精度证明。

模块隔离有价值；网格更新、碰撞与道路图双层维护增加成本，仅明确场景才引入。

路径查询有效不等于服务完成；Navmesh只编码可行走不能直接表达法律许可。

无局部预算的频繁重烘焙会成为尖峰。

完整4456字符README正文；没有读Detour/Crowd源码、建图图像或性能基准。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [83163ed427b796f79c9a1289.txt](../texts/b7/b70960709ab48e1bd4a20ada20ff2b1a56032f6c6a7fb750cf699595cf777394.md) | 文章/文档正文 | [0, 4456) |

## 原研究概要与相关链接

- [11-open-source-projects/03-navigation-environment/recastnavigation.md](../../ai-reference/11-open-source-projects/03-navigation-environment/recastnavigation.md)
- [https://github.com/recastnavigation/recastnavigation](https://github.com/recastnavigation/recastnavigation)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp#L973-L1018](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp#L973-L1018)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp#L1046-L1110](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp#L1046-L1110)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp#L439-L462](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp#L439-L462)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp#L77-L134](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp#L77-L134)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp#L583-L637](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp#L583-L637)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/License.txt](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/License.txt)
- [https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1](https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
