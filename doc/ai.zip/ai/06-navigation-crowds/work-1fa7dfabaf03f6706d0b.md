# feat!: scale impassable cells to close gaps too small for large actor pathing

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:16a40099ba5a6cc86e95a88b3fbea9fe26c62d94be26aabf90d073e206468ec7`。
- 已有内容：讨论正文/已载入评论。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：BlondeBurrito，仓库所有者、PR 作者及合并者。
- 原目录日期：2023-09-04（沿用已有记录）。
- 主要来源：[https://github.com/blondeburrito/bevy_flowfield_tiles_plugin/pull/32](https://github.com/blondeburrito/bevy_flowfield_tiles_plugin/pull/32)

## 概要与项目参考

Domino建议：移动物理可行性必须考虑体积/通道间隙，路径算法所选路线不等于实际可以通过；未来潜入和室内追逐不能默认同建筑空间等价。
以少数尺寸类别共享缓存可避免每人完整独立流场，但这是工程建议，非PR性能结果。

## 已有机制分析

PR说明新增actor_scale扩大baseline CostFields的不可通行范围，避免很宽actor被FlowField引导穿过两侧255不可通行cell之间的小缝。
可见commit列表另有fix handle actor sizes that span multiple sectors；页面记录2023-09-06合并，完整代码diff未在载体出现。

## 后续行为与玩法启发

玩家摆障碍/封窄门，NPC体型或携带大物体改变可达路径；追捕方与逃逸方可有不同候选路线。

## 适用范围与局限

按尺寸分层CostFields增加缓存/重建成本，跨sector边界需正确合成；PR无万人数量、生成时延或内存数据。

不能将流场局部清障机制直接视为DominoFloyd全图替换依据。

actor_scale领域参数能局部扩展，尺寸变化应失效相关缓存；真实碰撞执行仍需核验。

扩大障碍可能过度封闭可通行细缝或sector边界，原稿只有描述与修复commit标题没有证实算法。

动态拥堵、临时占用、开门权限与体积几何不同，不能一个255cost统一解决。

2934字符PR网页载体全部读完，通用Loading错误未盖过真实描述，但没有源码diff/测试。

短描述机制有效，证据深度不足独立进入高优先级候选。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [16fb7368a3f64591060fc41d.txt](../texts/ec/eccf6a352b54fbe6369c8fc12f5e6eda26475c5b1f129faaff99db77709e2173.md) | 讨论正文/已载入评论 | [0, 2934) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/04-flow-field-shared-destination.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/04-flow-field-shared-destination.md)
- [https://github.com/BlondeBurrito/bevy_flowfield_tiles_plugin/pull/32](https://github.com/BlondeBurrito/bevy_flowfield_tiles_plugin/pull/32)
- [https://github.com/blondeburrito/bevy_flowfield_tiles_plugin/pull/32](https://github.com/blondeburrito/bevy_flowfield_tiles_plugin/pull/32)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
