# AStar-JPS-ThetaStar: Basic algorithms for single-shot grid-based 2D path finding

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/pathplanning/astar-jps-thetastar`。
- 已有内容：文章/文档正文。
- 主要来源：[https://github.com/pathplanning/astar-jps-thetastar](https://github.com/pathplanning/astar-jps-thetastar)

## 概要与项目参考

Domino建议：路线返回必须说明图权重、几何长度、移动方式与版本，不把权重自动作ETA；对未来室内局部潜入/追逐才按需要引入方格。
当前nav为道路Floyd，不能凭此README更换全局算法；共享路线缓存与动态图失效还需其他证据。

## 已有机制分析

源事实：C++11方格中心2D单次查询，BFS/Dijkstra/A*/Theta*/JPS；输入XML定义障碍、起终点、cellsize、启发式/权重、OPEN同f时g-min/g-max。
源事实：实际移动成本始终Euclid，启发式可Euclid/diagonal/Manhattan/Chebyshev；allowdiagonal、cutcorners、allowsqueeze依赖相互定义，Theta*重设父可能违背cardinal-only限制。
源事实：可后处理平滑，Theta*低层路径以line-of-sight重建；日志等级全OPEN/CLOSE每步可能极大。README未解释搜索内部实现。

## 后续行为与玩法启发

封锁巷道、室内障碍、潜入/追捕能采用局部移动条件；合法许可与物理障碍独立，犯罪可穿越受限但真实可达的空间。

目击/调查不由line-of-sight寻路自动完成，需感知范围、遮挡和个人认知；玩家改障碍触发局部路线修复。

## 适用范围与局限

该项目明确single-shot非相似连续多请求复用，10000+每人频繁全格搜索成本未知；局部有限查询预算/缓存才可评估。

full日志按每扩展步存OPEN/CLOSE可大量增长，不能进NPC热路径。

移动拓扑、角落规则、启发式合法性和缩放单位集中定义，避免平滑破坏实体实际可走约束。

示例配置可作为规格参考，未读asearch/theta源码，不把README当算法审计。

Theta*穿斜线打破禁对角约束；平滑穿过实体宽度不够的缝；加权启发式误称最短路保证。

引用文件名pathfinding-js与原页C++仓库不一致，应以实际map URL及正文身份归并。

完整7752字符仓库页/README；未读算法源码、运行、benchmark。与当前道路导航直接契合有限。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [22f7d4d3f5bbf447aa06a4bd.txt](../texts/22/2272caf7c8e32f3abbb0c3c719cfe5f3b8208fc4f40e93a20d6ba8fc76c75523.md) | 文章/文档正文 | [0, 7752) |

## 原研究概要与相关链接

- [https://github.com/pathplanning/astar-jps-thetastar](https://github.com/pathplanning/astar-jps-thetastar)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
