# P&D 过河游戏智能帮助实现

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://blog.csdn.net/DDghsot/article/details/80714784`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：DDghost123（CSDN DDghsot；正文链接 ddghost/unity3d_n 自己的作业实现）。
- 原目录日期：2018-06-16（沿用已有记录）。
- 主要来源：[https://blog.csdn.net/DDghsot/article/details/80714784](https://blog.csdn.net/DDghsot/article/details/80714784)

## 概要与项目参考

可用于Domino极小确定谜题或局部模板的离线可达性检查；当前任务选择/执行需要的信息不完备、中断及真实资源并不在此模型中。
船位不能只由人数代替，是状态键须含影响可行动作的变量的明确例子；角色任务也应保留真正影响执行的进度与占用。

## 已有机制分析

用左岸牧师数P、恶魔数D和船岸布尔位标识状态；五种搬运操作是1P、1D、1P1D、2P、2D，操作加减人数同时翻转船位。两岸均满足无人牧师或P≥D及数量上界才接边。
从初态遍历不断增长的allGraphNodes，生成合法邻接状态并双向接边；提示时用BFS层序扩展，withLengthNode携带首个邻居startNode，找到终态就返回首步人数操作。
作者末尾明确适用已知少量状态/操作/后果，隐藏手牌、随机伤害与状态空间增大不适用。

## 后续行为与玩法启发

适用于渡运/押送小谜题的提示，难提供犯罪、证词、欺骗与社会长期后果；偷渡或劫船还需外加参与者意愿、位置、容量、风险及不可逆效果。

## 适用范围与局限

小人数状态数约2(Pmax+1)(Dmax+1)，若拓展为世界所有实体状态会组合爆炸。

getNodeFromList及visited检查线性扫描；withLengthNode复制邻接List，反复全图构建或万人各图不适合。

代码直接建图/BFS清楚，可用数组索引与visited标记简化小图；不需为Domino引入该Unity类系统。

推荐卡/广告/related snippets完整读过但仅主帖代码可作证据，不能把旁边其它文章摘要算已读。

文中一方面说4牧师4恶魔无解，一方面声称状态合法一定到终点，合法与可达不同。

getNextStep通过getNodeFromList可能把新合法但未连接状态添入图，随后返回无路径；已在终态也没有提前返回，BFS可沿邻居再回终态给出多余动作。

双向接边只因这道搬运谜题可逆；一般交易、盗窃或消费不可自动加逆边。

14165字符完整网页正文读取含推荐/广告；未核图片、Unity演示或链接仓库。

小确定谜题BFS教程，独立价值低于支持真实日常/社交/强玩法生命周期的材料。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [144831683b2a3341f7ee96a9.txt](../texts/87/875076a01278c5f18f2ada82a12dc64894000be6af693019ff4f6db347cfad6e.md) | 讨论正文/已载入评论 | [0, 11500)、[11500, 14165) |

## 原研究概要与相关链接

- [12-community-2016-2026/10-chinese-community/02-csdn.md](../../ai-reference/12-community-2016-2026/10-chinese-community/02-csdn.md)
- [https://blog.csdn.net/DDghsot/article/details/80714784](https://blog.csdn.net/DDghsot/article/details/80714784)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
