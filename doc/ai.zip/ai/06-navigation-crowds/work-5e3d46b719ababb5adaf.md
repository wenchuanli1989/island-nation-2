# SUMO 2024 Tutorial

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://raw.githubusercontent.com/eclipse-sumo/sumo/main/docs/web/docs/Tutorials/2024.md`。
- 已有内容：文章/文档正文。
- 原目录作者：Jakob Erdmann（讲稿自我介绍，SUMO 用户大会教程讲者/项目贡献者）。
- 原目录日期：2024（沿用已有记录）。
- 主要来源：[https://raw.githubusercontent.com/eclipse-sumo/sumo/main/docs/web/docs/Tutorials/2024.md](https://raw.githubusercontent.com/eclipse-sumo/sumo/main/docs/web/docs/Tutorials/2024.md)

## 概要与项目参考

Domino 推论：把路线草案、实际到站、队列容量、搭乘确认及失败恢复分开；行程规划不能直接更新位置或收益。当前 human 仍是占位循环。教程更适合作为导航与执行器错误案例库，不能原样迁入 SUMO 交通栈。

## 已有机制分析

源事实：OSM 场景先生成道路、需求与公交，再用警告定位对象和时间、设置断点、重载及单步调试；几何修复后重建网络，需求亦须重新生成。
源事实：步行→公交→步行计划与 tripinfo 的真实搭乘分开。示例乘客到站3201s，而车3156s已离站；速度因子和损失时间使计划错失实际连接。
源事实：striping 步行模型将道路分条并处理对向空间，仍可能在狭窄入口拥堵；路径随机化只能分散部分负载。JuPedSim 与 non-interacting 模型提供不同互动程度。
源事实：飞行出租车以 taxi 类、空中完全连接网络、停车与步行接入组合；更改容量和 FIFO/最近车派遣分别改变共享能力与空载距离。
作者样例主张：一次场景中 striping 约6000倍实时、JuPedSim约10倍，non-interacting约快10倍；最近车派遣较FIFO缩短约3分钟平均等待。这些数字未复现。

## 后续行为与玩法启发

玩家阻断路口、占用车辆、破坏公交或改变运力，能通过真实排队和到站顺序影响工作与社交承诺；犯罪、目击和处罚须另记。

允许错过公交、改乘、步行绕路、拼车与被抢走服务机会；每项替代须满足真实车辆与场所容量。

## 适用范围与局限

无10000 NPC单机证明。样例倍率强依赖网络、模型和互动范围；JuPedSim在教程版本不与车辆/信号互动，non-interacting不能用于近场碰撞或目击。Domino应只为局部候选维护队列和拥堵，限制查询扇出；示例空中完全连接图随站点数平方增长，不适合直接扩到城市级。

保留导航/需求/执行的版本与实际结果，定位计划失败原因；单步和指标检查不应替代完整业务状态。路径距离、耗时及现实ms明确分开，复制教程以秒表示的仿真时间前须转换到项目合同。

一小时插入需求不保证一小时清空；缺少过街连接可令末班行程耗时超过两小时。

增加随机路径和迎面保留空间不能保证所有种子无堵塞；增加公交也不能保证每个人搭乘成功。

FIFO较公平却可能空载远行，最近车规则可能使远处乘客长期等待；教程没有公平性保证。

飞行出租车由道路权限模拟，不证明飞行动力学或空域安全。

全文41675 raw字符，包含教程文字和完整演示叙述；未观看关联视频、核看地图图像或运行SUMO。

作者版本与基准不能作为Domino运行时性能证据。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [f55113fbafc42a9a137fc969.txt](../texts/7b/7b299ef97239e0d39c9e381642e439487c802de8e631253ccdd836da81f6c915.md) | 文章/文档正文 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 41675) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/08-travel-time-activity-chain.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/08-travel-time-activity-chain.md)
- [https://eclipse.dev/sumo/docs/Tutorials/2024.html](https://eclipse.dev/sumo/docs/Tutorials/2024.html)
- [https://github.com/eclipse-sumo/sumo/blob/main/docs/web/docs/Tutorials/2024.md](https://github.com/eclipse-sumo/sumo/blob/main/docs/web/docs/Tutorials/2024.md)
- [https://raw.githubusercontent.com/eclipse-sumo/sumo/main/docs/web/docs/Tutorials/2024.md](https://raw.githubusercontent.com/eclipse-sumo/sumo/main/docs/web/docs/Tutorials/2024.md)
- [https://sumo.dlr.de/docs/Tutorials/2024.html](https://sumo.dlr.de/docs/Tutorials/2024.html)
- [https://sumo.sourceforge.net/docs/Tutorials/2024.html](https://sumo.sourceforge.net/docs/Tutorials/2024.html)
- [https://www.youtube.com/watch?v=9WCGxJDdY9s](https://www.youtube.com/watch?v=9WCGxJDdY9s)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
