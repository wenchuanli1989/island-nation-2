# Modular Tactical Influence Maps — Dave Mark, Game AI Pro 2 chapter 30

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:http://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Dave Mark。
- 原目录日期：2015（沿用已有记录）。
- 主要来源：[https://gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf](https://gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf)

## 概要与项目参考

Domino 推论：将地点风险/拥挤/服务机会作为有限区域的共享只读查询输入，供有限任务模板选择目标，不让影响图直接结算移动、犯罪或资源。
可由普通 C 实现共享基础数组、静态模板、每 worker 有界临时工作图；事件唤醒时按需局部查询，避免每 NPC 一个全地图。
当前 nav 路径权重不能当物理距离/ETA；作者的 speed×刷新间隔及路径距离启发需建立真实距离/可达时间数据后再使用。

## 已有机制分析

影响图提供空间信息而非动作指令：按 faction 分开 proximity 与 threat 基础图，累加多个 agent 的影响；同一基础信息计算一次，供多个人物查询，替代反复两两距离计算。
影响由位置/射程和响应曲线传播；射击视线可屏蔽不可见格，移动潜在威胁应用路径距离而非直线距离，文中明确路径查询/Dijkstra 预计算的运行与工程成本不可忽略。
预计算不同半径和曲线的归一模板，在更新时以 strength 权重 stamp 加到基础图；按更新间隔与最大速度选择位置模板，威胁范围可分档，边界格须裁剪。障碍多时简单 stamp 不成立。
工作图仅覆盖本次决策相关区域，组合加法/乘法/权重、归一化、反转和兴趣模板；取某点值、局部极值或极值位置分别回答威胁、聚集与目标地点。
原实现每秒清空重填基础图，作者战术场景建议更新间隔约 0.5–2 s；工作图在单线程可复用一块缓冲。减去自己的 proximity stamp 后形成 ally spacing map，与敌我威胁交叠组合，找近处且不拥挤的前线。

## 后续行为与玩法启发

推论：巡逻威慑、潜入路线、逃逸藏身点、群体围捕和避免目击区域可以组合本地风险/视线/路障信息；非法候选仍可进入选择，再依据主观风险评分。

推论：玩家制造火灾/路障、改变守卫布局、提供错误情报会改变局部风险或人物知识图；世界事实图与个体观察/传言须分离，不能把所有 faction 信息默认公开。

原文展示坦克挡在脆弱同伴前、群体施法避免友伤、撤退、前线分散与挡路法术；犯罪应用为本轮扩展推论。

## 适用范围与局限

维护图约需清零全部格、对每活跃 agent 叠其半径平方格，工作图查询约局部面积×层数；全世界细格、很多 faction 或大范围威胁会放大内存/CPU。

预计算曲线消掉重复平方根和响应曲线，但不消掉 stamp 加法、地图刷新、临时组合和路径距离成本；网格精度改变可造成平方级格数变化。

作者仅给两款大型在线 RPG 原型应用背景及几十/几百角色计算讨论，无 Domino 10000 NPC 性能证明；0.5–2 s 是其战术经验，不是普遍刷新合同。

同一工作图单线程复用不能直接交给多线程同时写；Domino 可按 worker/批次复用小缓冲，稀疏活跃区域和不同更新预算须独立验证。

组合式 Add/Multiply/Normalize/Inverse 与共享模板让新查询局部扩展，适合类型 ops；无需先引入通用 DSL。

明确每层语义/来源/时间戳、单位、可见性、模板近似范围与更新责任；归一化丢失绝对威胁大小，不能混作真实伤害或犯罪概率。

室内潜入等需按局部场景细化区域，不能沿用日常同楼免移动就把建筑内风险视为等价。

隔墙猛兽直线距离近，但绕行很远；径向模板会夸大短期可达威胁。

范围模板取整上调造成避得过远，下调可能进入真实攻击范围；作者明确这是设计近似。

共有 faction 地图不等于 NPC 能知道所有敌人；用于调查/潜入会导致全知反应。

未扣自己的 stamp 会错误排斥自己的位置；用归一图代替真实强度会掩盖总威胁变化。

全文读完本地 PDF 提取文字，包含数值图/说明但未核原 PDF 图形布局；公式抽取存在字符错位，未据其精确公式实施。

战术小群体为原文主要范围；开放世界事件调度、存档与个人知识系统不在章中实现。

共用事实图用于主观决策需额外观察权限，不能据原章宣称调查/犯罪因果链已解决。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [60063ee377965db6524bb22c.txt](../texts/9a/9aa8ea5bdcda860d113d3fc405e7f2e7f6324242f2b137cb9cac2f3150ae1c28.md) | 论文/讲义提取文本 | [0, 55144) |

## 原研究概要与相关链接

- [03-world-perception-navigation/08-influence-maps.md](../../ai-reference/03-world-perception-navigation/08-influence-maps.md)
- [https://gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf](https://gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf)
- [https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf](https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter30_Modular_Tactical_Influence_Maps.pdf)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
