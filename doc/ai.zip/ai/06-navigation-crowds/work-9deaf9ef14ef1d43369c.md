# Now flexible routing is at least 15 times faster

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://www.graphhopper.com/blog/2017/08/14/flexible-routing-15-times-faster/`。
- 已有内容：文章/文档正文。
- 原目录作者：Peter（GraphHopper 官方博客作者）。
- 原目录日期：2017-08-14（沿用已有记录）。
- 主要来源：[https://www.graphhopper.com/blog/2017/08/14/flexible-routing-15-times-faster/](https://www.graphhopper.com/blog/2017/08/14/flexible-routing-15-times-faster/)

## 概要与项目参考

Domino 推论：未来路网增长或个人避险权重出现时，可用共享基图下界加请求局部成本覆盖；路线偏好权重不要混成实际 ETA。当前 Floyd 是否需要替换必须按真实图规模判断，本文不证明替换已经必要。

## 已有机制分析

源事实：Dijkstra/A* 可按不同车辆和偏好使用灵活 weighting；优化权重与最终时间估计是不同量。
源事实：landmark 预计算地标到节点距离，以三角不等式生成下界，取多个地标下界的最大值指导 A*。旧表仅在边成本增加时仍有下界保证，降低成本会破坏最优性条件。
源事实：按图拓扑/最远点选地标，并在请求内 QueryGraph 的虚拟起终节点中处理启发式；子网络使用 Tarjan 分析并分别准备地标。
作者规模说法：德国图 16 地标约 550MB，世界图每 profile 约 5GB；使用 2 字节距离和区域划分控制大小。文中 16/32/64 地标平均 72/46/33ms，相比 A* 1.2s，CH 平均仍快约十倍。

## 后续行为与玩法启发

临时封锁、危险区域和玩家设路障可增加个人路线成本而保留安全下界。

犯罪者、调查者和商人可对同一路网有不同风险偏好；个人以为安全与真实通行条件分离。

新道路、优惠通道或玩家开门降低成本时，启发式需重建或切换到仍正确的算法。

## 适用范围与局限

这些为 2017 年 GraphHopper 作者内部测量，硬件/完整查询条件未在本轮复现；不是 10000 NPC 路由吞吐。地标表按节点数×地标数×profile 数占内存，不能给每个人复制一套；新增捷径和频繁降价会触发重建成本。

明确每个 cost 的单位与最低基准，动态覆盖仅请求局部保存，图修订号与下界版本配对。将连通性、启发式正确性和权重/ETA 分开；不要为 16 位表示而人为切断 Domino 世界的真实道路。

降低边权或增加更短路径会使旧地标估计超过真实最短成本，A* 可能给非最优解。

临时虚节点若启发式不识别起终边位置，会得到错误估计或退化。

地标太少/分布不佳或强动态成本使搜索退化，不能把标题 15 倍当所有查询保证。

道路只增风险的假设不覆盖抢修、折扣、开门或玩家新建捷径。

完整读完 11368 字符文章载体；图像、图表排版和关联实现未核看。

作者性能与内存说法未复现，不可直接外推到当前 Domino/Floyd。

正文涉及商业库旧版本，本文推荐的是算法条件而非当前产品规格。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [52037e3cf5cceee05a4b0ca5.txt](../texts/10/102b940e1f5cb4c8b15b3ae92d62bb0638d7d8a16db669c570fb02f080ff504d.md) | 文章/文档正文 | [0, 11368) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/09-environment-reachability-cost.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/09-environment-reachability-cost.md)
- [https://www.graphhopper.com/blog/2017/08/14/flexible-routing-15-times-faster/](https://www.graphhopper.com/blog/2017/08/14/flexible-routing-15-times-faster/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
