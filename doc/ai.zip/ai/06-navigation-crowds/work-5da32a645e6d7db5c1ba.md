# A comparison of SUMO’s count based and countless demand generation tools

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:cb3e10fb426a7b9cc86d4d63092133f0955147adc060607f5f71471e72b6b65c`。
- 已有内容：正文/源码节选。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Michael Behrisch; Pauline Hartwig。
- 原目录日期：2021-09（沿用已有记录）。
- 主要来源：[https://tib-op.org/ojs/index.php/scp/article/download/107/278](https://tib-op.org/ojs/index.php/scp/article/download/107/278)

## 概要与项目参考

二级场景数据与导航负载参考。当前Nav只是路径查询、weight不是距离/ETA，无移动/需求闭环；当前Human家庭/公司address与Building用途可成为活动目标入口，但交通生成文件不提供人物意愿、执行、到达、占用或存档。

## 已有机制分析











## 后续行为与玩法启发

工程推论：合理居民与跨区通勤流可为护送、追逃、封路、伏击和货运路线创造空间机会；需实际可追踪人物与路线，不能从计数曲线生造目击或犯罪历史。

玩家改变工作地点、运输服务、道路可通行性或经营地点后，未来任务与真实移动可改变交通；计划校准不能立即结算工资、消耗或到达。

主路计数匹配而次路空白可提示玩法机会分布失衡；评估并不自动生成真实支线活动。

## 适用范围与局限

10,000/50,000是输入人口，不是同时运行的完整NPC行为数量，更不是CPU/RSS/吞吐证明。

cadyts100步为校准迭代，属场景生成成本，不可推广为实时万人规划策略。

论文基于小conurbation高峰小时与有限计数，不能保证完整开放世界全天需求、犯罪感知和社会互动规模。

Floyd矩阵与当前Nav动态失效成本未由这些生成工具解决；统计负载适配不能证明导航代码已编译运行。

可把人口/地点/路线候选生成作为离线内容管线，运行时仍通过普通C任务模板和执行器使用稳定ID。

保留生成参数、区内/区际模式、候选路线与校准数据来源，避免人口数量与旅行量混为同一配置。

未完成cadyts校准应标为本研究限时结果，不能宣称工具一般失败。

同时统计流量误差和空间覆盖，不能仅优化一个指标。

增加人口五倍仍产生不可信需求，周边通勤缺失并非简单人数修复。

只拟合检测主路会留下未测次级路网的系统偏差。

routesampler匹配输入计数不保证真实OD或个人行程；需留出评价和机制检验。

生成轨迹不等于真实NPC旅行、资源结算、目击事件或犯罪结果。

single-taz模式选择错误会漏掉区内需求；路网输入本身仍需人工适配。

本人仅读p1/4/5双版本，p2/3/6/7其他reader覆盖；不声明整篇个人全文阅读。

没有查看PDF图像和第6页结果表，不引用具体RMSE数值或车辆统计。

身份URL来自分配清单及第1页DOI，不联网校验当前网站。

两个raw PDF路径相同SHA归并为同一作品，未重复计数。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [169b32b56d037202a286.txt](../texts/ec/ec05a6d2dddd8ae75e70dad394541b2abed9baa7e29ea2422cc66074421056e4.md) | 正文/源码节选 | [0, 11000)、[11000, 20502) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/08-activity-transport.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/08-activity-transport.md)
- [https://doi.org/10.52825/scp.v2i.107](https://doi.org/10.52825/scp.v2i.107)
- [https://sumo.dlr.de/hugo/2021/](https://sumo.dlr.de/hugo/2021/)
- [https://tib-op.org/ojs/index.php/scp/article/download/107/278](https://tib-op.org/ojs/index.php/scp/article/download/107/278)
- [https://www.tib-op.org/ojs/index.php/scp/article/download/107/278](https://www.tib-op.org/ojs/index.php/scp/article/download/107/278)
- [https://www.tib-op.org/ojs/index.php/scp/article/view/107](https://www.tib-op.org/ojs/index.php/scp/article/view/107)
- [https://www.youtube.com/watch?v=o8h8dUrqpTM](https://www.youtube.com/watch?v=o8h8dUrqpTM)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
