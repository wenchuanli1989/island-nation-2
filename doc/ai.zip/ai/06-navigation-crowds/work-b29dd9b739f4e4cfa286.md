# Spatial Partition — Game Programming Patterns

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://raw.githubusercontent.com/munificent/game-programming-patterns/master/book/spatial-partition.markdown`。
- 已有内容：文章/文档正文、论文/讲义提取文本。
- 当前前100：第 25 项；[空间划分：局部候选与密度退化](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/025-b29dd9b739f4.md)。
- 原目录作者：Robert Nystrom。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://raw.githubusercontent.com/munificent/game-programming-patterns/master/book/spatial-partition.markdown](https://raw.githubusercontent.com/munificent/game-programming-patterns/master/book/spatial-partition.markdown)

## 概要与项目参考

直接契合Domino扁平数组+ID索引：空间桶只保存ID/索引，供附近设施、求助者、交易对象、目击者候选查询；不用把主存储迁到链表。
地域用于候选筛选/调度维度，与一地域一线程无关；执行提交真实移动后更新索引，规划读取对应发布版本。
同楼常态简化可保留，但潜入/追逐/目击须按局部区域与距离/遮挡进一步筛选，不能仅同cell即认定可见。

## 已有机制分析

按位置建立辅助空间结构，把全体两两O(N²)候选查询拆到局部桶；固定grid按坐标/格大小算cell，跨cell移动时移出旧桶再加入新桶。
范围交互需扫描邻cell并做实际距离检验；无向成对交互只取半邻域防重复，作用半径超过格大小则扩展多圈。
固定平面grid更新简单但空格多/拥挤退化；层级自适应可处理密度差，BSP/k-d等对象依赖分区有重平衡成本，quadtree固定边界、密度触发细分。
空间索引可作第二缓存而非实体主存储，保留顺序主数组方便全体遍历，创建/删除/移动同步索引。

## 后续行为与玩法启发

crime:
盗窃和袭击的可能目击者可从附近格查询，候选位置不是已经目击。

deception_investigation:
声音/旁听及追捕可限定范围；证词真实性和识别另由知识/事件层决定。

cooperation:
局部工作/交易/援助候选查询，避免全体互配。

player_interaction:
玩家改变位置、遮挡或路线会改变可互动候选，不改变未发生的历史。

犯罪实际发生后只查附近有感知机会的NPC，再按视线、警觉、知识更新目击记录；玩家改变路线、遮挡、警报范围可改变发现概率。

局部交易/协助/搜索与追捕避免全世界广播；空间索引只提供候选，不自动裁决违法性或转移资产。

## 适用范围与局限

均匀低密度时大幅缩小候选；全体挤同格时仍 O(N²)，输出本身若很多也无法保证常数查询。

过小格导致扫描大量空格，过大格导致格内配对多；更新与二级缓存额外耗 CPU/内存。

双向 pair 去重仅适用于对称关系；方向感知或不同半径要各自检查。

原文对 quadtree 一次插入最多一次 subdivision 的示例主张有条件；重叠点/深度与容量边界需明确，不能当通用最坏界。

10,000人物全两两约50M无向对；分区能把典型查询限制到邻桶，但拥挤同cell仍退回O(N²)，须控制候选数或拥挤区域细分。

内存包含桶头/成员链接，动态更新有代价；空世界大grid遍历也昂贵，可记录非空桶或按查询取桶。

原章没有具体万人实测；quadtree说单次插入只一次细分并不覆盖同坐标/无限细分，项目需最小格尺度与拥挤上限。

实体真值与空间缓存保持单一更新入口，增删和移动不允许漏同步。

Domino 应采用数组/ID 友好的成员布局，原文教学链表不必原样复制。

只有实际性能/密度需求触发分层结构，避免过早树索引。

移动、创建、删除、压缩数组、加载重建时集中维护索引不变量；用稳定ID避免kvec移动令链接失效。

先固定grid或建筑级桶，实际密度/查询超预算才升级层级；明确point/query/radius版本及索引拥有者。

半邻域去重仅用于对称关系；有向攻击/单NPC查询不得机械减半漏目标。

只查同格漏掉格边界两侧近邻。

任意扩大交互半径却只查一圈邻格会漏事件。

扫描全部八邻格并同时处理同一对会重复结算攻击。

实体跨格但未更新索引会被双方漏掉；所有人聚集同格退化。

邻桶漏扫会遗漏跨边界目标；大半径只扫一圈也会遗漏。

拥挤人群共享坐标时细分不一定减少候选；grid与自适应结构都不能自动解决真实N²交互。

源码使用^code占位，实际原样代码未包含，不能据此称完整源码审计；图像只读alt说明。

完整读书籍源 Markdown；^code 标记引用的 C++ 代码片段未展开，本载体不证明具体实现已读。

只读图像 alt/正文解释，未核看全部插图或运行任何例子。

复杂度是教材分析，未给 Domino 万级实测；缓存一致性、负坐标 floor 和并发细节须项目自行定义。

完整原始Markdown章节已读，代码^code指令未展开，图片未核看；不能宣称读完全部实现。

作者机制是复杂度推理而非Domino万人测量。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [89680197a9b6063eaf6dd4e1.md](../texts/ca/cabe529bc5d1a1b464c7ac1207f30f74ea366dbdbd8a86a36203d29a9d1a7581.md) | 论文/讲义提取文本 | [0, 12000)、[12000, 24000)、[24000, 25663) |
| [89680197a9b6063eaf6dd4e1.txt](../texts/e0/e0aa97b426d8f5a6753d07f8744679720c5302b97e589d888a9f499cbd379778.md) | 文章/文档正文 | [0, 12000)、[12000, 24000)、[24000, 24820) |

## 原研究概要与相关链接

- [03-world-perception-navigation/07-spatial-queries.md](../../ai-reference/03-world-perception-navigation/07-spatial-queries.md)
- [https://raw.githubusercontent.com/munificent/game-programming-patterns/master/book/spatial-partition.markdown](https://raw.githubusercontent.com/munificent/game-programming-patterns/master/book/spatial-partition.markdown)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
