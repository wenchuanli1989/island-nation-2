# How to make NavigationAgent2D to use a Warp Point to go faster

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：cidwel（Godot 4.X 使用者）；smix8（Godot 导航维护者，答复者）。
- 原目录日期：2024-05-18（沿用已有记录）。
- 主要来源：[https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6)

## 概要与项目参考

Domino 建议：特殊连接的资格、实际耗时与宏观路径成本显式表示；局部走路与跨区域的高层连接分开。
路径缓存需随道路、连接可用性或成本改变失效；计划选择更便宜的路线不等于已完成移动。

## 已有机制分析

原文单条 Godot 论坛回复（2024-05-18）称默认 AStar / NavigationAgent 不能可靠处理传送门；这是该时点回复者主张，未验证当前 Godot。
原文建议建立传送门高层映射和缓存路径成本，查询时比较传送路径与普通路径，并选择当前位置更好的路线。

## 后续行为与玩法启发

隧道、渡船或走私入口可成为有条件捷径；玩家关闭入口、改变收费或散播错误地图能改变选择。

## 适用范围与局限

高层缓存可能减少重复寻路，但回复没有节点数、算法、缓存粒度、更新成本或万人测试。

把每个个体/每次查询都枚举全世界捷径可能仍昂贵，局部候选与复用是项目建议。

统一普通边与特殊边的成本、方向和资格，维护明确失效条件；不要以一条论坛回复约束当前自有引擎实现。

可达性、等待时间和使用条件变化会使缓存成本失真；门户不能只按直线距离比较。

未知捷径不应因客观图可达自动写入人物知识，回复没有讨论信息范围。

只读该完整回复载体，不是整个论坛线程、Godot 文档或源代码；当前版本情况没有联网确认。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [2898891a5ddd830b7f7f7b63.txt](../texts/09/09e0740bfc141a79ba077421daca8e426e2afa23154d3da3ce904c28881620c3.md) | 讨论正文/已载入评论 | [0, 513) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md)
- [https://forum.godotengine.org/t/62084.json](https://forum.godotengine.org/t/62084.json)
- [https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084)
- [https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6)
- [https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/8](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/8)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
