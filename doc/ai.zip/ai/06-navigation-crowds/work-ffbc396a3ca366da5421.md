# Godot PR #87378 — NavigationMesh border_size for tile baking

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:a7cb4f9862f79251d696bbcef5003e14bdea426fbf8d2d52a01d15594fd0de2f`。
- 已有内容：讨论正文/已载入评论。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：smix8（Godot 导航贡献者及 PR 作者）；Scony、AThousandShips（审阅）；akien-mga（合并）。
- 原目录日期：2024-01-19（沿用已有记录）。
- 主要来源：[https://api.github.com/repos/godotengine/godot/pulls/87378](https://api.github.com/repos/godotengine/godot/pulls/87378)

## 概要与项目参考

具体局部导航分块边界机制，有维护/局部精细模拟参考；不属于当前human近期任务主问题。

## 已有机制分析

source_fact: baking AABB限制源几何范围，border_size限制最终mesh surface；border_size>agent_radius，AABB恰扩大border_size；ReCast按voxel cell ceil，edge_max_error≤1等帮助tile边缘对齐并用edgekeys合并。
domino_recommendation: 若未来局部室内导航采用网格，区分源几何重叠边带与最终tile范围，保证边界连通；当前Domino道路图/Floyd不能直接接此属性。

## 后续行为与玩法启发

潜入、封锁与室内追逐可在必要建筑局部启用细分nav，保持常态建筑级模拟；跨tile边界不能丢失路线。

## 适用范围与局限

局部tile重建可控空间更新范围的推论，但材料没给万级NPC查询/烘焙时长。

全世界mesh预生成及Godot迁移不必要；目前Nav直接边和Floyd另有成本。

采样cell_size与agent_radius都是几何单位，别当业务ms/ETA。

参数组合与边界身份需一致，维护独立邻接缓存失效。

仅裁AABB会因agent radius收缩留缝；border不足或不ceil对齐会无法按edgekey合并。

图片未读，不能从文本断言某图细节或实际修复成效。

全文[0,1904)PR描述；未读diff或链接图片，未运行烘焙。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [bb941c0d60538a7a5dcc355b.txt](../texts/b1/b17d552d141799edd2c6822ff4d176b0fe1560a70d4db94b9981d10a433a73f7.md) | 讨论正文/已载入评论 | [0, 1904) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/01-dynamic-navmesh.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/01-dynamic-navmesh.md)
- [https://api.github.com/repos/godotengine/godot/pulls/87378](https://api.github.com/repos/godotengine/godot/pulls/87378)
- [https://github.com/godotengine/godot/pull/87378](https://github.com/godotengine/godot/pull/87378)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
