# D* Lite

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://idm-lab.org/bib/abstracts/papers/aaai02b.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Sven Koenig; Maxim Likhachev。
- 原目录日期：2002（沿用已有记录）。
- 主要来源：[https://idm-lab.org/bib/abstracts/papers/aaai02b.pdf](https://idm-lab.org/bib/abstracts/papers/aaai02b.pdf)

## 概要与项目参考

Domino 建议：频繁封路/设施损坏时可把规划缓存失效细化成受影响请求的局部修复；道路实际状态与 NPC 已知通行信息独立建成本视图。
当前 nav 是 Floyd 全图方案，是否采用 D* Lite 应由图规模、变化率、共同目标与内存预算触发；论文不能自动证明应替换现有导航。
任务生命周期需要让阻断事件唤醒 MOVE 并决定等待/改路/失败；修复完成只给路线，不确认实际到达或推进其他效果。

## 已有机制分析

LPA* 保留每节点 g 和一步 lookahead rhs；g==rhs 为局部一致，优先队列只包含不一致节点。边权改变后更新其影响节点，启发式只修复当前目标路径相关区域。
D* Lite 将搜索反向为目标到移动起点的距离，使人物向目标前进时复用结果；需能枚举有向图前驱与后继。
机器人移动使启发式 key 改变，使用累计 key modifier 保存旧 key 的下界，弹出后重算并必要时重新入队，避免每次移动全堆重排。
允许边成本增加/降低及知识修订；首次搜索等价于一定 tie-break 的 A*，后续只传播受影响或尚未计算的值。论文按节点扩展、访问和堆上滤次数比较，分别去掉增量与启发式做消融。

## 后续行为与玩法启发

玩家封路、破坏桥梁、开门、解除封锁可以引发有依据的改路。潜入者依据自己发现的障碍重规划，侦察与虚假道路情报能改变主观路线而不篡改真实边。

逃亡/追捕可利用路线阻断与未知区域；移动追捕目标频繁改变终点时原固定目标复用优势会降低，需要明确切换/放弃策略。

## 适用范围与局限

每个独立搜索上下文有 g/rhs/堆，若一万人各复制全图是 O(NV) 内存并可能 O(N*repair) 峰值；优先仅活跃路径、局部子图、共享相同目标和成本视图、合并边变化。

局部修复优势依赖相似重复问题；广域变化或不相关目标仍可能触及大图，论文每次节点最多两次扩展不表示修复恒定时间。

实验为单机器人随机网格/自适应离散化，记录操作次数而非万人 CPU 延迟；部分场景启发式优势不显著，映射场景个别计数例外。

保持两个值和队列成员/优先级不变量；用稳定 node ID 和 nav revision，禁止跨 kvec 扩容留借用指针。

边变更需更新正确端点并支持前驱访问；路径权重、物理距离、现实 ETA 和权限风险不要混同。

旧 key 机制依赖非负一致/三角不等式启发式；政策/风险成本视图不满足下界时不能沿用最短路正确性宣称。

人物拥有不同权限、危险偏好、已知地图时不能无条件共享同一个缓存树。

追捕终点持续移动、全城灾害、首次陌生目标会削弱历史复用；预算不足时必须明确路径尚未完成，不能使用旧路径宣告行动成功。

格网 8 邻居 cost=1 是实验设置，不能当 Domino directed road、距离或时间合同。

图节点太粗看不到小通道，过细导致图膨胀；局部室内玩法需有必要精度。

PDF 抽取全文已显示 [0,48356)，正文可读，但公式/伪代码含严重编码损坏，图形未核看；完整读文字不代表正确核验每个数学符号。

未复现实验、未审计现有 nav 实现，本轮性能与项目映射是受限设计评估。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [346740e7df2b36df95563991.txt](../texts/5d/5d41ca01bbc389ce2319b90847a7b3f57f59cfda2c4d995d6ff9f8a21e0a92d1.md) | 论文/讲义提取文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 48000)、[48000, 48356) |

## 原研究概要与相关链接

- [03-world-perception-navigation/05-hierarchical-pathfinding.md](../../ai-reference/03-world-perception-navigation/05-hierarchical-pathfinding.md)
- [03-world-perception-navigation/09-environment-change.md](../../ai-reference/03-world-perception-navigation/09-environment-change.md)
- [https://idm-lab.org/bib/abstracts/Koen02e.html](https://idm-lab.org/bib/abstracts/Koen02e.html)
- [https://idm-lab.org/bib/abstracts/papers/aaai02b.pdf](https://idm-lab.org/bib/abstracts/papers/aaai02b.pdf)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
