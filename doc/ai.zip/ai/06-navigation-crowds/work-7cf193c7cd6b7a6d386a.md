# Godot issue #82560 — navigation arrival flag

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/godotengine/godot/issues/82560`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：ershn；Godot 问题报告者，正文自述已定位源码原因并准备修复 PR。
- 原目录日期：2023-09-30（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot/issues/82560](https://github.com/godotengine/godot/issues/82560)

## 概要与项目参考

Domino建议：执行者使用当前主体位置、目标位置/版本和任务要求确认到达；路径规划完成只产生候选路线。
目标变更、最后一段移动及移动失败分别返回原因，防止到达等待永久挂起或错误结算。

## 已有机制分析

路径耗尽、最终路径点接近与主体实际目标到达是不同条件，不能把单一缓存flag替代物理确认。

## 后续行为与玩法启发

追捕目标移动、交易双方会面、门边潜入和协作占位需要不同到达合同；不是任意路径done即完成。

## 适用范围与局限

本地距离检查较小，但是否每NPC每帧触发应按实际移动/目标变更决定；本文不提供调度策略。

路径版本与目标版本分离；保存恢复后重新校验位置，不保存不可重建的到达缓存作为事实。

threshold不一致可提前结束路径更新但仍未满足真正目标；反向把路径终点当目标也会误判到达。

关闭issue/里程碑不证明修复代码行为，必须单独核查#82561实现。

全文读报告2992字符；未运行Godot，未读修复PR，不判断当前版本。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [c7ccb26fa127e91447c852be.txt](../texts/5b/5bd30633dc5a0bbab6ddab6f25989f42d188314787afe033681edda9b9969416.md) | 讨论正文/已载入评论 | [0, 2992) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/07-navigation-failure-handoff.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/07-navigation-failure-handoff.md)
- [https://github.com/godotengine/godot/issues/82560](https://github.com/godotengine/godot/issues/82560)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
