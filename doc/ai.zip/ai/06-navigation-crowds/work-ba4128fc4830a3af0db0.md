# Implicit Crowds: Optimization Integrator for Robust Crowd Simulation

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:eb72c9ee55a110a2aaa4a09e3e9628aadc1a22e8f565e6a3a565fb5ce324d7b0`。
- 已有内容：论文/讲义提取文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Ioannis Karamouzas; Nick Sohre; Rahul Narain; Stephen J. Guy。
- 原目录日期：2017-07（沿用已有记录）。
- 主要来源：[https://www.cs.ucr.edu/~ioannis/implicit-crowds/](https://www.cs.ucr.edu/~ioannis/implicit-crowds/)

## 概要与项目参考

Domino建议：global nav/Floyd只给路线，局部移动执行者另处理共享通道容量、拥堵/避碰；到达需要实际位置确认，路线权重或计划时间不能替代到达。
Domino建议：优先把TTC、连续最小间距和有界邻居查询作为可检验独立机制；全局非线性求解只考虑必要的密集互动场景，不能直接套到全部日常NPC。

## 已有机制分析

源事实：把所有圆盘人物的速度组成2m维变量；外部路线提供目标速度，动量项、目标速度势、平滑预计碰撞时间势与距离屏障共同构成后向Euler优化目标。预计碰撞时间来自相对位置/速度的圆盘交叉二次方程，远期冲突被截断衰减。
源事实：为去除速度障碍边缘不连续，对逆TTC作线性外推和平滑；对一步内最小间距而非仅末态距离设置无穷屏障，避免穿透。以零速度作为可行初值，Armijo线搜索不接受无穷能量状态，L-BFGS更新近似Hessian并有限迭代/阈值停止。
源事实：实现限定起始时刻10m内的交互对，常用100次优化、5步记忆；论文测试交叉流、走廊、2000人街区、1200人疏散及随机场景，展示车道/拉链/旋涡等流动现象并与人群轨迹离群点比较。

## 后续行为与玩法启发

Domino建议：市场出口拥堵、玩家设置路障、撤离与护送可产生可观察的通行/等待后果；局部空间细化可支持追捕、藏匿和封锁。

源限制与建议：追逃、领随属于非对称力，作者说明不能直接放入相对速度对称势；犯罪目标与风险判断须由上层任务产生，局部求解只维持几何可行性，不推导谁发现或举报。

## 适用范围与局限

源事实：6核3.5GHz Xeon实验称测试场景>10Hz、100ms及以上步长实时；随机实验绘到5000人，固定0.25s时近线性增长。该结果无10000个完整决策人物证明。

源事实：全体同步全局求解比ORCA/PowerLaw慢2-10倍；无法直接异步/不同更新率。密度升高会增加邻居数和梯度计算，约 O(I*(N+E))，若E接近N²则不再线性；此复杂度是Domino工程推论。

Domino建议：需要空间邻域与明确局部块交界更新契约；减少迭代虽不穿透却可能人为减速，不能用作可信的通行时间或犯罪结算。

源事实：需解析能量梯度，L-BFGS比完整稠密Hessian省内存；调半径与迭代数改变行为组织度。

Domino建议：若引入应独立为移动执行子系统并暴露停滞/完成/中断原因，避免中央任务执行器实现数学求解或每种追逃专分支；动态障碍与初始重叠需要额外明确约束。

源事实：无碰撞证明依赖初态无碰撞、无移动障碍保证零速度可行；步内线性轨迹假设在4s步长下使人群流速下降。

源事实：少迭代导致速度接近0；缩小邻居半径改变组织性；逃跑/领随的非对称影响只能显式积分，大步长可变得不平滑。

Domino推论：分片或超出邻居范围的高速相遇若未做跨块连续检查，不能沿用整群原始无碰撞保证；几何通过并不等于物品交换、伤害、目击或合同履行成功。

完整读76708字符PDF提取文本；未核看图像/补充视频、未读补充数学推导或实现。

文字有连字提取错误，但公式/算法/限制可读；不等同本轮运行或万人性能复现。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [022bb2efc57819fe8e72a968.txt](../texts/0b/0b94585846dd04fcf8feee194cb609c242a5df6438eae7b232c480f195c88463.md) | 论文/讲义提取文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 46000)、[46000, 57500)、[57500, 69000)、[69000, 76708) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [796c04d5a62e3e91c28217cf.txt](../texts/b5/b5ec5cada76515f4098861946abcd4e33aa7de5a187fbeb760c7974d18708e98.md)

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md)
- [https://github.com/johnoriginal/implicit-crowds](https://github.com/johnoriginal/implicit-crowds)
- [https://www.cs.ucr.edu/~ioannis/implicit-crowds/](https://www.cs.ucr.edu/~ioannis/implicit-crowds/)
- [https://www.cs.ucr.edu/~ioannis/implicit-crowds/files/implicit_crowds.pdf](https://www.cs.ucr.edu/~ioannis/implicit-crowds/files/implicit_crowds.pdf)
- [https://www.youtube.com/watch?v=9SVC7XBhBpk](https://www.youtube.com/watch?v=9SVC7XBhBpk)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
