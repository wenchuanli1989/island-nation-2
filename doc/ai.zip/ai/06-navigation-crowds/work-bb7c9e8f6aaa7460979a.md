# PyQuadTree 0.2 — TalkTown vendored pyqtree/__init__.py

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:142ccf961ee09eb835786a5f99311cafacb2a4df98dbf783a775c2dac7a14ad6`。
- 已有内容：源码/工程文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 主要来源：[https://raw.githubusercontent.com/james-owen-ryan/talktown/e8751ffa05def902dbc956852dad10e866b578d8/pyqtree/__init__.py](https://raw.githubusercontent.com/james-owen-ryan/talktown/e8751ffa05def902dbc956852dad10e866b578d8/pyqtree/__init__.py)

## 概要与项目参考

current_baseline: Domino有位置/导航与扁平数据，但human没有局部感知/候选查询。
domino_recommendation: 借用先空间粗筛、再领域细筛、按ID去重的接口，把可访问人物/服务/资源限制在少量邻近候选。C实现可先选择建筑/地区桶或固定网格，只有测得热点才引入四叉树；按场景细化室内区域而非全世界细粒度。

## 已有机制分析

source_fact: insert先归一化bbox，在叶节点存item+rect；超过MAX=1且depth<3就拆四子节点，将既有矩形再插入。
source_fact: 跨中心两轴的矩形留在父级，跨一轴可进入多个孩子；查询按bbox与中心选择子树，再精确判断rect重叠，用set按item去重。
source_fact: Index以总bbox创建中心/宽高；intersect返回命中对象，countmembers递归数节点，模块末自带1000随机对象计时示例。无remove、move或动态发布接口。

## 后续行为与玩法启发

建议：犯罪潜入/目击、调查访问、追逐、援助或交易用局部候选；空间重叠只证明可进入感知范围，不证明已看见、知道或合法。

建议：玩家封锁局部区域后只唤醒受影响实体；观察需另加视线、权限、注意力与信息来源，合作意愿也不能从邻近直接推定。

## 适用范围与局限

固定MAX_DEPTH=3最多64叶，热点/覆盖大区域的bbox仍可使查询O(N)；跨子树重复存储增加内存和去重成本。

没有动态更新；万NPC移动若每次重建整树会抵消局部查询收益。可维护迁移桶/批更新或读快照索引。

末1000随机对象脚本只是源码示例，本轮未执行，且分布均匀不能证明密集城市/长矩形场景。

规范bbox边界和ID去重，分清物理粗筛与制度/主观过滤，便于增加多种活动。

将索引持有ID/版本而非跨kvec扩容裸指针；个人任务不拥有整棵空间树。

countmembers数储存节点可能包含跨孩子重复对象，不能当唯一NPC数量统计。

大bbox留父级导致所有局部查询都扫它们；拥挤小区域在深度上限内退化。

混合严格/非严格重叠比较在边界/零面积点上有特殊结果，需明确单位/边界合同后采纳。

此文件只有空间索引，不能据TalkTown仓库名声称其记忆、谎言或社交机制已经通读。

完整7304字符抽取代码与文档；文本缩进已丢失，未运行/做语法校验或读TalkTown其余模块。

只覆盖该空间索引模块载体，不等于整项目源码审计。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [dc35b4630eada697e0fb9546.txt](../texts/b3/b3bc8eb0aa9299d45670f571a73e8727d51e67ce4a576e14fbd83dec59caa38b.md) | 源码/工程文本 | [0, 7304) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [dc35b4630eada697e0fb9546.repaired.txt](../texts/36/36f5d2534bf875faafae8d1c095da7065976048ba80b5b9efa3af188d1eeea40.md)

## 原研究概要与相关链接

- [https://github.com/james-owen-ryan/talktown/blob/e8751ffa05def902dbc956852dad10e866b578d8/pyqtree/__init__.py](https://github.com/james-owen-ryan/talktown/blob/e8751ffa05def902dbc956852dad10e866b578d8/pyqtree/__init__.py)
- [https://raw.githubusercontent.com/james-owen-ryan/talktown/e8751ffa05def902dbc956852dad10e866b578d8/pyqtree/__init__.py](https://raw.githubusercontent.com/james-owen-ryan/talktown/e8751ffa05def902dbc956852dad10e866b578d8/pyqtree/__init__.py)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
