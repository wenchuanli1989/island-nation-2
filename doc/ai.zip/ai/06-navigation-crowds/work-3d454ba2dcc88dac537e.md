# NavigationAgents' `is_target_reached` returns `false` even within `target_desired_distance` to the `target_position` · Issue #82560 · godotengine/godot · GitHub

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:77a92eb154c5cbbf0f297ea64f531e7cdcbb346145bf4e59cde4ca926d78c661`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：ershn；Godot 问题报告者，正文自述已定位源码原因并准备修复 PR。
- 原目录日期：2023-09-30（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot/issues/82560](https://github.com/godotengine/godot/issues/82560)

## 概要与项目参考

闭合本地残差文字阅读/来源定位；不重复统计既有独立作品。

## 适用范围与局限

本补片不单独提供万级NPC性能证据。

全文对照paired：两距离阈值、最后waypoint后距离检查不再运行、复现步骤均已有；只是backticks/编号/附件链接差异。

不能把标题、摘要、链接、提议或社区报告提升为原作品完整机制/代码/运行证明。

语义对照确认核心段落已在旧paired正文；标记/链接格式差异不能创造新正文缺口。

已读完整所分配残差；未读的全篇/外链/图像/附件仍保持缺口，原paired载体其他读者覆盖须由根汇总。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [c7ccb26fa127e91447c852be.txt](../texts/f1/f1bebc4d1a21534c328527cf262a3815a978e136764b67b9d564cf856cb9ca98.md) | 文章/文档正文 | [0, 918) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/07-navigation-failure-handoff.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/07-navigation-failure-handoff.md)
- [https://github.com/godotengine/godot/issues/82560](https://github.com/godotengine/godot/issues/82560)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
