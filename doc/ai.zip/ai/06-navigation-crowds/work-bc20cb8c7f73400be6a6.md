# [2022 TGDF] 挑個好位置：頑皮狗的崗位系統 (周明倫) — 40-page document text

- 分类：导航、人群、交通与空间协调。
- 资料标识：`youtube:eNGg0zjaifk`。
- 已有内容：文章/文档正文。
- 原目录作者：周明倫 / Ming-Lun “Allen” Chou（Naughty Dog）。
- 原目录日期：2022-07-16（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=eNGg0zjaifk](https://www.youtube.com/watch?v=eNGg0zjaifk)

## 概要与项目参考

Strong direct mechanism for local candidate selection, believable investigation and bounded expensive work. Current baseline has no spatial bucket/eye-witness logic and coordinate route endpoints still O(V); posts can provide semantic locations, not replace movement executor or Floyd contracts.

source_fact:
只有课程简介和完整可见5条Q&A，课程主体和幻灯片未在载体。log n为讲者主张，未见树平衡/基准条件。

domino_recommendation:
可参考动态候选位置索引、fat bounds及有预算的请求队列；C23线程批处理不等同协程，队列延迟用现实_ms预算和实际硬件而非1–3帧照搬。当前无需自家Lisp编译器。

Domino建议：对有价值的局部地点查询缓存保守包围范围，移动越界或岗位属性改变再更新；查询结果仍需当前版本/可达性/占用校验。

Domino建议：短请求预算除吞吐还测 enqueue→首次处理→完成现实 ms 和最长等待；1–3 帧不是跨硬件通用上限。

## 已有机制分析

source_facts:
Posts are generated from nav mesh/ledge, tools/collision data or manually/runtime. Scenario selector combines 0..1 criteria by product; zero rejects and small positive values discourage while preserving options. Cheap criteria precede expensive ones, stopping at zero.

Bottle investigation selects first corner with sight to sound origin, then nearby corner recently unseen by any NPC with spacing; shooting/exposure use desired target distance, path distance and sight.

Collection cylinders/spheres reduce illustrated 1700 cover posts to about 10, but collecting by scanning all posts still costs a whole scan. Spatial hash quantizes coordinates, tests only AABB-touched buckets; large volumes still yield hundreds of candidates.

Binary AABB tree supports dynamic add/remove, 2N-1 nodes and custom surface-area plus eighth-power axis-length penalty to avoid long thin nodes. Broad phase conservatively rejects whole subtree by OR flags, maximum distance bound or entire box behind player.

Speaker reports roughly halved time versus spatial hash in their use cases, acknowledges other cases may favor hash. Expensive raycasts/exposure use parallel/time slicing and asynchronous best-post request returning false until ready.

domino_recommendations:
Create bounded local service/interaction/observation candidate queries over flat IDs; start with simple spatial buckets and cheap reject filters, then upgrade to hierarchy only if large volumes/profile justify it.

Expose query PENDING/READY/INVALID with task/query revision and target version. Recheck occupancy/reachability on execution; asynchronously selected location never proves arrival or successful action. Preserve lower legal-risk score as preference, not universal physical rejection of trespass.

发布者Q&A说明AABB树支持动态子节点、fat AABB超出才移除再插入，更新工作按时空分割摊到多帧。

request queues按固定PS4/PS5硬件调成1–3帧内消化，不按通用任意线程数/平台配置。

明确规则更容易解释/调试；Update和Coroutine同为主线程不等于并行；原脚本Racket bytecode+C++运行翻译，后自家C++编译器。

原描述把 NPC 目的地、掩体、玩家重生点统一称作岗位，但没有在此给出评分公式。

原 Q&A：选 AABB tree 因适合动态节点，新增/移除 log(n)；实际 AABB 包在更胖的 fat AABB，只有移出时才移除并重新插入，并可将更新分散到多帧。

原 Q&A：queue 中请求调整到 1–3 帧内消化，性能针对固定 PS4/PS5 硬件调参；Update/Coroutine 通常都是主线程单核，不等于真正多核并行。

原 Q&A：规则较易解释/调试；Racket bytecode 和自家 C++ 运行器/编译器是讲者工具链经验，不是 Domino 必须采用的 DSL。

## 后续行为与玩法启发

source_facts:
Player loses sight/throws bottle; NPC relocates for exposure or investigates successive relevant/unknown corners. Multiplayer spawn selection avoids player-visible/nearby positions.

domino_recommendations:
Player can distract a guard, block a corridor, supply misleading sound or cooperate on search. Observation history with provenance guides sparse shared search; a sound only creates suspicion, not offender identity. Crime facts, eyewitness belief, report and enforcement remain distinct; avoid omniscient shared history of all NPC views.

目的地/掩体/重生岗位说明位置候选可按角色需求复用，未来潜入、调查、协作封锁场景需真实占用/可达/视线校验。

玩家改变岗位/障碍应失效缓存，不能只凭AABB重叠认定犯罪目击或成功掩护。

找座位、盯梢、埋伏、逃跑出口及重生选择可复用有限岗位索引；非法用途和物理可用性分开。

玩家移门、移动障碍或破坏掩体时缓存失效；信息尚未被 NPC 感知的变化不能直接成为其全知选择依据。

## 适用范围与局限

Naive N NPC × P posts × C criteria is prohibitive; local bucket/tree traversals reduce candidate work, early-outs skip expensive checks. Author's all-common-tree-ops log N statement cannot imply range query log N regardless of output: query is output-sensitive and worst O(P), dense large volumes/mass wakeups still expensive. Tree uses 2P-1 nodes plus metadata; rebuild/update/OR propagation and repeated raycasts need budgets. Reported 2x speedup is author-specific, no hardware/NPC scale measurements.

fat AABB减少更新、切片平滑请求峰值，但密集/巨型框和目标筛选量未测；没有10000NPC数据。

平台固定有利预算调校，不证明任意机器同样消化延迟。

只读 1606 字符说明/Q&A，无完整视频、树实现、候选评分或万人 benchmark。

fat AABB 会增加假阳性，移动剧烈时重插频繁；10k 活体/静态地点混合应以稀疏局部索引而非每人各一棵全世界树。

Scenario-specific criterion lists with debug scores/visual rejection reasons and cheap-to-expensive order are maintainable. Complex custom tree cost and pruning require conservative bounds; simple grid has lower initial cost. Shared readonly selectors and sparse query runtime fit C ops/data better than per-NPC world copies.

通用岗位定义与人任务实例分离，类型过滤/事件修订和取消释放可用普通C结构。

脚本编译器属于开发者内容系统背景，采用成本高，当前不建议引入。

先依据 Domino 当前图/同楼粗粒度和真实热点选择结构；AABB 适合动态空间查询不说明一定优于当前简单区域列表。

Q&A 是原讲者明确经验，演讲预告不是完整生成/选择算法。新增岗位数据须有稳定 ID、版本、释放及容量合同。

If broad-phase bound wrongly rejects potentially valid child, selection becomes incorrect; soft penalty 0.01 must not be treated as hard zero.

Candidate query may finish after target moves/post removed/route blocked or another actor occupies it; version/recheck and cancellation required.

Score product biases options with more factors; distance/visibility estimates need comparable normalization.

Recently unseen by any NPC assumes explicitly tracked knowledge, not telepathic player location; source search rule is tactical game mechanism, not general institution truth.

Dense ranges may touch almost all nodes and time slicing adds stale-result delay; 10000-agent frame budget remains unproven.

请求摊帧无上限会饿死高优先调查；fat box候选被当精确位置；协程被当多核加速。

从简介推断岗位打分/树实现完整已读或从log n断言所有动态查询严格界。

只按空间近邻选岗位可能选中不可达、被占用或视线暴露点。

异步排队没有公平性、失效或终止合同会完成过时请求。

把 fat AABB 当精确可用性或将 coroutine 当 C23 多核执行，都会误用原机制。

Complete local extracted 40-page document text read; pages 1-2 blank in text, images/formulas/code/video not visually inspected.

Treat as lecture notes supplementary to eNGg0zjaifk, same independent talk as transcript. Author's own speedup/complexity claims not reproduced; no Domino runtime verification.

全文description/Q&A载体已读，不等于完整视频/讲座；原始幻灯片正文缺失。

可作为同一TGDF岗位系统原作的补证归并，避免描述载体另算作品。

完整读原可见说明及 Q&A；没有宣称读完全场视频或观看幻灯片。

log(n) 和 1–3 帧是讲者说法，未独立复现；空间树不解决路径、信念或实际行动。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [document-text.txt](../texts/0c/0c5f313055b9ea7b9acded48991ebea8aeb4c8bc9e5148b4ff042af6b5ce85a7.md) | 文章/文档正文 | [0, 6331) |
| [description-text.txt](../texts/0d/0dd434de2ea9d65a5f6ffc111fbc65414c2fb423c57fd81e6ffacfb32258ff71.md) | 文章/文档正文 | [0, 1606) |
| [description-capture.txt](../texts/0e/0ef4d612ab3f8a921139663df04d430a4bc6c8ecf3eaedcf66d96979fe2a3a61.md) | 文章/文档正文 | [0, 1924) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/10-methods-frontiers/06-chinese-game-ai.md](../../ai-reference/13-youtube-2011-2026/10-methods-frontiers/06-chinese-game-ai.md)
- [https://2022.tgdf.tw/en/agenda](https://2022.tgdf.tw/en/agenda)
- [https://2022.tgdf.tw/en/speakers/minglun_allen_chou_naughty_dog](https://2022.tgdf.tw/en/speakers/minglun_allen_chou_naughty_dog)
- [https://www.youtube.com/watch?v=eNGg0zjaifk](https://www.youtube.com/watch?v=eNGg0zjaifk)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
