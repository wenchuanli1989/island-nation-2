# [3.x] Support for Dynamic BVH as 2D Physics broadphase

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/godotengine/godot/pull/48314`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：pouleyKetchoupp（PR 作者/贡献者）；lawnjelly（BVH 作者/维护者审阅）。
- 原目录日期：2021-04-30（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot/pull/48314](https://github.com/godotengine/godot/pull/48314)

## 概要与项目参考

source_fact: 这是Godot 3.x物理broadphase技术变更与review，不是NPC日常算法；PR正文有真实特定场景的作者测试记录。
domino_recommendation: 本轮基线host尚无空间桶/邻域检索，nav坐标最近点O(V)，未来局部感知/资源候选容易成为全体热点；本作品提供有边界的空间优化评估与维护教训，可提名空间候选机制参考。

## 已有机制分析







## 后续行为与玩法启发

source_fact:
正文只讨论物理候选与碰撞，无犯罪/调查/合作模型。

domino_recommendation:
盗窃/潜入附近目击者、调查附近证物、协作附近服务与玩家区域封锁可先局部粗筛；再用实际视听/进入权限/个人已知信息确认，非法候选不能由社会许可从物理索引删除。建筑内常態可保留粗级，必要潜入区域才细化。

## 适用范围与局限

source_fact:
125000 bodies是无contact broadphase，添加/移除为秒级突发；500及2700 contact场景有限。作者~30/35%声明受多线程narrowphase/solver前提与硬件/场景影响，不是NPC吞吐。

domino_recommendation:
全体索引更新和所有query仍有O(N)底量；密集重叠/大范围bounds可能输出O(N²) pairs，BVH不消除最终候选数。局部query、动作阈值更新、冷热分离和预算仍必要；不能按125k空接触推定10k完整日常。

分开无关优化便于定位回归/回退；零invalid与0-based索引造成+1/-1 hopscotch需要一致合同。

review指出blind FORCE_INLINE可能扩大代码/破坏优化甚至编译失败；这是review观点，应按编译器/热点证据判断，不从此修改项目所有inline。

C23只借机制/测试口径，不搬C++模板或引入Godot；现有静态空间标签只是数据，新增索引更新/失效合同仍需设计。

调参代码被ifdef关闭，‘参数无影响’测试没有验证实际参数；review纠正后仍需正确场景评估。

bounds expansion过大增多false positives；pair sticky减少重插入但不能把相近对象误判成真实观察/犯罪发生。

频繁生成/删除/大规模移动有明显突发成本；一帧重建全体树会抵消查询收益。

正文末尾关联stack-buffer-overflow与2D修复提示维护边界，但未读取具体bug源码，不能宣称本reader确认原因。

全文读18564字符PR正文/评论快照，包括界面壳；未完整读BVH源码、diff或关联issue。

性能记录是作者的指定Godot场景，未经本轮复现；不能外推万人NPC或当前新版Godot。

来源补充空间机制，不证明Domino已实现任何空间query。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [37458304a41dcc080966df8d.txt](../texts/d4/d49985cac0a221221c263a05a2726d4240d85e30dd09e6315141912ee76fea96.md) | 讨论正文/已载入评论 | [0, 12000)、[12000, 18564) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/05-spatial-index-perception.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/05-spatial-index-perception.md)
- [https://github.com/godotengine/godot/pull/48314](https://github.com/godotengine/godot/pull/48314)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
