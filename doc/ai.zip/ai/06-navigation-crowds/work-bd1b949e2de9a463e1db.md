# Feature: Allow to keep an action performing even if the target became invalid at some point

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:0b2dac739a45db1f78f0d127715de269403199c5736e8862ac72f7c6aac26fde`。
- 已有内容：讨论正文/已载入评论。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Racines（GOAP 使用者、功能提议者）。
- 原目录日期：2024-10-25（沿用已有记录）。
- 主要来源：[https://github.com/crashkonijn/goap/issues/285](https://github.com/crashkonijn/goap/issues/285)

## 概要与项目参考

Domino建议：目标有效性、业务效果已提交、表现动作完成是不同状态；若取货已经完成，可继续无效果动画，不应因实体销毁回滚/重发取货。
若目标被他人先毁则不能照样提交收获；仍可安全完成表现收束，执行阶段各自核真实前提。

## 已有机制分析

原issue请求：收集物品在动画过程中已销毁，作者希望动作持续到动画结束；提议在GoapActionBase禁内部valid检查，或在BeforePerform置ForceValidation/End清除，由sensor直到结束维持target。
保存页只有发帖者请求，没有维护者答复、实现diff或关闭原因。

## 后续行为与玩法启发

抢物、争夺战利品、销毁线索/证物、玩家中途打断可触发不同有效性；动作收束应保留实际资产结果和失败原因。

## 适用范围与局限

单个Unity GOAP请求无性能信息；按阶段事件处理可避免每帧全量target检查是项目推论，需测。

每行为声明何时不再需要活target以及何时提交效果，保留稳定ID/值，不为延长动画持有已销毁对象指针。

笼统禁全部validation可能让失效服务/被夺资源继续成功；Closed不证明请求按提案实现。

完整读可见issue正文和页面壳，不等于完整讨论/Discord线程/代码或已确认修复。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [579a8bda5b3f127e0d3c1ee3.txt](../texts/71/71d5cbd16f897143f7cffa12b5a61aa6efc58f74364baf6a0d07a3ee37782778.md) | 讨论正文/已载入评论 | [0, 1550) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/06-affordances-place-selection.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/06-affordances-place-selection.md)
- [https://github.com/crashkonijn/GOAP/issues/285](https://github.com/crashkonijn/GOAP/issues/285)
- [https://github.com/crashkonijn/goap/issues/285](https://github.com/crashkonijn/goap/issues/285)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
