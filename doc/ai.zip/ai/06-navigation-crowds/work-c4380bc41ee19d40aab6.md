# KD-Tree Nearest Neighbor Data Structure / Stable Sort

- 分类：导航、人群、交通与空间协调。
- 资料标识：`youtube:Glp7THUpGow`。
- 已有内容：字幕/转录文本。
- 原目录作者：Stable Sort（频道署名）。
- 原目录日期：2020-10-09（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=Glp7THUpGow](https://www.youtube.com/watch?v=Glp7THUpGow)

## 概要与项目参考

Domino局部空间候选/最近资源查询可用边界距离剪枝，避免全体O(N²)感知；需准确平衡/动态维护/半径查询接口。
该教程适合入门，若作为规模依据必须拒绝2H保证；DynamicBVH等完整讲义可作更强候选。

## 已有机制分析

KD树按depth mod维度交替x/y比较并切空间；向靠近目标的branch下降，在回溯时维护当前最近候选。
使用目标到切分面的距离作为另一branch的下界，小于候选距离时也遍历另一侧；比较平方距离免sqrt。
讲者4:41–4:53宣称heightH最多visit2H所以log search；该普遍上界不成立，递归回溯可访问多个子树而非每层最多两节点。

## 后续行为与玩法启发

附近商人、目击者、追捕目标先按空间筛选再按信息/身份规则；近不等于看见、了解或有权限。

Domino 推演：搜索附近目击者、买家、逃生点或赃物交易场所后，分别判断个人知识、许可、风险；不能把几何距离自动变成犯罪成功或目击证据。

## 适用范围与局限

最坏情况可访问O(N)，不平衡增高、聚集/高维降低剪枝；没有动态移动更新/10000NPCbenchmark。

查询k输出至少O(k)，可限制半径/数量但会改变漏检语义。

退化插入使高度可达 N；分支回溯可能访问大量甚至全部节点，不存在通用 2H 访问上限。

高维距离与大量移动实体可能削弱剪枝；全文未给出万人动态更新、平衡重建或吞吐数据。

教程没有rebalancing、delete、移动体维护或源码文字；完整码在描述外部链接未取得。

维护建议：若使用，应明确对象坐标、稳定 ID、插入删除和重建边界；把候选查询与路线计算分开。全文没有动态删除实现。

另一侧可能仍有更近点，单向BST搜索会漏；所有点同x只按x排序也会退化。

视频声称higher dimensions works equally well是机制可推广，不能等同成本同样好。

树不平衡或多个区域与最佳球相交时，反复探索两侧会接近线性扫描。

某医院在欧氏距离上最近，但道路封闭或用户不具进入资格，推荐结果不可执行。

完整6:31字幕文本，未观看图示/pseudocode画面或读外链源代码；错误复杂度主张已分开记录。

已完整阅读本地 6399 字符字幕载体；未观看视频、检验图示或阅读代码。

高维应用例不构成规模证明；全文无均衡条件、误差处理及动态维护细节。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [transcript.txt](../texts/80/808dab3433ce636bcdb5f6a0d48eb4f15c9dffeccb8632826f24f13c9a964a6b.md) | 字幕/转录文本 | [0, 6399) |
| [browser-export.txt](../texts/b9/b90cdb62966cec35703b19558ee5a35ec70157d79ec00f026643bc3315d78ea5.md) | 字幕/转录文本 | [0, 6490) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md)
- [https://www.youtube.com/watch?v=Glp7THUpGow](https://www.youtube.com/watch?v=Glp7THUpGow)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
