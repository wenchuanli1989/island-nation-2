# 游戏AI寻路——八叉树+A*寻路

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://www.cnblogs.com/OwlCat/p/18226894`。
- 已有内容：文章/文档正文。
- 原目录作者：狐王驾虎（OwlCat / FoxTiger），个人 Unity 空中寻路示例作者。
- 原目录日期：2024-06-02（沿用已有记录）。
- 主要来源：[https://www.cnblogs.com/OwlCat/p/18226894](https://www.cnblogs.com/OwlCat/p/18226894)

## 概要与项目参考

可启发未来局部室内/空中潜入区域按障碍密度细化；当前Domino道路Floyd不应因本文直接换成全世界八叉树A*。

## 已有机制分析

三维Bounds区域递归分八块，只在与障碍包围盒相交处继续细分；空旷区域保留大叶子，最小相交叶标障碍。
将无子节点且非障碍叶子加入图，再两两ray/距离阈值筛边，按空间包含找到起终点叶，交给通用A*。

## 后续行为与玩法启发

设计推论：潜入、空中追逐与封锁需细分位置/障碍，而非同建筑所有地点等价；这是物理拓扑，不负责许可、目击和个人认知。

## 适用范围与局限

八叉树剪枝减少静态节点，但GenerateEdges仍双重全图扫描O(V²)，示例约600节点/4000边无万人/动态地图成本。

树用对象/指针/字典且每节点内含A*临时成本，万NPC并行查询不能共写G/H/Parent，应查询态独立有界。

作者承认各段代码因渐进修改前后有差异，需以完整项目另核验；适合思路讲解，不作可直接采用代码。

若未来必要，独立局部空间索引与nav路图，稀疏邻接生成需新的正确性合同。

FindEdge代码在!ContainsKey时取EdgeList索引，条件疑似反向；RemoveNode/RemoveEdge未同步邻接，可能悬残边。

单位边权1却使用欧氏启发距离，不能保证可采纳；CompareTo把float差强转int会把小差抹零，GetSuccessors以FCost充边代价、NodeBounds/NodeCube命名冲突。

距离阈值与ray对目标包围盒相交不等于沿线无障碍/角色体积可通过；两空叶中心连线可能穿障碍。

完整读16745字符文章代码；未看图、未读外链A*或gitee完整工程、无运行验证。

静态源码中指出的疑似问题不是复现错误；原文更新注明完整项目可能已调整。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [1438abc747b9dbbd724a5bca.txt](../texts/61/612b3c809d01203d5ce6d950938591cab8b8f9474ac4594bd8ad5580b0f2d734.md) | 文章/文档正文 | [0, 16745) |

## 原研究概要与相关链接

- [12-community-2016-2026/10-chinese-community/01-cnblogs.md](../../ai-reference/12-community-2016-2026/10-chinese-community/01-cnblogs.md)
- [https://www.cnblogs.com/OwlCat/p/18226894](https://www.cnblogs.com/OwlCat/p/18226894)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
