# Box2D 3.1.0 Dynamic Tree

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://box2d.org/documentation/group__tree.html`。
- 已有内容：文章/文档正文。
- 原目录作者：Box2D。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://box2d.org/documentation/group__tree.html](https://box2d.org/documentation/group__tree.html)

## 概要与项目参考

高价值的普通C可实现空间预筛机制与诊断接口，适合万级NPC局部感知/资源选择；不直接提供AI或业务执行。

## 已有机制分析







## 后续行为与玩法启发

crime:
为潜入、追逐、见证人/障碍候选提供局部空间查询；违法不在category筛查中默认剔除。

deception:
候选空间接近不是已观察，NPC是否注意/识别/相信须另算。

investigation:
证人候选先AABB，再精确视线/时刻/注意；形成观察记录后才有证词/归因。

cooperation:
邻近伙伴/设施容量候选可避免全员互配，接受与占用仍由人物和执行协议控制。

player_interaction:
玩家堵路、隐匿、改局部布局可影响精确感知与路线，建筑级常态索引在必要场景细分局部区域。

## 适用范围与局限

文档声称cast约k log(n)，不是10,000+NPC每帧成本实测；密集/巨AABB使k变大并退化。

每NPC全图大范围查询仍近全量；必须局部范围、感知时机、查询候选上限/早停和批次唤醒。

节点pool与重建scratch占内存，proxy移动/类标更新有维护成本；数据分布决定树质量。

没有并发读写/安全快照承诺，唯一写者发布或锁内query需Domino另论证。

API小且功能边界明确，pool/index可借；树的private数据不直接让业务依赖内部布局。

节点/叶访问统计和area ratio使退化可观测。

proxy销毁assert仅内部API不变量，外部存档/网络输入仍须验证ID；reuse proxy不能等同稳定人物ID。

AABB overlap不能直接成为目击犯罪或实际接触；mask近似漏复核会把错误类型/权限当成立。

ray hit broadphase未做exact cast会产生穿墙目击。

类别位频繁改动/大范围移动/全树rebuild可能比简单地域索引更贵。

callback返回0只是终止查询，不代表任务取消确认、资源占用释放。

完整8956字符本地官方3.1.0页面正文，未审计tree源码、图像或benchmark。

本轮不联网更新版本；评审针对该归档，不声称当前最新版。

需按3D世界/建筑区域和具体分布决定结构，不默认将2D AABB直接替代Domino导航。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [c9c66a06adb71950e459bf40.txt](../texts/48/488b91ec910ce3c520c646637320045a4d0083ad4c60efbdc79814c676d16bd0.md) | 文章/文档正文 | [0, 8956) |

## 原研究概要与相关链接

- [03-world-perception-navigation/07-spatial-queries.md](../../ai-reference/03-world-perception-navigation/07-spatial-queries.md)
- [https://box2d.org/documentation/group__tree.html](https://box2d.org/documentation/group__tree.html)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
