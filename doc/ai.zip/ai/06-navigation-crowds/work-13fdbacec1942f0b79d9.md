# Friday Facts #117 - Path Finder Optimisation I

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://factorio.com/blog/post/fff-117`。
- 已有内容：文章/文档正文。
- 当前前100：第 45 项；[Friday Facts第117期：寻路优化I](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/045-13fdbacec194.md)。
- 原目录作者：Tomas；实现工作 Ondra（Oxyd）/ Wube Software。
- 原目录日期：2015-12-18（沿用已有记录）。
- 主要来源：[https://factorio.com/blog/post/fff-117](https://factorio.com/blog/post/fff-117)

## 概要与项目参考

直接指出万人目标中的请求数量、固定开销、预算与响应迟滞矛盾；带实际开发者测量和具体触发原因的强候选。

## 已有机制分析

source_fact: 寻路每tick限制节点数避免帧峰值，但请求多时虫群迟钝；分析存档发现大量<=5和5-50短路径，初始化/拼结果的固定成本使短请求占压。
domino_recommendation: 除总CPU预算还观察待处理延迟和唤醒积压；请求按原因分类，避免把固定单请求预算当及时性保证。
source_fact: <=5多由路上遇友方触发重新接入路线，用make way局部避让；5-50多是集结/回巢，直走加固定侧绕障失败才常规寻路。
domino_recommendation: 持续移动复用路线，对临时阻挡先局部等待/让路，再局部修复；需要真实位置和通过检查，不能LOD凭空穿越。
source_fact: 报告短路径steps约10000降至1000、请求约1000降至200；长湖泊路线的cache复用、缩短终点、可能hierarchical路径是未来工作。
domino_recommendation: 未来评价要区分已报告收益与未完成方案；现Floyd道路图只借请求节制/缓存失效，不套其A*成本数字。

## 后续行为与玩法启发

封路、追捕、偷运集结等让NPC真实等待、避让与局部重规划

玩家堵塞道路能产生真实排队/延期，后果有因果而不能直接宣告移动完成

## 适用范围与局限

10000是某save的寻路steps，不是NPC人数。

仅虫群短路径且不靠近玩家允许次优；有人类交易/追逐重要后果时不能任意降级。

当前Floyd路径结构不同，建议收益须未来匹配量测。

以请求理由、长度、步骤直方图定位成本，比只记录全体日志有用。

局部避让与全局路线分工，缓存须随道路事实修订失效；确定失败条件。

预算平滑FPS仍会使NPC对攻击不响应。

直走绕障复杂凹形/湖泊可失败，需回到路线求解。

缩终点和hierarchical当时未实施，不可计入已验证10倍改善。

完整7934字符官网正文与壳；图未查看，指标为作者报告，未本轮复现。

两个别名同篇归一；历史2015版本，不反映当前Factorio完整寻路器。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [3a3ebeee5c352f81d7c20bfa.txt](../texts/d2/d2b884741fc6f8e8a32bf51f51a7b8f243dacb42e43366ddfa9231081712662d.md) | 文章/文档正文 | [0, 7934) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/09-game-case-studies/05-factorio-production.md](../../ai-reference/13-youtube-2011-2026/09-game-case-studies/05-factorio-production.md)
- [https://factorio.com/blog/post/fff-117](https://factorio.com/blog/post/fff-117)
- [https://www.factorio.com/blog/post/fff-117](https://www.factorio.com/blog/post/fff-117)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
