# Math for Game Developers: Dynamic Bounding Volume Hierarchies — GDC 2019

- 分类：导航、人群、交通与空间协调。
- 资料标识：`gdcvault:1026269`。
- 已有内容：文章/文档正文。
- 原目录作者：Erin Catto。
- 原目录日期：2019（沿用已有记录）。
- 主要来源：[https://gdcvault.com/play/1026269/Math-for-Game-Developers-Dynamic](https://gdcvault.com/play/1026269/Math-for-Game-Developers-Dynamic)

## 概要与项目参考

确认主题与作者，提供空间查询用途，只有摘要深度，实施价值不足。

## 已有机制分析

source_fact: 官方 overview 说 BVH 用于加速 ray cast、overlap 和 closest-point 查询，动态层级允许对象增删移动；提到构建方式避免程序生成世界的性能陷阱，但未解释具体步骤。
domino_recommendation: 空间索引可辅助局部人物感知/候选，选择算法需原讲义或源码证据；不能凭摘要决定替换当前路网。

## 后续行为与玩法启发

犯罪/调查/追捕：附近/射线候选可辅助潜在目击与遮挡判断，但摘要没有观察归因或执法机制。

欺骗/协作/玩家干预：动态对象更新是可能的底层前提，不直接产生社交或资产后果。

## 适用范围与局限

摘要无复杂度、对象数、耗时或 10000 NPC 数据；fast queries 为用途主张。

应先核对动态维护、退化与内存布局算法，再考虑 C23 实现；此页不是实现规格。

有 large game worlds 标题不证明全员同频感知可运行。

页面 free content 标签和 logout/订阅壳不表示讲座正文已取得。

全页文字已读，只有官方 overview；没有视频字幕、讲义算法、图像或性能结果。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [1ca9625a402711c01132979d.txt](../texts/e7/e7857be3f56d88d313d7b16763e14209e01641d8164946bc99a691c2d74abd87.md) | 文章/文档正文 | [0, 2549) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md)
- [https://box2d.org/files/ErinCatto_DynamicBVH_Full.pdf](https://box2d.org/files/ErinCatto_DynamicBVH_Full.pdf)
- [https://box2d.org/files/ErinCatto_DynamicBVH_GDC2019.pdf](https://box2d.org/files/ErinCatto_DynamicBVH_GDC2019.pdf)
- [https://box2d.org/publications/](https://box2d.org/publications/)
- [https://gdcvault.com/play/1026269/Math-for-Game-Developers-Dynamic](https://gdcvault.com/play/1026269/Math-for-Game-Developers-Dynamic)
- [https://www.youtube.com/watch?v=lBe_qYDuG8I](https://www.youtube.com/watch?v=lBe_qYDuG8I)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
