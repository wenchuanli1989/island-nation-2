# CodingTrain/QuadTree — quadtree.js

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://raw.githubusercontent.com/codingtrain/quadtree/master/quadtree.js`。
- 已有内容：源码/工程文本。
- 原目录作者：Daniel Shiffman。
- 原目录日期：2018-03-26（沿用已有记录）。
- 主要来源：[https://raw.githubusercontent.com/CodingTrain/QuadTree/master/quadtree.js](https://raw.githubusercontent.com/CodingTrain/QuadTree/master/quadtree.js)

## 概要与项目参考

Domino建议：空间索引只产生附近目标/目击候选，再单独检查视野遮挡、区域权限、物理距离与人物已知信息；现有导航路径权重不能代替这些量。
共享空间只读索引加实体ID候选可削减近邻全员扫描，类型任务只读取少量近邻；树定义/节点可用扁平池而非JS对象。

## 已有机制分析

Rectangle/Circle提供区域contains与intersects；query先剪掉与节点边界不相交子树，再在叶子检查准确范围。
插入超过容量8时四分并把旧点迁到更小子节点，MAX_DEPTH=8防止继续细分；根界外插入返回false。
nearest搜索按点到子矩形的平方下界排序，尝试以maxCount/maxDistance与已找到最远候选剪枝；距离比较尽量不做sqrt。
序列化只存有内容的子树及根边界/容量；fromJSON重建缺失空子节点；filter/merge通过遍历重插建新树。

## 后续行为与玩法启发

建议查询附近目击者、交易对象、盗窃机会、调查线索与救援人员；空间相邻只代表候选，不自动成为目击或知情。

不同楼层/房间/障碍/视线需要第二层过滤，未来潜入不可仅用同建筑或二维距离代替。

潜入、追逐、犯罪目击、近场援助/交易可先范围查询，再提交真实行动和生成有限观察事件。

玩家遮挡/封锁局部区域改变精筛结果；不应让“在查询圆内”自动变成已目击或知道违法事实。

## 适用范围与局限

最大深度保证停止细分，密集同点可在叶容纳任意多点，范围查询最坏仍O(N)；每帧全树重建O(N depth)。

每人查询大半世界仍近O(N²)，需半径/候选上限/事件唤醒；JS对象/递归/每查询排序与数组concat成本不可照搬C内存预算。

平均局部查询可减少候选，但本文件无万人benchmark，密集点在MAX_DEPTH叶子无容量上限时仍会扫描大量点。

每次移动重建整树或每NPC都全图大范围query会消除收益；动态移动更新方案此文件没给。

children生成数组、排序、concat、每叶point排序和结果排序有分配/写入成本；C实现应度量网格与树的实际密度/更新代价。

C版本可用扁平节点/索引和批量位置修订；明确叶/内部节点不变量与边界归属。

原source mutable points与children排序会改变存储顺序，查询共享需只读发布，不留向量扩容裸指针。

保留清楚几何单位、边界约定与索引更新/发布版本；不能照搬这份代码的接口当已验证库。

源码中deleteInRange在divided时points已是null，却仍调用points.filter；nearest返回furthestSqDistance时做sqrt，下一层却同平方距离比较，存在静态可见的单位/空值疑点。

索引是运行时派生数据，加载可按实体真实位置重建，避免保存JS对象/指针或陈旧引用。

静态源码：subdivide将points设null，而deleteInRange在递归后无条件points.filter，内部节点会空引用；未运行验证。

kNearest返回名为furthestSqDistance的值却Math.sqrt再作为平方量比较，量纲不一致；空分叉toJSON省略所有children时fromJSON可能恢复divided且无子节点。

所有点重合或高度集中会到深度上限，叶容量膨胀使近邻查询退化。

deleteInRange对已细分节点访问null.filter；按源逻辑可失败，未运行确认。

kNearest的平方阈值跨递归被sqrt改变可能导致错误剪枝/结果；未测试，不能声称closest正确。

坐标点被外部原地移动但树节点不更新，边界剪枝可能漏掉真实近邻。

完整读此单源码文本；未读仓库其他文件/测试、未运行，发现仅静态合同问题。

master URL无固定commit，carrier SHA固定本轮内容；关联视频未观看，不宣称完整教程已读。

完整显示13,354字符原始JS源码，未运行或测试算法、未观看所关联视频。

源码查找身份为视频教学相关仓库，但本次证据是库文件，不能称整教程/整仓核读。

最近邻及删除问题为当前文本静态推断，应作为采用前验证条件；可借空间剪枝机制，不能直接宣称实现正确。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [d319dee0f83f641a527ef917.txt](../texts/04/04260f6142811aef4983e2ca6962b32b0e89cd369dc9b9470fd73d74dc257b4f.md) | 源码/工程文本 | [0, 13354) |
| [d319dee0f83f641a527ef917.txt](../texts/62/62e62d535cef928bb691056c1fb78df9dd99b39635672d6085e8459bccce87b8.md) | 源码/工程文本 | [0, 11271) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md)
- [https://github.com/CodingTrain/QuadTree](https://github.com/CodingTrain/QuadTree)
- [https://raw.githubusercontent.com/CodingTrain/QuadTree/master/quadtree.js](https://raw.githubusercontent.com/CodingTrain/QuadTree/master/quadtree.js)
- [https://thecodingtrain.com/challenges/98-quadtree](https://thecodingtrain.com/challenges/98-quadtree)
- [https://www.youtube.com/watch?v=OJxEcs0w_kE](https://www.youtube.com/watch?v=OJxEcs0w_kE)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
