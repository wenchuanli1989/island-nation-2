# Dangling OmniLight happening randomly

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:4168f1182fe080cfbcf9483ffeba6c28d6eca9c5847192111b9efa6dd6f31978`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Zylann，Godot/Voxel Tools 贡献者与问题报告者。
- 原目录日期：2020-08-18（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot/issues/41360](https://github.com/godotengine/godot/issues/41360)

## 概要与项目参考

残差与上述完整field归并；不按差异载体增加作品数量。

## 已有机制分析

Godot例子爆炸light三秒释放后mesh配对未解除，RID查找无效而反复报错；新版field恢复精确较简复现评论链接，原帖已有描述。

## 后续行为与玩法启发

爆炸破坏、玩家拆除设施导致NPC引用失效时，应真实失效与收尾。

## 适用范围与局限

残差自身不构成任何额外性能证据。

稳定ID查找失效只是检测，清理所有关联才闭环；未运行复现项目。

对象释放但关系仍留产生永久错误；源为Godot3.2.2渲染器，不直接证明Domino相同缺陷。

仅残差carrier已全文；完整field另有独立条目、范围与SHA。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [a50f2701b27589a1d0ec2bf9-0f5af75a0c1f.txt](../texts/5c/5c6fd1e797ecc1dbecddeee4e4ee17240cd794769245a936acfb52c84a903933.md) | 文章/文档正文 | [0, 160) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/05-spatial-index-perception.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/05-spatial-index-perception.md)
- [https://github.com/godotengine/godot/issues/41360](https://github.com/godotengine/godot/issues/41360)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
