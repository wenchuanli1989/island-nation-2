# Lifelong Planning A*

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://idm-lab.org/bib/abstracts/papers/aij04.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Sven Koenig; Maxim Likhachev; David Furcy。
- 原目录日期：2004（沿用已有记录）。
- 主要来源：[https://idm-lab.org/bib/abstracts/papers/aij04.pdf](https://idm-lab.org/bib/abstracts/papers/aij04.pdf)

## 概要与项目参考

为道路阻断、代价变化和任务前置失效提供清晰的增量修复条件与不变量。
精确区分路径正确性与效率；适合衡量现有 Floyd 全图缓存何时需要更局部的算法。

## 已有机制分析

source_fact: 在固定起点/终点、正边成本的有限已知图上保存 g 与一步前看 rhs；只将 g!=rhs 的顶点放进按 [min(g,rhs)+h,min(g,rhs)] 排序的队列。
domino_recommendation: 可为长期重复的同类路线保留受限搜索状态，图变更后标记目标顶点/依赖，避免无条件全图重算。
source_fact: overconsistent 时将 g 降到 rhs，underconsistent 时先置无穷并更新自身/后继；直到目标一致且最小队列键不小于目标键。
domino_recommendation: 候选路线计算应对快照/图修订号运行，执行前再验有效性；路线修复只产生计划，不提交位置或资源。
source_fact: 优化使用 predecessor p，降低成本只作 min 更新，增加成本只重算实际依赖该边的 rhs；可延迟初始化，并使用队列 decrease/update 而非移除重插。
domino_recommendation: 借用依赖失效与冷热初始化理念，先在道路/路线缓存层实现，不引入每人物通用符号求解器。
source_fact: SHERPA 将 STRIPS 可达状态按需生成，缓存已展开前驱，将多个满足目标的状态归并，算 hmax 时忽略 delete effects。
domino_recommendation: 仅作为未来复杂组合任务的比较基线；近期模板无需完整世界状态图。

## 后续行为与玩法启发

玩家封路、改运费、破坏通道可导致物流/逃逸路线重新选择。

犯罪可将主观风险作为成本；物理可达性与违法许可须分离，算法本身不提供目击/归因/惩罚。

## 适用范围与局限

每个保留的搜索状态需要每顶点 g/rhs 与队列/依赖信息；10000 NPC 各自保留全图为 O(NV) 内存，论文未验证。

单次静态变更后每顶点至多展开两次不等于任意连续变更下总量有界；搜索中处理新变化会破坏此上界。

51-201平方网格的多次重复规划表明小变更、靠近目标较有利；桶队列 A* 可改变优势，不能按扩展数直接推断运行成本。

g/rhs/queue 三不变量、正成本和一致非负启发式可直接作为调试检查。

按图版本保存/丢弃缓存，需要限制搜索状态寿命；移动起点须另考察 D* Lite。

变化集中在起点或旧/新搜索树重合度小会出现负收益。

inadmissible heuristics 缩窄搜索树后增量重用更难优于重算。

符号状态空间过大，预先初始化全部状态不可行；不合法 heuristics/零负边不能直接套证明。

完整读取151960字符PDF提取文字，数学符号有OCR/编码损伤；未核看原PDF图像。

仅作者网格实验运行时间，不是Domino或10000NPC吞吐验证；SHERPA只有扩展统计。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [307a1ab206b485fee8f978f5.txt](../texts/a0/a02367f66cb5272b87e816471b7a6efbc23e3712a64aad7d1dec5eb8d7dc2bfa.md) | 论文/讲义提取文本 | [0, 151960) |

## 原研究概要与相关链接

- [03-world-perception-navigation/09-environment-change.md](../../ai-reference/03-world-perception-navigation/09-environment-change.md)
- [https://idm-lab.org/bib/abstracts/Koen04a.html](https://idm-lab.org/bib/abstracts/Koen04a.html)
- [https://idm-lab.org/bib/abstracts/papers/aij04.pdf](https://idm-lab.org/bib/abstracts/papers/aij04.pdf)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
