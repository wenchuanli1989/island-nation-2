# Peeps using overlaid paths for pathfinding when they have a goal #23006

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/openrct2/openrct2/issues/23006`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：alex-parisi（issue 报告与机制分析者）。
- 原目录日期：2024-10-16（沿用已有记录）。
- 主要来源：[https://github.com/OpenRCT2/OpenRCT2/issues/23006](https://github.com/OpenRCT2/OpenRCT2/issues/23006)

## 概要与项目参考

Domino建议：导航可达图必须来自真实连接，渲染装饰、权限与碰撞层各有明确语义；路径存在或视觉接壤不能自动贡献可走边。
有目标与无目标的导航策略需共享同一可行边合同；局部重规划的历史缓存要绑定路线/图修订，不能以记忆排除真实方向后退到不可行边。
候选路径/ETA只是计划估算，行为推进发现断路须报告失败并局部修复，而不是到期直接宣布到达。

## 已有机制分析

问题复现用ProxyPather隐藏真实path，再叠加边全开的装饰path；一般导航取firstTileElement，但ChooseDirection把同高度所有path的permittedEdges做OR，并把任一overlay的thin判定做OR。
thin junction判定按相邻path存在计数，不保证邻居与真实path互通；有目标的peep记最近4个thin junction及未尝试边，回到路口时排除已试方向，可能选到装饰层贡献的不可行边。
作者把permittedEdges收集移进firstTileElement分支后报告lost guests下降并提供前后视频链接，但评论强调尚有quirks、没有此用例测试协议、需查原先合并overlays的理由。
2025年评论提议blocked flag减少重叠层；插件作者澄清overlay用于外观与可走区域分离，blocked flag可消除不可走tile的第二层，却不能消除可走tile的视觉层，edge级flag可能另有价值。

## 后续行为与玩法启发

潜入、封锁、室内不同区域/楼层和犯罪逃离需要实际通道及权限，不能把可见装饰路/同建筑当物理可达。玩家改路使 NPC 路线失败有明确原因。

路径记忆用于局部重试可解释，不能自动给人物全知目标实时位置或把暂时卡住当永久无路。

玩家封路、假门、隐藏通道、潜入与逃逸需要视觉可见、物理通行、社会许可和人物已知路线分离；非法路线可以物理存在，但风险另评。

室内追踪可使用有限局部区域/边权限，避免同楼一律等价；警卫误认外观入口和真实堵塞可以产生可解释后果，不能通过bug让NPC穿墙。

## 适用范围与局限

每点扫描 tile 所有元素和有限 4-junction 记忆是具体界限，但无 10000+ benchmark；Domino 局部邻接和小候选可用，整图重建不是本文证明。

重叠层扫描成本依tile element数，固定4路口记忆是有界空间；评论提到找到第一path即可早退出以省cycles，但未提供量化性能结果。

万人NPC应共享真实图与局部动态边状态，限制单次路径修复；不能每NPC复制装饰场景或全图重建。

分开作者复现描述、假设与 proposed patch；Open 标签不能当问题在当前版本仍存在或已解决。

默认第一个 overlay path 正确有内容顺序依赖，需要实际路身份合同，而非统一图/装饰图代码混用。

显式视觉/导航标记与边合同比用tile排序和叠层漏洞表达意图更易维护；构建图、实际移动与目标回退必须使用相同解释。

案例适合作为设计反例清单：相邻存在≠互通、合并边≠合并可走实体、优化先查表示含义；不把作者小改自动视为通用修复。

所有路径 edge 并集可生成不存在的通路；thin 统计存在性和移动连通性不一致。

仅首个 path 可能丢合法重叠通路/队列/高差语义；有限记忆不保证避免全局循环。

只取first path若tile顺序改变或原实现有合法合并需求，可能破坏其他场景；作者与维护者均未确认完整影响。

统一blocked tile不能表达同tile不同边、不同高度或只替换外观的可走路径。

仅靠最近4路口未试边避免环路，图改变或错误permittedEdges仍会使NPC走到死路。

全文读社区页及所引代码片段，未读完整 GuestPathfinding.cpp、图片/park 附件、plugin 源码或复现。

特定 overlay 构造问题，不能证明 Domino 当前 nav 存在同缺陷。

16,735字符issue主帖、代码摘录、嵌入timeline评论完整读取；未下载park、观看before/after视频或运行OpenRCT2。

本地快照仍标Open，没有合并PR/完整修复证明；是特定叠层插件边界的具体导航反例，低于通用行为/玩法机制候选优先级。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [55529b927cc89e648ffda786.repaired.txt](../texts/3e/3e3eabcc379750bcf7223103dfd9f235353817880aaf331058fb0b50c6d39bfe.md) | 讨论正文/已载入评论 | [0, 11500)、[11500, 16735) |
| [55529b927cc89e648ffda786.txt](../texts/ea/eaec64240e3d1effbfdc61c5bd2c339def82f3c15e64ea182202c08dc9035864.md) | 讨论正文/已载入评论 | [0, 7895) |

## 原研究概要与相关链接

- [12-community-2016-2026/05-game-development/06-openrct2-peeps.md](../../ai-reference/12-community-2016-2026/05-game-development/06-openrct2-peeps.md)
- [https://github.com/OpenRCT2/OpenRCT2/issues/23006](https://github.com/OpenRCT2/OpenRCT2/issues/23006)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
