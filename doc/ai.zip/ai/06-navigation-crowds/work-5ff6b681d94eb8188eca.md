# Blazing Fast Neighbor Search with Spatial Hashing (Ten Minute Physics slides text)

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://matthias-research.github.io/pages/tenMinutePhysics/11-hashing.pdf`。
- 已有内容：文章/文档正文。
- 当前前100：第 26 项；[基于空间哈希的高速邻居查询（Ten Minute Physics讲义抽取文字）](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/026-5ff6b681d94e.md)。
- 原目录作者：Matthias Müller。
- 原目录日期：2022-03-01（沿用已有记录）。
- 主要来源：[https://matthias-research.github.io/pages/tenMinutePhysics/11-hashing.pdf](https://matthias-research.github.io/pages/tenMinutePhysics/11-hashing.pdf)

## 概要与项目参考

Directly supports avoiding ten-thousand-NPC all-pairs sensing and fits Domino flat arrays/phase processing. The source is an extracted slide deck with some diagram text reordered; it is not a measured implementation in this task.

## 已有机制分析

source_facts:
The slides replace all-pairs distance tests with a uniform grid: for equal radius r and cell size 2r, store each center once and search 9 surrounding cells in 2D or 27 in 3D.

An unbounded grid hashes integer floor(position/spacing) cell coordinates into a table, explicitly allowing collisions; larger tables reduce extra tests and table size equal to particle count is suggested.

The storage construction is count bucket occupancy, partial sums, then fill a particle-index array, yielding contiguous bucket ranges rather than per-cell linked allocations.

domino_recommendations:
Use a shared spatial broad phase to produce local NPC/interaction/witness candidates before exact range, visibility, access and belief checks. Reuse the flat-array approach and phase snapshots; do not store a full world grid per human.

Support actual query radius and varied object extents explicitly; merge or deduplicate colliding bucket visits and perform exact tests. Treat any budget cap as a documented perception/gameplay approximation, not an exact collision or evidence guarantee.

## 后续行为与玩法启发

Local witness discovery, nearby partners, crowds and help requests can use this broad phase. Crime guilt or fraud success still requires observation records and execution; spatial adjacency alone is not knowledge or consent.

## 适用范围与局限

Building counters/prefix ranges is proportional to table size plus point count. Query work depends on actual bucket occupancy and true neighbor output; a crowd in one cell or poor hash collisions can still approach quadratic pairs. Ten-thousand performance is unmeasured here and the source's 100000 all-pairs example is arithmetic, not a runtime result.

Keep cell spacing, coordinate bounds/signs, table rebuild ownership and exact query semantics explicit. Spatial updates belong to physical/state phases and should expose stable ID/revision references to readers; this deck does not define concurrency or persistence.

The 9/27-cell rule fails when query distance exceeds spacing or object extents differ without expanded ranges.

Treating every particle in a hash bucket as a true neighbor creates false witnesses and collisions.

Hashing cannot eliminate the cost of a genuinely dense crowd's required pair output.

All extracted slide text read; slide images/layout, linked video and code were not viewed or executed. Hash occupancy and exact query implementation are not shown.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [df02f7aa9aa14dbf0659ccf7.txt](../texts/a4/a4a0dd68d270e10c2d664f462a2c845433f3464264856e08f1d1b8ed045b23da.md) | 文章/文档正文 | [0, 2159) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/07-spatial-neighborhoods.md)
- [https://matthias-research.github.io/pages/tenMinutePhysics/11-hashing.pdf](https://matthias-research.github.io/pages/tenMinutePhysics/11-hashing.pdf)
- [https://raw.githubusercontent.com/matthias-research/pages/master/tenMinutePhysics/11-hashing.html](https://raw.githubusercontent.com/matthias-research/pages/master/tenMinutePhysics/11-hashing.html)
- [https://www.youtube.com/watch?v=D2M8jTtKi44](https://www.youtube.com/watch?v=D2M8jTtKi44)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
