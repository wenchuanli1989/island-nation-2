# MASON Continuous2D.java

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-repository-bundle:eclab/mason@08c95296de1b4fa73635e0c301ca9a272af8749e`。
- 已有内容：源码/工程文本。
- 主要来源：[https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/continuous/Continuous2D.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/continuous/Continuous2D.java)

## 概要与项目参考

Domino 建议：若细化局部移动/目击，区域桶以ID/索引保存附近人/物，精确条件由后续位置、建筑区域、遮挡与权限独立过滤；建筑级常态无需全世界细粒度坐标。
Domino 建议：区分粗候选接口与精确查询合同，复用临时批缓冲；借用容器的失效规则对应当前kvec扩容风险。

## 已有机制分析

源事实：连续坐标→固定离散桶，保存对象真实位置与桶所属；先收包围桶候选，再以距离平方或坐标绝对差精确筛点。
源事实：非点物体查询扩大一桶，需桶宽至少覆盖最大物体尺寸；桶宽在构造时确定，不能带已有数据随意改。
源事实：查询可复用result Bag；最近邻逐洋葱层扩展，达到搜索阈值退回全部对象，桶查询有明确借用容器禁止修改/长期持有的合同。

## 后续行为与玩法启发

追捕、潜入、围观、求助、选择交易对象及盗窃目标可先用局部桶候选，再分别检查物理可达/资源/社会风险。

玩家封锁走廊、改变位置或遮挡可改变候选与目击机会；不能以同楼常态简化抹平所有室内权限。

Domino 建议：暂停生产/调查与永久取消分开，旧动作停止确认后才能把工具/预算交新任务；玩家打断、协作者退出、拘捕要留下真实完成部分和原因。

线程结束没有领域成功含义，不能因此宣布偷盗/交易/合作已完成；目击和机构后果仍单独提交。

source_fact:
无具体行为或犯罪交互。

crime:
犯罪目击/调查访问当前位置候选，索引只确定空间同址，不代表目击成功。

deception_investigation:
可查询访问者与观察候选；必须另存带时间的观察事件，不能用当前 Bag 反推历史到场。

cooperation:
建筑/工作地点成员可作为稀疏合作与任务候选，不按全体互配。

player_interaction:
人物进入离开场所后索引随实际位置提交更新，玩家干预可改变局部可参与者。

巡逻/工作进度的周期检查只是唤醒，不表示到点/支付成功；玩家取消后仍须统一执行者确认进度与资源释放。

有界稀疏参与者/事件集合可使用紧凑数组，服务/调查成员删除必须保留稳定身份和占用释放。

随机遍历可能改变资源先到先得，应区分调度公平与人物选择，而非凭容器shuffle生成游戏事件。

跨会话继续调查、贸易、多人约定与持续工作，保留已知事实/进度/实际效果，重建到期通知。

玩家打断任务、世界退出和临时挂起分别发命令到统一写入者；可按状态解释为何活动未继续。

固定随机种子与多个独立运行可用于日后比较犯罪风险/关系演变参数，当前没有运行验证。

可承载任意领域update但此文件没有crime/交易/合作逻辑。

附近盗窃目击、巡逻追捕、交易邀请可先查局部桶，再判断视线/知识/参与意愿；玩家改变位置、封锁通道影响候选，但距离命中不自动形成证据或惩罚。

物体尺寸不同或感知半径不同可分索引，防止对室内全部空间等价的偷袭/调查失真。

追捕参与者、目击候选或附近交易对象等临时集合可以无序筛除；若叙事顺序、邀请优先级、价格公平或任务sequence有意义，则保持其独立顺序数据。

此源码不含犯罪、知识、玩家干预或真实资产机制；玩法价值仅是承载局部候选集合。

玩家打断交易、犯罪活动、同行协议后保存退出，再加载应保留已发生效果和剩余进度；框架本身不生成这些玩法。

Stop a patrol, recurring extortion demand or delivery appointment; pending wake cannot revive cancelled intent, while already committed outcome remains real.

中断抓捕、交易或合作时需等实际执行停止后释放地点/货物，恢复后保留此前进度与后果。

玩家暂停/存档不能自动完成劳动、发工资或重复犯罪资产效果。

Crime witnesses, guards, nearby helpers, social encounters and service queues can be selected from actual local occupants.

Player movement, blocked entrances, gatherings or evacuation changes local candidates and event recipients; locality enables measurable intervention consequences.

Building-level occupancy suffices for routine candidates, but infiltration/indoor pursuit requires zone or visibility filtering; co-location alone is not proof of seeing an event or legal permission.

犯罪调查期限、服务排队、协作集合、交易超时可复用到期通知；到期只提示检查，不保证工作完成或定罪。

玩家断路、拒绝邀请或取消交易需修订任务并隔离旧唤醒，已完成财产转移不能由取消timer撤销。多人同刻竞争需领域容量/顺序规则。

## 适用范围与局限

期望查询成本为覆盖桶数+桶内候选数，密集桶或大半径最坏O(N)；全员每帧查询仍可能退回O(N²)。

桶过大收集太多无关对象，过小访问大量空桶；可多尺度索引但移动维护成本随索引数增加。

源码未给10000 NPC性能/内存实测；Java对象Map与Bag分配成本不能当C数组成本。

最近邻预算N/10后返回所有对象，没有保证低于全扫的最坏性能。

源码每异步对象一个线程；10000NPC若逐人采用会引入10000栈/调度及world锁争用，文章无万人基准。粗粒度Schedule锁整步占用，不解决热点并发资源。

批量pause/stop逐线程join可能长阻塞，halt不能唤醒阻塞任务则无法结束；Domino应集中停止生产→唤醒→join少量worker，人物层只有限状态，预算按任务组。

source_fact:
接口无调度实现或性能。

domino_costs:
不能由一个step推断万人效率。

源码详细注释和实现明确：添加预期 O(1)，搬移/删除要扫描旧位置 Bag，为 O(M)；不能采信开头概述的所有变更均 O(1)。

全体扫描 allObjects 为 O(N)，遍历地点 HashMap 可能 O(H)，批量地点结果成本至少成员输出量。

每地点大 Bag、稀疏 Map 桶及 Java 引用/GC 开销不能照搬成 C 万级预算；局部极密时移动扫描仍贵。

没有并发同步或快照边界，不能直接作为双缓冲线程安全证据。

重复事件队列成本由未读Schedule实现决定；一个helper无万人/线程吞吐证据，per-event lock/对象/key不适合直接证明C扁平调度开销。

已知索引的删除O(1)，按对象查找仍O(n)，containsAll/集合筛选可嵌套扫描；万级NPC全员找目标不能只靠Bag。

倍增复制O(n)，每批shrink或clone会增加复制成本；JavaObject[]存引用不等价C紧凑实体结构。

注释3.5x/4x性能是旧Java作者声称且无本轮复现，不作当前C23性能保证。

登记表复制与暂停成本O(A)，A应为少量引擎后台服务，不应等同1万个NPC异步线程。

完整Java对象图序列化/GZIP会暂停执行并带来内存、I/O峰值；Domino采用扁平数组世界事实快照，不能照搬对象图。

parallel是独立模拟job线程而非同世界NPC并行；该文件无万人基准。

无事件队列或10000+规模证据；Serializable标记不证明低内存/恢复安全。

桶太大退化为全员筛，太小扫描大量空桶；全员每帧查询仍有整体成本，需仅为活跃者/事件查询。

多分辨率索引增加移动维护成本；nearest-neighbor阈值会返回allObjects，不能把它当万人有界查询。

直接顺序数组访问和容量重用减少对象/迭代器开销；contains/remove(Object)仍全扫，containsAll/retainAll可与另一集合产生乘法成本。

开头3.5x/4x速度为旧Java实现注释主张，无当前硬件或10,000 NPC性能数据；Java Object[]指针追踪不等于C扁平热记录的访存成本。

registry snapshot O(A)内存和pause/stop时间取决于异步对象数；不能为每个NPC建立一个异步线程或在checkpoint中永久保存所有运行对象。

这个文件没有Schedule内部队列/复杂度/批量感知算法或万人benchmark；-parallel不证明单宿主世界可并行。

One queued no-op per stopped repeat costs scheduler slots; 10000 long callbacks under lock can block stop responsiveness.

No scheduler complexity or NPC benchmark; zero interval is allowed here, actual Schedule handling not read.

Stagger repeated due times and coalesce notifications instead of all-person callback polling.

每实例一Thread、锁与不可复制随机访问不适合10000NPC；改为少量批处理线程与有限运行记录。

join无超时若halt无法唤醒阻塞任务可永久等待；人物业务等待应由事件调度。

Hash bucket retrieval is expectedO(1), but consuming occupants is O(M). Detailed source docs and code identify movement/removal as O(M) due to local search, despite broad opening language suggesting speedy O(1) operations.

Global scan remainsO(N), hash-location iteration O(H), and concentrated crowds can make local movement/perception expensive. Bound candidate enumeration and evaluate bucket occupancy distributions.

Flags trade memory for allocation cost. Shrink branch requires remaining count≥MIN_BAG_SIZE32 and capacity≥4×count, so large nearly-empty retained buckets may not shrink until empty; C retention policy needs an explicit budget.

堆操作通常O(log E)，批次B的处理/洗牌至少O(B)，所有万人同刻到期仍会峰值；该文件没有万人吞吐验证。

停用条目不会即时删除，反复改期会保留到期残留；必须预算E、取消残留和批次上限。currentSteps一次收集整时刻事件也会扩大临时内存及锁占用。

Domino可人物合并唤醒、近期事件窗口、分批业务处理；仅有可测模式时再考虑calendar queue，不因框架注释直接换数据结构。

把bucket index、真实位置、边界语义和借用结果所有权写清，移动/删除保持双索引一致。

桶尺寸更改必须清空重建；C实现应通过受控配置接口而非可直接改字段。

常态建筑级索引与关键室内细区域可按需求分层，避免世界全精细化；不沿用Java deprecated API壳。

可跟踪running/paused及恢复来源，便于区分fresh start与恢复外部文件位置；但run/halt契约完全交子类，缺明确资源清理/失败事件。

弃用重载/stopper是库历史接口，本项目无需兼容；用普通C ops并记录业务激活版本，公共取消/释放集中，避免每个领域各自做线程生命周期。

小接口清楚；Serializable标记只表达序列化可参与，不证明完整任务恢复。

位置 HashMap 的值相等键必须不可变，原地修改位置字段会使检索/删除失败。

删除/移动/清空都应更新两张表和数组；对外只读结果需明确存活期。

copy constructor 只复制 Map/Bag 外层，条目 LocationAndIndex 与地点 Bag 仍共享；不能默认它是独立世界快照。

stop把未来回调变noop而不是删除已排事件，与业务terminal/cleanup分离；类型ops公共终结应另保存。

unsynchronized类要求外部锁；源码警告迭代中添加/移除除iterator.remove外语义未定义。

removeMultiply缓存numObjs后多次remove可能有旧长度边界风险，需独立验证；本轮只读未执行。

保序需求只用于日程/行为序列等语义有序结构，无序对象集合可避免搬移。

pre/post/awake钩子清晰区分初启、正常保存后继续、加载重建；可用小型C接口表达。

writeToCheckpoint在preCheckpoint后发生写入异常时没有finally恢复，可能使异步服务保持pause；Domino需明确失败后保留世界并恢复或可重试。

finish可重复调用但要求子类自行flag防重复；存档恢复不能再调用start的reset清空业务状态。

CLI、GUI、分布式优化和旧Java兼容复杂度不应引入当前核心。

接口足够简单，C可用函数指针但未见shared定义/实例模式。

可提炼普通C桶索引、粗筛/精筛、暂存结果接口，无需引入Java MASON框架。

桶宽、非点范围和wrap-around有明确前置合同；离岛地图通常不必采用环面。

当前文件主要Java对象/hash/Bag，布局需适配ID数组；本文未审计SparseField基类。

需要维护有效长度、重用槽位、ID索引更新与遍历删除规则；不保存数组裸指针跨扩容。

数组复制/clone共享对象，不是规划只读世界快照；无同步容器不能并行写，应在单写入者或阶段化边界更新。

公共开始/正常结束/提前结束/保存前/保存后/恢复钩子能减少类型特殊逻辑，但钩子顺序和失败cleanup必须是明确合同。

只提炼生命周期模式，C23线程对象和运行queue仍按当前架构重建。

Keep repeat data and common stop protocol separate from domain callbacks.

Reschedule-before-callback makes internal stop clear future wrapper but cannot undo current action; document this boundary.

Use saved business due time/progress, rebuild runtime events on load; Java object/key references are not persistent identities.

显式run/resuming/restoring和halt/pausing分层容易审查；Java序列化合同不能直接移植C。

旧deprecated重载与示例val未定义应当作载体限制，不保留兼容分支；Domino按现设计实现最小生命周期。

Three structures require coordinated updates, swap-index repair and well-defined borrowed-view lifetimes; document these invariants in C APIs.

Do not copy Java Serializable or GC/object-pointer ownership assumptions. Persist canonical person/location data, then rebuild derived buckets after load.

Known bucket slot can improve performance but adds one invariant; use it only if relocation cost justifies it rather than build a generic spatial framework.

可移植的是时间/排序/生命周期合同和局部锁边界，普通C+现有队列/heap足够，不引入MASON/Java或通用调度DSL。

为并行规划保留值快照，execution统一提交；对堆中借用指针和已出队副本的取消检查需说明所有权。

近邻不是视线/认知，点距离也不是路网可达或实际ETA。

非点对象超过桶宽会漏候选；稀疏远距最近邻扩层很贵，密集人群一个桶很贵。

原copy构造器未显式复制doubleLocationHash、最近邻额外层循环y未进入坐标表达式，属源码可见疑点；未运行，采用前需验证，不能照搬。

越界非toroidal坐标并不由width/height自动禁止；近邻不支持toroidal模式。

stop/pause是synchronized方法且持this monitor等待join；worker若需要同一monitor收尾可能互阻。halt必须使线程退出，run默认空/halt默认空不提供可停保障。

线程自然结束并不自动清running或unregister，直到stop；running并不等于正在工作或任务成功。

序列化状态没有真实资产/进度一致性证明；先发halt后立即保存而不等确认会重复效果。

共享锁只按文档约定，不代表Java/C普通字段并发安全；异步访问RNG与世界顺序破坏可复现。

统一step不定义推进时间、状态修改所有者或生命周期；Serializable不保证外部资源/旧事件恢复正确。

把可变坐标对象作为哈希键后原地修改，旧条目无法可靠找到。

删除数组元素不修交换对象下标，之后 ID 查询指向错人。

修改返回的内部 Bag 会破坏两张表一致性；持有旧 Bag 遇复用后可能指向别处。

将浅拷复制构造当隔离快照会让共享可变条目互相影响；本轮未审阅子类额外复制逻辑。

零interval被允许可在相同time持续repeat；infinite double与浮点精度也未排除，不宜作现实time合同。

下次repeat在用户step之前排好，stop会留下queued wrapper；取消不撤回当前执行或已提交效果。

捕获reschedule失败仍执行一次用户step，源码错误策略与Domino timer backend失败abort目标不同，不能原样照搬。

直接数组引用在resize后旧数组仍被持有，跨线程并不能保证实时更新。

浅clone不会隔离内部对象修改，不能当完整人物快照。

swap-tail破坏顺序，若行为序列依赖index会跳步或错配。

stop/暂停的完成保证取决于未读取的AsynchronousSteppable，调用stop不能自行等价于join完成。

从后台调用kill的死锁警告说明停止线程与停止确认是不同阶段。

文件保存异常只打印返回null，read异常也返回null；恢复业务不能用兜底新世界掩盖失败。

PRNG种子强制32位和默认wallclock与Schedule模拟时间并存；Domino业务仍统一累计未冻结现实毫秒，不重置已存时间。

一个step回调不区分开始/等待/停止/释放，Serializable不自动保存世界资产关系。

width/height仅用于环面和显示，并不自动把非环面输入限制在边界内。

最近邻radial扩展代码内层循环使用固定e而不是y，可能重复查询同层；未运行验证，不建议直接移植该实现。

粗桶候选包含范围外对象，误当精确邻居会导致错误目击和交互。

尾项交换破坏任务顺序/优先级，且只改数组未更新索引会使后续ID查询错误。

边迭代边改容器原文标undefined，迭代器没有fail-fast；clone不能隔离对象内部修改。

removeMultiply缓存旧numObjs而remove会缩当前长度；含null且大量删除时尾部清空项可能被旧界继续访问，需另外核实，不能照抄循环到C。

writeToCheckpoint在preCheckpoint后如果序列化/flush抛错，postCheckpoint不在finally里，不保证所有异步对象恢复；不能照搬此错误路径。

finish可能重复调用且用户退出时可能不调用，源码注释要求flag；实际registration只看cleaning标记，并未单独检查永久stopped。

文件末尾assess注释先称默认全0，后又称optimimum，但代码明确返回0；帮助文档job编号步进与实际thread*repeat/job++也不应当性能事实。

Treating stop as removal from queue is wrong; wrapper may still pop and no-op.

Long callback holds lock so outside stop blocks; cancellation responsiveness depends on bounded callback duration.

Unknown schedule semantics for zero interval or past due time can spin/reject, so no safe catch-up claim from this file.

Executing callback after reschedule failure can leave recurring work silently non-repeating.

默认halt空函数，长线程若不协作终止，stop/pause无限join；取消通知不是完成。

初始线程setDaemon(true)/name，resume线程未设置同属性，生命周期属性不完全一致。

保存running/paused不能证明原子业务快照或恢复后副作用一致；未审计SimState与其他代码。

A packed stadium of10000 people remains a large bucket; sparse hashing does not make all pairwise social comparisons cheap.

Returning an internal mutable bag or caching it across movement breaks membership; current project kvec realloc makes pointer retention similarly invalid.

Copy constructor map copies share Bags and LocationAndIndex values, so it is not an independent multi-thread snapshot.

Location membership does not encode route feasibility, individual knowledge, line-of-sight, ownership or sanctions; those rules must stay separate.

clear/reset不是立即停止本批业务，重复Steppable甚至可重新排程；把清空队列当确认取消会漏执行。

浮点time到2^53后加1无变化；beforeSteps在主try/finally之外，若其异常，inStep复位合同可能失效；不能把此源码称无缺陷实现。

随机同刻顺序服务于实验偏差控制，不适合所有交易/追捕竞争语义；种子/业务冲突策略需单独设计。

完整读取单个Java源文件；父类SparseField/Bag等未在本任务内，不是整MASON源码审计。

未运行/测试，疑似代码问题仅静态观察；不证明引擎性能。

C实现、冻结时间和执行生命周期映射均为建议，源类只管理空间。

完整读单Java文件，未读MASON Schedule/SimState/GUI/完整checkpoint实现或运行；可停契约是子类责任，无证明。

排除理由：对生命周期有参考但一对象一线程及粗粒锁不符万人结构，缺NPC资源/合作业务语义，优先级低于可恢复动作机制。

313字符Steppable接口全文已读，Schedule/SimState及序列化实现未读；不能宣称审计MASON框架。

完整阅读一个固定提交的 Java 文件，不等于 MASON 全仓审计、Bag 实现阅读或运行验证。

只有当前源码与注释证据；未执行任意引擎或 MASON 测试。

本轮一次空输出读取未计覆盖，随后相同 0–12000 重新完整显示。

完整2047raw chars，SHA/header/EOF/exit0闭合；仅一个repeat helper，Schedule/cancel/save源码未读取。

15431字符Java源码载体全文，不是MASON整仓审计、运行测量或C23直接移植。

源码疑点为source-only判断，未编译或测试。

已全读30485 raw字符单一源码文件；未读Schedule/AsynchronousSteppable内部、未整仓审计。

无执行、测试或规模复现；工程映射仅采纳生命周期思想，不采纳Java序列化/线程模型。

完整单文件330字符；未读MASON scheduler/storage或运行。

已读这个完整源码文件与注释，未审计整个MASON仓库、依赖类或运行性能。

只覆盖二维空间索引，未提供任务生命周期、LOS、知识与法律制度。

完整阅读固定commit的修复文字载体，未审MASON调度器、模型或整个库；未运行Java源码。

AFL3.0只见文件头声明，本轮未作许可证兼容判断；开头性能比值不能视为现今量测结果。

完整读取当前41,390 codepoints单一SimState.java源码载体；不等同MASON全仓审计、Schedule源码阅读或框架运行验证。

checkpoint序列化对象图与Domino值快照目标不同，恢复pattern有参考价值但具体持久化需另设计。

源码声明MASON22.0只是此提交内容，未查询最新版本。

One pinned Java source file complete, Schedule/SimState not read and no tests/runtime.

No payment/progress/stop ACK/persistence implementation; Domino adaptations are recommendations.

完整读一份修复后的Java源码文本；alias raw/repaired归并，不当作完整MASON代码库审计。

未运行、未核SimState注册/序列化流程，也没有性能证据。

Complete repaired raw carrier [0,22653) displayed in two SHA-matching exit0 TTY windows with header/EOF/tail checks.

Only SparseField source was read. Bag implementation, spatial subclasses, synchronization and runtime benchmarks were not inspected or executed.

完整读取固定commit下Schedule.java本地修复载体，不等于MASON整仓或Heap/IterativeRepeat实现核读。

注释与源码提供结构和边界证据，未运行或复现性能。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [75d10cdd073fab924dc5ba8a.txt](../texts/14/14e0b8fae4901b67f98df34f3ff0a9b448c15bd1ee60e9960d061c30451415ac.md) | 源码/工程文本 | [0, 2047) |
| [baec33d350d293946f342e0b.txt](../texts/1a/1a894ba44be5941367e174db2db87fba1036487bda62c6d34e8714b908c6bcd9.md) | 源码/工程文本 | [0, 12000)、[12000, 18950) |
| [bdf48a2f5672e3d14306124f.repaired.txt](../texts/39/39e454beb3c49661da7c3d902998e53d69422ff83bfbd039d1207fbc87b286e1.md) | 源码/工程文本 | [0, 11500)、[11500, 19482) |
| [75d10cdd073fab924dc5ba8a.repaired.txt](../texts/40/4000d09adc835fb617aa827b770fc68801776f9b0e07f3aa594db8e1de412e99.md) | 源码/工程文本 | [0, 2702) |
| [036ad4f4296d76190b8e7f06.repaired.txt](../texts/5c/5c281a8679f510568348027889c12492cb1d9055f0a7cf50c0dc8cbe03242699.md) | 源码/工程文本 | [0, 330) |
| [de0d061e9583cee2281ad33f.txt](../texts/77/7744142659c46ba8b0307aa76a7875f7825b6b0d2d3ebbf26fc55c302c8a88e5.md) | 源码/工程文本 | [0, 11500)、[11500, 23000)、[23000, 30485) |
| [4a61a1d313068b7fce9c0e85.repaired.txt](../texts/7d/7d9c85470b6dcbac95fea40561b1784440bc7f0f7833c004b31501b59eb2342f.md) | 源码/工程文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 43333) |
| [bdf48a2f5672e3d14306124f.txt](../texts/81/8100da139c42a7b6e28f7f85ca27f7f70581919045176241715dcc0847a410f3.md) | 源码/工程文本 | [0, 11500)、[11500, 15431) |
| [9c6fce1fa81fa5a555df54f3.txt](../texts/82/82dab3e97b428b75b21fd57ee9bd8031c0d41aade01c948814dc3e2229fb66d5.md) | 源码/工程文本 | [0, 313) |
| [3e30e39dddca3ad8ffe31e19.txt](../texts/8d/8ded5cb8b4846388310745b92d58d003c3b6a1f6322025229c4955c4a2da61ec.md) | 源码/工程文本 | [0, 12304) |
| [3e30e39dddca3ad8ffe31e19.repaired.txt](../texts/a1/a16bf06a808ce3b621aa2f11c16670dced2da64e4c1a9e1def9de79da90568a5.md) | 源码/工程文本 | [0, 11500)、[11500, 15750) |
| [048f5e8d12f3b79ab47cd6d6.txt](../texts/a3/a3ecd0720a604853c1ad590b8eacc49f81316b9f6d2fc2f3b25947a9df30e17e.md) | 源码/工程文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 40757) |
| [035d8aba6a48ad1f1d560fd3.repaired.txt](../texts/b2/b2f158f96f5e78140720a69b5a29eac59420ac39f3271d7f026f9e649e9fb4da.md) | 源码/工程文本 | [0, 11000)、[11000, 22000)、[22000, 33000)、[33000, 41390) |
| [048f5e8d12f3b79ab47cd6d6.repaired.txt](../texts/ce/ce985fc5c59f53ba33802d706e8c3244e36e220c200b09341fd55f40857728e5.md) | 源码/工程文本 | [0, 48852) |
| [8813efec2ed5ddc18985b961.repaired.txt](../texts/d7/d796ba1ef0c920dfd4638ce7a416e7844049e6252a72a610971ade9f21494649.md) | 源码/工程文本 | [0, 11500)、[11500, 22653) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [baec33d350d293946f342e0b.repaired.txt](../texts/07/071a3b6da088fec1773e48c581273ff3517da94e9124152db3c09d3a0072a871.md)
- [9c6fce1fa81fa5a555df54f3.repaired.txt](../texts/13/13d3751731bc536541ca23ceabd7e7e5c0ef414adec2ea62593d279f62d0e99b.md)
- [c1b357ad9020c23eea63c382.repaired.txt](../texts/1d/1d3825a5b3011b8ee2a24834163062a32b18e39454b749e2b6ff069a5595c2a2.md)
- [eccbaf423f140de1216ae6ab.repaired.txt](../texts/4f/4fd67129c3871ead5052db80ad7bf7c3932d49ff78dbf00f1ee25f2aa31395b7.md)
- [359eaca53133e1d884779736.txt](../texts/57/57badfcf44c3776be9335559403949c7423def59b00c0bdd0f22f34ae049c9b6.md)
- [de0d061e9583cee2281ad33f.repaired.txt](../texts/7a/7ab0a2b788c858880327bd9523b92cf4d8ba5297337597bbad96c0729aadd3a8.md)
- [e51817bba81b4cf0b7d237da.repaired.txt](../texts/9b/9b1c8514f9eafe6dbde9511c2c13a0c9f9a71296f50b6c06634593a96110a68c.md)
- [6ca63ea610bb1b4582d6974a.repaired.txt](../texts/d6/d6209fdd356b1b686c0ba7a0463b3825daef28b81c758126337e43abdf36d09a.md)
- [c9306e94246f0e0654cf0430.repaired.txt](../texts/fe/feb41be5f612d4418cddf61ea6dcf9e058f7985d7792af281a370ab3406ab2d1.md)

## 原研究概要与相关链接

- [11-open-source-projects/06-abm-frameworks/mason.md](../../ai-reference/11-open-source-projects/06-abm-frameworks/mason.md)
- [https://github.com/eclab/mason](https://github.com/eclab/mason)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/LICENSE](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/LICENSE)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/AsynchronousSteppable.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/AsynchronousSteppable.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/AsynchronousSteppable.java#L299-L350](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/AsynchronousSteppable.java#L299-L350)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/IterativeRepeat.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/IterativeRepeat.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/IterativeRepeat.java#L43-L72](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/IterativeRepeat.java#L43-L72)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Schedule.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Schedule.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Schedule.java#L316-L367](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Schedule.java#L316-L367)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/SimState.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/SimState.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/SimState.java#L231-L277](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/SimState.java#L231-L277)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Steppable.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Steppable.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Steppable.java#L9-L13](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/Steppable.java#L9-L13)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/SparseField.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/SparseField.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/SparseField.java#L270-L299](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/SparseField.java#L270-L299)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/continuous/Continuous2D.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/continuous/Continuous2D.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/continuous/Continuous2D.java#L530-L569](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/field/continuous/Continuous2D.java#L530-L569)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/util/Bag.java](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/util/Bag.java)
- [https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/util/Bag.java#L366-L378](https://github.com/eclab/mason/blob/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/util/Bag.java#L366-L378)
- [https://github.com/eclab/mason/commit/08c95296de1b4fa73635e0c301ca9a272af8749e](https://github.com/eclab/mason/commit/08c95296de1b4fa73635e0c301ca9a272af8749e)
- [https://raw.githubusercontent.com/eclab/mason/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/AsynchronousSteppable.java](https://raw.githubusercontent.com/eclab/mason/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/AsynchronousSteppable.java)
- [https://raw.githubusercontent.com/eclab/mason/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/IterativeRepeat.java](https://raw.githubusercontent.com/eclab/mason/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/engine/IterativeRepeat.java)
- [https://raw.githubusercontent.com/eclab/mason/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/util/Bag.java](https://raw.githubusercontent.com/eclab/mason/08c95296de1b4fa73635e0c301ca9a272af8749e/mason/src/main/java/sim/util/Bag.java)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
