# QuadTree or Spatial Hashing in ECS ? — Reddit 1jopdn4 可见讨论

- 分类：导航、人群、交通与空间协调。
- 资料标识：`reddit-post:1jopdn4`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：u/lieddersturme（主帖）；u/kit89（自述四叉树实现）；u/ten3roberts、u/F300XEN、u/meheleventyone（取舍意见）。
- 原目录日期：2025-04-01（沿用已有记录）。
- 主要来源：[https://www.reddit.com/r/gamedev/comments/1jopdn4/quadtree_or_spatial_hashing_in_ecs/](https://www.reddit.com/r/gamedev/comments/1jopdn4/quadtree_or_spatial_hashing_in_ecs/)

## 概要与项目参考

空间索引选择的初级权衡和候选类型过滤可参考；没有 ECS 更新代码、日常 AI 或真实规模数据，证据强度低于实现资料。

## 已有机制分析

source_fact: 提问为 2D C++/SDL2 bullet hell，实体尺寸 16/32/64，并询问碰撞空间划分与 A* 集成。回复指出适合碰撞的空间划分未必适合路径规划。
domino_suggestion: 保留感知/近邻候选索引与有向道路导航的独立查询语义，不把四叉树或空间哈希当路径算法。
source_fact: 回复对比四叉树适应密度/聚集但要处理跨节点对象、不能继续细分的情况；网格可能浪费空格内存，字典式哈希可能带来散乱访存与哈希成本。均未给实现或基准。
domino_suggestion: 以城市/区域有限网格、稀疏活跃桶和稳定 ID 为简单起点，明确大对象跨桶、移动、删除和热点密度的维护规则。
source_fact: 一位评论先减少碰撞关系类型：敌弹只关心玩家、己方弹只关心指定实体；另建议抽象查询以便更换结构。最后评论提出 navmesh 分割和自己的四指针树节点，只是经验自述。
domino_suggestion: 先按服务/刺激/参与者类型限定可交互关系和候选，再选结构；查询契约比同时引入两套索引更有价值。

## 后续行为与玩法启发

调查与犯罪目击可以先查局部可听/可见候选，进一步判断遮挡和个人知识，附近 NPC 不能自动成为知情者。

交易地点、协作参与者和社交冲突可按空间与实体类型缩小候选；玩家移动/删除对象后索引需更新并由执行端核查。

正文不包含欺骗或处罚机制，这些是 Domino 推论。

## 适用范围与局限

没有 10000+ 测量。“非移动端无所谓”是泛泛评论，不适用于密集开放世界假设。需限制每批桶访问/候选/精查，处理广场聚集导致近似全对、空世界巨大网格、哈希散乱访存；返回少量 K 不证明遍历少。

隐藏索引实现并公开稳定查询语义，避免四叉树节点边界耦合业务或 nav。

清楚定义跨桶实体、不可细分的高密度叶子和删除后的 ID 有效性。

相对 2y 时间和作者性能判断未验证，不能据取回日推算精确发帖日期。

适合碰撞的分桶未必包含可通行连接，不能推出 A* 正确。

高密度叶子仍可能需要大规模局部配对。

评论自报四指针布局没有给缓存/删除/内存测量。

仅换索引而不限制可能交互类型可继续产生无效全对查询。

当前本地载体全部读完，非完整 Reddit 评论树，折叠/删除/抽取遗漏不可见。

未读链接目标、代码或实测数据。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [1jopdn4-visible-discussion.md](../texts/02/022918d848ce2311d55fac51d3d1f90638f9d53551c2c9dcf7c2241f49ad3769.md) | 讨论正文/已载入评论 | [0, 2600)、[2600, 4828) |

## 原研究概要与相关链接

- [14-three-sites-2026-10-04/03-world/spatial-queries/content/1jopdn4-visible-discussion.md](../../ai-reference/14-three-sites-2026-10-04/03-world/spatial-queries/content/1jopdn4-visible-discussion.md)
- [https://www.reddit.com/r/gamedev/comments/1jopdn4/quadtree_or_spatial_hashing_in_ecs/](https://www.reddit.com/r/gamedev/comments/1jopdn4/quadtree_or_spatial_hashing_in_ecs/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
