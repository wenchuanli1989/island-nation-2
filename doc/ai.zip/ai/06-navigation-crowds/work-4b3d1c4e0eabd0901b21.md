# Advanced NavMesh Usage - Beyond Simple SetDestination | Unity Tutorial

- 分类：导航、人群、交通与空间协调。
- 资料标识：`youtube:JrnTHOZCzWQ`。
- 已有内容：字幕/转录文本。
- 原目录作者：Chris Kurhan / LlamAcademy。
- 原目录日期：2025-07-15（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=JrnTHOZCzWQ](https://www.youtube.com/watch?v=JrnTHOZCzWQ)

## 概要与项目参考

Domino 推论：行为目标是可互动位置/攻击范围，而非另一人物中心坐标；不同能力/区域可行性应生成不同导航终点。
建筑级常态移动可保留，未来潜入/追捕按需要细化局部区域与互动距离；当前Floyd边权不自动变实际长度或ETA。

## 已有机制分析

原作：目标在另一不可达navmesh时，将目标位置改为己方可行区域的射线边界或SamplePosition命中；query filter按agent类型和area masks筛选。
原作：大型攻击者取目标collider最近点、投影到自身Y平面，组合raycast与sample命中，后退agent radius形成停靠点；目标位置变化超过stopping distance才重设destination。
原作动作以Running等待path pending、attack range或remaining distance来结束；含采样失败时直接设velocity的作者fallback。

## 后续行为与玩法启发

Domino建议：守卫在围墙/平台上观察，调查员到可见/可询问位置，盗窃者接近柜台/货物可触及点；玩家封路、关门、挪动物品会改变交互候选及执行结果。

Domino建议：物理不可达/身体类型限制可以排除端点，法律禁止/主人不允许进入应另成许可和风险信息；违法潜入仍可做物理候选。

Domino建议：逃逸/追捕选择掩体或封锁边界，协作交接货物在共同可达点会合，而非要求双方重叠到中心坐标。

隔楼观察、围栏外追捕、屋顶守卫、隔门交易可在可行互动区域停下；玩家封锁入口可使NPC换停靠点或明确失败。

攻击/发现是否成功还需视线、遮挡、武器范围与真实目标状态，不能以导航边界命中判定命中或目击。

## 适用范围与局限

源示例仍每frame查询位置/射线，第一动作每frame设置destination；阈值只减少第二动作目的地重设，未消除查询成本。10000NPC照搬将有全体感知/路径请求峰值。

Domino建议：按目标/路网revision和移动阈值唤醒、限查询频率，常态图节点端点缓存；只有参与局部强玩法NPC用细区域查询。

无10000NPCbenchmark；UnityNavMesh开销与C Floyd当前实现不可等同。

原作一方案每帧重raycast/sample/setdestination，不适合10000个NPC常态全员使用；用目标/区域变化事件、变化阈值与有界重算。

最近点/平面距离不是路线长度，SamplePosition命中不证明连通性；无万人数据，Unity API不能直接移植C23图导航。

把交互端点选择做类型ops，通用移动生命周期只处理运行/失败/取消/到达；类型过滤与目标几何参数分离。

Unity APIs不直接迁移C；绑定稳定ID/区域版本，存档恢复重建几何查询而保留行为意图/进度。

分离领域互动终点选择、路线求解与动作到达确认，保持公共移动生命周期和少量类型参数。

领域失败明确反馈原因；保留目标修订避免旧path完成回调提交当前行为。

几何最近点不保证可达、路径最短或能攻击；raycast首先碰到的mesh边缘未必是应去的目标边缘。

无path不pending也可能是路径失败，不能当已到达；到端点也不证明攻击/询问/交易成功。

强行velocity fallback可能破坏物理边界或忽略失败原因，Domino应返回明确失败/替代候选而非绕过资源/空间约束。

忽略Y对T-Rex例有效，跨楼层/潜入/垂直视线未必适用。

作者把无path且不pending当到达，路径失败也可满足该条件；Domino必须核实位置/路线结果。

直接velocity fallback可能绕过区域或物理限制，应明确失败/重选，不能为避免站立自动穿越。

navmesh raycast不是物理遮挡射线，投影最近点可能位于不可连通岛屿。

完整读取15329字符字幕0:00-11:08，未看演示/源码；自动字幕含坐标平面及术语误识。

提名交互端点/不同移动域机制，非推荐改全世界NavMesh或照搬fallback。

全文导出字幕已读，含头部language en/captions authored or unspecified；未看视频、Unity代码、动态图/碰撞实际效果或完整GitHub项目。

无取消、占用、存档恢复和万人性能证明，按目的选择路径终点的机制可单独吸收。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [transcript.txt](../texts/21/218cbc1fdc1b8b5a3c723a295d7c51ad84ea3b84153bdea7a2f8e3b03e079dcb.md) | 字幕/转录文本 | [0, 11000)、[11000, 15329) |
| [browser-export.txt](../texts/fc/fc3861a1c55ba39c32fabd652971a254609e12dee4beca6b5916306a0903da52.md) | 字幕/转录文本 | [0, 11500)、[11500, 15417) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/05-dynamic-routes-cache.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/05-dynamic-routes-cache.md)
- [https://github.com/llamacademy/dino-attack/blob/72c45e60c6b1ae7aa933c8dfb6047426437a0275/Assets/LlamAcademy/Dinos/Behavior/MoveToTargetOrEdgeOfNavMeshAction.cs](https://github.com/llamacademy/dino-attack/blob/72c45e60c6b1ae7aa933c8dfb6047426437a0275/Assets/LlamAcademy/Dinos/Behavior/MoveToTargetOrEdgeOfNavMeshAction.cs)
- [https://github.com/llamacademy/dino-attack/blob/72c45e60c6b1ae7aa933c8dfb6047426437a0275/Assets/LlamAcademy/Dinos/Utility/NavMeshUtilities.cs](https://github.com/llamacademy/dino-attack/blob/72c45e60c6b1ae7aa933c8dfb6047426437a0275/Assets/LlamAcademy/Dinos/Utility/NavMeshUtilities.cs)
- [https://llamacademy.dev/tutorials/](https://llamacademy.dev/tutorials/)
- [https://llamacademy.dev/tutorials/JrnTHOZCzWQ/](https://llamacademy.dev/tutorials/JrnTHOZCzWQ/)
- [https://www.youtube.com/watch?v=JrnTHOZCzWQ](https://www.youtube.com/watch?v=JrnTHOZCzWQ)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
