# Pathfinding conundrum

- 分类：导航、人群、交通与空间协调。
- 资料标识：`reddit-post:duwh3z`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：u/Dracon270; visible answer u/SayAllenthing。
- 原目录日期：2019-11-11（沿用已有记录）。
- 主要来源：[https://www.reddit.com/r/gamedev/comments/duwh3z/](https://www.reddit.com/r/gamedev/comments/duwh3z/)

## 概要与项目参考

访问策略与门操作路径成本的小而明确机制，适合未来局部室内玩法；缺实现/验证且整图copy建议不适合直接采用。

## 已有机制分析

source_facts: 主帖角色不同：员工可开所有门、客人不应开staff或他人房门；在下一步遇门触发脚本但打不开会卡住，按角色建多grid可能存储膨胀。
回复建议默认锁门不可通过，按请求代理的门/房访问集合在查询中设可通；开门耗时可给门更高weight而避免抄近路穿办公室。
深层搜索可见回复给copy grid再修改代理可开格的示例，另允许暂改后还原；该条无作者/permalink且不代表全thread。
domino_recommendations: 共享拓扑加个人能力/访问策略filter，而非每NPC一份全图；搜索上下文独立，不临时污染共享图。
严格分门客观锁定、人物钥匙/工具能力、组织授权、个人已知与意图；合法通行、破锁/潜入等不同任务候选有不同耗时/风险。
实际开门、破门、移动经过与目击由执行提交，路径预计通过不等于当前已开或有权限。

## 后续行为与玩法启发

source_facts:
原帖只讨论员工/客人的门访问，没有违法行为实现。

domino_recommendations:
玩家借钥匙、上锁、堵门、撤职可改变人物常规路线；无许可但能破锁的犯罪仍可列物理可行候选，额外风险/制度后果分开。

潜入/追逐需要局部房间细化，不把同楼常规免移动扩为所有室内空间等价。

发现门损坏与发现人物开门是不同观察，调查归因不能自动由访问日志/关系推出来。

## 适用范围与局限

无运行性能，主帖担忧多grid的规模是问题不是验证。

共享图加有限参数查询可避免O(N*V)全复制；临时修改再还原在异步/并发会数据竞争，需单一owner或私有投影。

更高weight只是预期cost，Domino任意道路权重不等于真实distance/ETA。

角色访问定义与个人钥匙/状态实例分开，变化revision使依赖的旧路径失效。

门动作明确启动/等待/取消/完成和占用释放；帖子未提供这些实现。

未具名搜索回复与正式可见thread内容分别记录证据可信范围。

把locked视为绝对物理不可行会排除可破门/尾随的犯罪扩展；制度禁止不是空间不可达。

未经同步暂改共享grid再复原会污染其他查询或遗漏复原。

以query前有钥匙推执行必成功会忽略钥匙丢失/门更新/拥堵。

完整读取3527字符本地主帖与四可见回复加一搜索片段，隐藏回复未展开、无代码/运行审计。

hint为associated_analysis，实际原社区正文摘录已纠正。

搜索深回复作者及permalink未知，不能与主回复同可信范围或当正式算法证明。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [reddit-duwh3z-visible.md](../texts/23/237b911ec25fd5e63fc77c5976f940ddd65b362c8141ee88d1975422cf7f4a07.md) | 讨论正文/已载入评论 | [0, 3527) |

## 原研究概要与相关链接

- [14-three-sites-2026-10-04/03-world/road-changes/reddit-duwh3z-visible.md](../../ai-reference/14-three-sites-2026-10-04/03-world/road-changes/reddit-duwh3z-visible.md)
- [https://www.reddit.com/r/gamedev/comments/duwh3z/](https://www.reddit.com/r/gamedev/comments/duwh3z/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
