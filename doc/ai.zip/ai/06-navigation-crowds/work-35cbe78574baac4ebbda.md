# Cooperative Pathfinding Experiments

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://arongranberg.com/2015/06/cooperative-pathfinding-experiments/`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：Aron Granberg。
- 原目录日期：2015-06-21（沿用已有记录）。
- 主要来源：[https://arongranberg.com/2015/06/cooperative-pathfinding-experiments](https://arongranberg.com/2015/06/cooperative-pathfinding-experiments)

## 概要与项目参考

Domino建议：建筑/路段常态导航保持当前图/Floyd职责，只有窄门、队列、封锁、室内追逐需要局部时间容量/让行；图权重不等于实际距离或ETA。
预留是未来意图，实际移动/占用由执行者验速度、位置、冲突后推进；取消/改路需释放旧预留并隔离旧到期，保存实际位置/进度重建短期预留。

## 已有机制分析

作者实验：搜索节点从空间square变为(square,time)，路径带抵达tick，顺序规划后立即预留空间时间节点；后规划者避开先规划者预留。
有限20/40 tick视野与启发式剪枝控制搜索；等待惩罚对近期较高，让静止者早让路并可回原位置，需几轮重规划协商。
将静止占位由硬预留改大成本可加速密集排列，但允许重叠；文末明确同速/无推挤物理/单格体积/单搜索线程/无links限制且不保证最优或能找到解。
评论提出半速以连续tick预留、多格大小及HPA*减少搜索范围；作者区分未实现想法和已试验，并承认没测试fringe-search建议。

## 后续行为与玩法启发

玩家堵窄走廊、封锁入口、潜入/逃逸、追捕或物流协作能产生等待/回退/改路因果；同时需要门禁、视线与空间细化，不能全建筑等价。

违法候选仍可存在，但真实容量/体积不可绕过；软预留允许重叠适合视觉人群时，不可用于偷窃接触、目击或实体碰撞的事实结算。交易队列可预留服务时段而非全球空间。

## 适用范围与局限

20 tick约放大空间时间搜索候选20倍；共享基础节点减少复制却仍需时间预留存储与反复重规划；作者实现串行，不能给万人全世界逐人高频套用。

Domino局部瓶颈限定人数/视野与重规划预算，导航共享路线/粗距离，只有玩家相关冲突细化；密集场景视野不足/优先级饥饿需业务解法。

普通C可独立实现短期占用表+局部路径/等待状态，不直接替换全世界Floyd或引入通用MAPF求解器。

实际速率改变、路线取消、硬软容量与占用释放应有可核原因；算法内容成本高于示例所展示的固定同速格子。

先规划者不知道后规划者目标，prioritized planning可能不给某人通道或导致死锁；不保证有解/最优明确写在原文。

物理推挤、不同速度、不同体积、特殊link及临时新人物会破坏原预留；未来提议不等于执行位置。

静止者硬占位可长等，软惩罚减少等待却允许重叠；不能同时宣称严格无碰撞和用软占位获得的密集表现。

完整读本地文章及四条评论文字，没观看嵌入视频/图片或复现；作者说当时尚未稳定/未发布，不能当当前产品功能事实。

相同作品的两个alias不可重复排名；评论建议与作者实验分开。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [64227012e2afb4448e844c8f.txt](../texts/a3/a39924e55dfcc2423317f1a435d50bf28d546d1e6093ef7d8fc27ad1b1b13515.md) | 讨论正文/已载入评论 | [0, 9693) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md)
- [https://arongranberg.com/2015/06/cooperative-pathfinding-experiments](https://arongranberg.com/2015/06/cooperative-pathfinding-experiments)
- [https://arongranberg.com/2015/06/cooperative-pathfinding-experiments/](https://arongranberg.com/2015/06/cooperative-pathfinding-experiments/)
- [https://www.youtube.com/watch?v=B-OoL2bOXl0](https://www.youtube.com/watch?v=B-OoL2bOXl0)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
