# How to make NavigationAgent2D to use a Warp Point to go faster

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：cidwel（Godot 4.X 使用者）；smix8（Godot 导航维护者，答复者）。
- 原目录日期：2024-05-18（沿用已有记录）。
- 主要来源：[https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084)

## 概要与项目参考

具体低层寻路与高层特殊通行分层及缓存成本反例，适合未来有条件跨区活动。

## 已有机制分析

source_facts: 2024-05-18讨论：用户把warp link travel/enter cost置0但路径仍不用；smix8称default AStar/NavigationAgent无法可靠处理teleporter。
建议高层映射teleport及cached path cost，比较普通路线与当前位置→入口＋出口→目标的合成路径。
选择portal后保存原目标、暂以portal入口为目标，使用后恢复；较大mesh每查询每portal多次全图搜索昂贵，可按region字典先高层筛选。
domino_recommendations: 跨层通道/渡轮/特殊门等可以提供有限高层候选，局部路段和跳转动作明确交接；不直接改当前Floyd架构。
候选path cost与距离/ETA分清、版本随拓扑/入口权限变更失效；执行抵达入口并取得服务确认后才跨区域。
按region过滤少数门户再查询局部段，避免每NPC枚举全世界所有portal。

## 后续行为与玩法启发

玩家关闭门/购买船票/提供通行信息、占通道会改变候选；潜入或走私可用私有入口与规则许可差异。

门户进入、收费/等待/跨区完成有真实效果链，用户可阻断；不能计划选择即瞬移。

## 适用范围与局限

原文明确每portal多次完整navmesh查询昂贵，region→portal稀疏映射和缓存可减搜索；没有实测规模。

多portal链/动态容量/时间窗不在此简单一次warp比较内，无万NPC吞吐保证。

保存最终目标与中途目标分开可复用到有限任务模板；稳定入口ID、版本、原因比直接重设唯一target更易恢复。

用户最后仅认为可行，未给实际复现结果；发言者身份来自论坛名，不冒称源码维护者证明。

使用零cost普通link不保证搜索采纳warp，默认寻路模型与瞬时通行语义可能不一致；线程没有证明具体根因。

入口不可达/出口失效/需多跳/真实服务等待会破坏简单比较；条件暂满不等于拓扑不可达。

Portal动作用旧计划完成不得恢复覆盖新目标；角色已中断时只清理原动作资源。

完整读4262字符9帖讨论；图片未视觉检查、未运行示例或Godot源码审计。

建议性线程未显示最终实施/基准，不能称通用最优多portal算法。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [bc7c315ba8fe15eae84879a3.txt](../texts/9a/9a564554dcf86e263ea2b22d7be19dd2655acfff5b92e8cbd6554dd928aa0039.md) | 讨论正文/已载入评论 | [0, 4262) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md)
- [https://forum.godotengine.org/t/62084.json](https://forum.godotengine.org/t/62084.json)
- [https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084)
- [https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/6)
- [https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/8](https://forum.godotengine.org/t/how-to-make-navigationagent2d-to-use-a-warp-point-to-go-faster/62084/8)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
