# Dynamic Tree Improvements

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://box2d.org/posts/2025/03/dynamic-tree-improvements/`。
- 已有内容：文章/文档正文。
- 原目录作者：Erin Catto，Box2D 作者/维护者。
- 原目录日期：2025-03-21（沿用已有记录）。
- 主要来源：[https://box2d.org/posts/2025/03/dynamic-tree-improvements/](https://box2d.org/posts/2025/03/dynamic-tree-improvements/)

## 概要与项目参考

Domino建议：若局部目击/运动对象大小差异大，可评估动态AABB树而不是每次全图或全员扫描；这是未来感知索引选择，不替换Floyd路径权重语义。

## 已有机制分析

源事实：动态树插入按SAH总内部面积增量选新proxy的兄弟，单路径下降且可任意层停下，不做穷尽搜索。
源事实：directCost=Area(Union(D,S))，inheritedCost累积祖先包围增量；叶代价精确，内部节点用乐观下界，并取选择当前孩子/后代下界的min夹紧。

## 后续行为与玩法启发

玩家潜入、追逐、移动遮挡物和封锁设施能以粗空间候选触发查询，随后仍需LOS、能力、真实观察和个人知识判断。

## 适用范围与局限

每次只走树一路降低插入搜索，成本随高度；本文未证明平衡树高度或万人每帧更新吞吐。

密集重叠、大量移动重插和失衡仍可导致候选/维护成本高；SAH优化平均ray visits不保证每个查询。

成本公式短、普通C可表达，叶/内部分开便于审查；需另核删除、移动、平衡与proxy生命周期接口。

贪心一次插入不能保证全局最佳树，作者据此拒绝穷尽搜索。

空间包围命中不是到达、目击或法律归因；小高度优化不解决全体高频查询。

完整3467字符公式说明已读，未读Box2D实现、完整动态树操作或运行benchmark；原文变量有拼写笔误。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [3bd7f10605ec9a5ea1f6c364.txt](../texts/18/18d165ecabf9ecd8e2107ff64de7dddb0001cc2bddf22d00b1804e45db21fbf6.md) | 文章/文档正文 | [0, 3467) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/05-spatial-index-perception.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/05-spatial-index-perception.md)
- [https://box2d.org/posts/2025/03/dynamic-tree-improvements/](https://box2d.org/posts/2025/03/dynamic-tree-improvements/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
