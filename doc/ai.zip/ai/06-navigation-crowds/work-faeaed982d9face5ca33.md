# Sebastian Lague Ant-Simulation Ant.cs at e638aa267e0b58eb0092b9c15a2732c501baa2b0

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-repository-bundle:seblague/ant-simulation@e638aa267e0b58eb0092b9c15a2732c501baa2b0`。
- 已有内容：源码/工程文本。
- 原目录作者：Sebastian Lague。
- 原目录日期：2021-03-25（沿用已有记录）。
- 主要来源：[https://raw.githubusercontent.com/SebLague/Ant-Simulation/e638aa267e0b58eb0092b9c15a2732c501baa2b0/Assets/Scripts/Ant.cs](https://raw.githubusercontent.com/SebLague/Ant-Simulation/e638aa267e0b58eb0092b9c15a2732c501baa2b0/Assets/Scripts/Ant.cs)

## 概要与项目参考

Domino建议：有限局部感知、错峰更新和实际到达后提交收益可抽取；Unity的逐帧GameObject和Time.time不能直接替换未冻结现实毫秒业务轴。
资源目标预约应成为可释放的显式业务记录，不用修改渲染/感知layer作为唯一所有权。

## 已有机制分析

低成本方向决策与每常运動分开，随机相位分散方向更新峰值；局部标记随现实运行时间衰减。
目标选择、占用式排除、实际拾取和送达效果分别发生，送达才计收集成果。
共享环境痕迹指导局部动作，个体无需复制整个导航/信息素世界。

## 后续行为与玩法启发

可为野生动物觅食或玩家诱导生态引流提供局部信号；人的调查应从实际足迹/观察建立信念，不能把信息素场直接当多人共同知识。

足迹/痕迹衰减可启发追踪、引诱、伪造线索；查询到痕迹只形成观察信念，不能自动认定犯罪身份。

玩家搬走资源、阻断返回路或投放诱饵可改变搜集任务，失败/死亡时需要回收预约与携带物。

## 适用范围与局限

每Ant预分配1024个PerceptionMap.Entry，10000个即1024万entries，尺寸未读定义不能捏造字节数；再含managed对象、transforms和碰撞成本。

三raycast每帧、OverlapCircle、最多三次局部marker扫描使10k长期成本不明，timeBetweenDirUpdate只限信息素方向，不限整个Update。

本文件不见PerceptionMap实现，不能声称空间grid或邻域查询复杂度为O(1)。

三个局部探针与非分配食物查询有界，但每人1024信息素Entry缓存乘10000即1024万条槽位，元素大小未读。

每帧每人多次raycast和Transform写入仍可能昂贵；PerceptionMap实现/截断策略未读，不能确认查询复杂度或万人性能。

handlers职责直观，settings与个体状态分开；若借鉴用扁平数组/shared配置/ID引用。

Time.time/float/Unity帧时间不满足Domino累计未冻结现实ms合同；死亡/占用/状态存档须另做。

设置共享、运行状态独立有价值；将行为领域逻辑拆为ops，统一取消/占用清理。

碰撞、方向、目标、寿命混在单Ant类，新增人类承诺和复杂互动应避免继续扩张此风格。

选目标即隐藏layer，无超时/失败/取消释放；走不到食物或ant死亡会遗留/毁掉资源，不能用于盗窃/交易结算。

Destroy后Update仍继续调用后续handlers，Unity实际销毁时机不在本文件；不能当安全生命周期范本。

food buffer只有1项，Random.Range(0,numFoodInRadius)并不随机挑全体候选；GetRandomDir的similarity参数未使用。

信息素Add权重t存在，当前求和只见年龄strength，未见使用entry持有强度字段，不能推断完整field模型。

寻找阶段已把目标layer置0，若蚂蚁死亡或任务放弃，没有此文件中的释放路径，目标可从候选中残留消失。

只有局部力可能在障碍间循环，不能保证到达；两个状态不表达拒绝、挂起、失败或存档恢复。

食物真实对象与标记分离；不能由信息素强度直接结算食物或物流成果。

10601字符1窗口完整代码；未看Coding Adventure录像或审计AntColony/PerceptionMap/settings，未执行Unity。

完整读取单Ant.cs，不是完整视频或整个Unity工程审计；PerceptionMap/设置/巢实现未读。

机制适合动物/局部移动参考，人类任务和犯罪因果需另外建模。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [3dc93d35f30821ea96809304.repaired.txt](../texts/1f/1f96b2e4a3077707cc6f3421fdde8716c2cebc39e5504fbb06b87a0af1d62fbb.md) | 源码/工程文本 | [0, 11000)、[11000, 11373) |
| [3dc93d35f30821ea96809304.txt](../texts/2b/2bf4176a2099e797e6bc8ef7c9dd9b51223ce8d2e4e2bc76eb97add1f987e493.md) | 源码/工程文本 | [0, 10601) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/10-methods-frontiers/09-procedural-world-ecology.md](../../ai-reference/13-youtube-2011-2026/10-methods-frontiers/09-procedural-world-ecology.md)
- [https://github.com/SebLague/Ant-Simulation/blob/e638aa267e0b58eb0092b9c15a2732c501baa2b0/Assets/Scripts/Ant.cs](https://github.com/SebLague/Ant-Simulation/blob/e638aa267e0b58eb0092b9c15a2732c501baa2b0/Assets/Scripts/Ant.cs)
- [https://github.com/SebLague/Ant-Simulation/blob/e638aa267e0b58eb0092b9c15a2732c501baa2b0/README.md](https://github.com/SebLague/Ant-Simulation/blob/e638aa267e0b58eb0092b9c15a2732c501baa2b0/README.md)
- [https://github.com/SebLague/Slime-Simulation/blob/6794cfdf584f71c657bd16366e31bf422be99ee6/Assets/Scripts/Slime/SlimeSim.compute](https://github.com/SebLague/Slime-Simulation/blob/6794cfdf584f71c657bd16366e31bf422be99ee6/Assets/Scripts/Slime/SlimeSim.compute)
- [https://github.com/SebLague/Slime-Simulation/blob/6794cfdf584f71c657bd16366e31bf422be99ee6/README.md](https://github.com/SebLague/Slime-Simulation/blob/6794cfdf584f71c657bd16366e31bf422be99ee6/README.md)
- [https://raw.githubusercontent.com/SebLague/Ant-Simulation/e638aa267e0b58eb0092b9c15a2732c501baa2b0/Assets/Scripts/Ant.cs](https://raw.githubusercontent.com/SebLague/Ant-Simulation/e638aa267e0b58eb0092b9c15a2732c501baa2b0/Assets/Scripts/Ant.cs)
- [https://www.youtube.com/watch?v=X-iSQQgOd1A](https://www.youtube.com/watch?v=X-iSQQgOd1A)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
