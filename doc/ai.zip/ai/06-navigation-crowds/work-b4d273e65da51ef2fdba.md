# Distributed Multi-agent Navigation Based on Reciprocal Collision Avoidance and Locally Confined Multi-agent Path Finding

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:a0ed55392f847668e530e5e16fb0033964a6216f6d797933c656195bc3bc0eee`。
- 已有内容：论文/讲义提取文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Stepan Dergachev; Konstantin Yakovlev。
- 原目录日期：2021-07-01（沿用已有记录）。
- 主要来源：[https://arxiv.org/pdf/2107.00246](https://arxiv.org/pdf/2107.00246)

## 概要与项目参考

直接补充全局路径之外的窄通道死锁与局部协作接口，为未来需要细粒度室内/街道拥堵的玩法提供方案；无需把整世界迁移到grid/MAPF。

## 已有机制分析

source_facts: 个体Theta*几何路+ORCA反应避碰；当自己k步均速低且邻居也低时判死锁，组N(i)+N(N(i))共享位置/waypoints建一致局部模型。
局部bbox加offset裁grid，按共享unique priority分配不重复最近起点及最靠近原waypoint可达终点；先moveToMAPFStart，全员就绪后同步执行。
每代理运行deterministic同MAPF：先PushAndRotate找可行方案，再ECBS找有ε界较低成本方案，共同timecap；外来agent靠近重新纳入求解，全员到局部终点回normal。
等待MAPF结束的零速度暂报告Vmax，避免重新误触发死锁；最坏两solver未成功仍回normal、可能未解死锁。
实验5..40代理/四map每规模250任务，i5-8259U16GB、timecap1秒；Gaps3 40人99%成功，Rooms40人约95次调用且平均10参与者。
domino_recommendations: 将常态建筑级/道路路由与堵塞现场局部区域分开，只在明确停滞持续现实_ms后启动有限范围协调。
单物理机可让一个局部协调任务计算共享计划，避免每参与NPC重复求解；参与人、计划版本、资源/路段占用和进度归个人executor验收。
进入/就绪/推进/终结状态及外来干扰有明确边界；冻结或中断需保留真实位置/释放可撤销占用，不能以规划路径直接更新到达事实。

## 后续行为与玩法启发

cooperation:
狭路会车、搬运队伍让行与物流等待可形成真实互相阻挡并有局部协调。

crime_investigation:
潜入、封锁、追捕需要局部区域粒度；追逃/蓄意阻挡者不必接受互惠让路，其行为许可不能被算法强制协调。

trade:
路段堵塞影响配送和到货承诺，基于实际进度而非全局route weight结算。

player_intervention:
玩家堵门、移动障碍、加入/退出队伍触发局部计划失效与替代。

## 适用范围与局限

局部两层邻域比全员MAPF可控，但高密度可扩大至很多人、外来agent反复触发重解；应设参与者/范围/事件合并与求解预算。

原文每代理重复确定求解放大成本，单机可一次共享局部解；算法复杂度与10000吞吐未给。

k250步、vlow0.001、ε10与1秒为论文场景调参，不是Domino时间/平衡常量；按累计未冻结现实_ms定义停滞。

三mode和局部规划步骤清楚；少量公共生命周期字段即可追踪，无需通用全NPC求解框架。

随机priority须作为共享事实/seed和稳定参与ID保存，不因每代理独抽导致解不一致。

完美位置/同步控制简化取消/拒绝/碰撞失败；实际executor需检查版本与实际位移。

静态已知grid、同质圆盘、完美控制通信、uniform cardinal move不能证明不同速度伤员/车辆或动态场景安全。

到MAPF起点仍依赖ORCA可继续死锁，作者解释非100%成功；两solver失败也可能回原死锁。

ECBS可大量超时；Rooms40agent95次调用显示频繁重解风险。

非合作犯罪者、警察追捕不能被自动当愿意让路的互惠代理；机构封锁不是单纯避碰障碍。

全文34027字符均读；PDF图表只有提取文字，未视觉核看，配视频未观看。

未审查C++代码或复现实验；最大40人，不是万人性能证据。

目前Domino全局路图不含该精细碰撞模拟，属于后续按场景启用。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [ccc895362dc0ec613a53d402.txt](../texts/50/5049c42e02fa8b6367c8ce2c6f4655486fc3e2018fa77c0ecd128c9c0de8c54d.md) | 论文/讲义提取文本 | [0, 11000)、[11000, 22000)、[22000, 34000)、[34000, 34027) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md)
- [https://arxiv.org/abs/2107.00246](https://arxiv.org/abs/2107.00246)
- [https://arxiv.org/pdf/2107.00246](https://arxiv.org/pdf/2107.00246)
- [https://arxiv.org/pdf/2107.00246.pdf](https://arxiv.org/pdf/2107.00246.pdf)
- [https://github.com/PathPlanning/ORCA-algorithm](https://github.com/PathPlanning/ORCA-algorithm)
- [https://www.youtube.com/watch?v=jE2YrXQ_pNs](https://www.youtube.com/watch?v=jE2YrXQ_pNs)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
