# Route Planning with Breaks and Truck Driving Bans Using Time-Dependent Contraction Hierarchies

- 分类：导航、人群、交通与空间协调。
- 资料标识：`youtube:7PEGqFWjreg`。
- 已有内容：字幕/转录文本。
- 原目录作者：Marieke S. van der Tuin; Mathijs de Weerdt; G. Veit Batz。
- 原目录日期：2019-05-31（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=7PEGqFWjreg](https://www.youtube.com/watch?v=7PEGqFWjreg)

## 概要与项目参考

提供时间/生理资源约束路线不能仅按静态权重的具体反例，连接human任务时长、行动可行性和路径估算；值得作为导航扩展候选。

## 已有机制分析

source_facts: 按出发时刻路段禁行函数计算等待与行驶；等待不消耗驾驶班次，休息可与禁行等待重叠。
stacked break graph复制成未休/已休两层，跨层边包含驾行与在边上休息；另跟踪自上次休息累计驾驶时长。
同节点较早到达但更长连续驾驶不一定支配晚到但较短驾驶路径；multi-label Pareto保留到达时间和班次时长均不被支配状态，普通Dijkstra单标签会漏解。
时间依赖CH组合/合并旅行函数，查询启发式采用最晚休息或禁行时休息，multi-label遍历预处理图；CH只保留时变最短路可能丢掉最优休息路径，讲者明确为启发式。
10000欧洲OD测试，原multi-label平均13/24秒查询；启发式在其样例均相同结果，有显著加速但不是一般最优保证。
domino_recommendations: 当前Floyd权重可继续作抽象导航候选；未来加入疲劳、等待、开门/封路和约定截止时，ETA需根据状态与真实ms计算，不能直接把最小路径权重当耗时。
优先给有限近期移动模板显式等待/休息步骤与资源状态；当单标签确实遗漏可行替代路线且成本有依据时才升级多标签/专门路由。

## 后续行为与玩法启发

适用于物流、护送、换班、封路与玩家阻断路线；非法驾驶/潜入要分物理疲劳约束与制度禁令，禁令可作为主观处罚风险候选，不一律硬删。

玩家封路、改变通行窗口/仓库营业、提供休息地和协助驾驶可改变到达时刻与合同履行。

非法越禁行应是NPC可选的制度违规路线与风险，不能一律与物理不可行混同；疲劳/燃料/通行障碍仍必须真实满足。

物流/护送合作角色、多司机、停车容量是扩展，演讲未实现多司机。

## 适用范围与局限

测试10000起终点对，非10000同时NPC；原multi-label平均13/24秒每query，CH缩短约150倍或18倍是作者试验主张。

多标签数量可能增长，预处理更新成本/动态道路修改未展示，万级需局部候选与查询预算。

每节点Pareto标签可爆炸，逐NPC全图约束搜索的秒级原方法不适合10000实时个体。

CH预处理依赖图/时间函数，动态道路/规则改变需失效重建或受控局部查询；作者加速只在其图与测试集。

先局部候选、共用静态图、有限规划范围、事件唤醒与批预算；不能以10000OD样本数宣称10000并发NPC。

标签意义和支配关系需包含全部相关资源；硬编码一次休息、一天/两天制度不能当通用任务框架。

班次耗时、旅途总时长、等待、休息应分别有单位字段，预测与真实移动游标分开。

明确启发式保留哪些约束与失解条件；执行遇新封路/停止需重查与取消确认，不把已算ETA当成功。

字幕有truck/ban/contraction hierarchy术语误听和不一致耗时数字，不采用精确加速/时长为工程常量。

更短行驶时间可因禁行等待更晚到；先找最快路再加休息错失更早到达路线。

CH漏掉从来不是时间最短却对休息约束最优的段；所有测试同结果不证明一般最优；单label无法完整检验最优。

选择最短驾行路线再插休息可比驾行更长路线晚数小时；等待窗口和休息联动。

单标签较早到达被误当全维更优，丢失后续符合班次的路径。

CH移除从来不是纯时变最短却为休息约束最优的边；样例一致并不保证所有图最优。

未考虑节假日/周总驾行、只一休息与一司机；停车细节仅基本方法试过，CH问答为建议。

完整自动字幕，未看图/论文或硕士论文；法律与时长仅作为历史模型说明，不是当前法律；结果数字字幕前后不一致。

全文自动字幕0:01–20:26已读，未观看路线图/函数曲线、读取论文/硕士论文或复现实验。

演讲所述欧洲制度是历史研究模型，本评审不提供现行法律指引。

没有任务占用释放、效果结算、存档恢复和当前Domino容量证明。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [browser-export.txt](../texts/23/23c3aa0f30740607da36975d4969bef72d76de5c225f5e56d287e26cbf0f7df3.md) | 字幕/转录文本 | [0, 12000)、[12000, 19336) |
| [transcript.txt](../texts/9b/9bedea2bbee361f56b5e7689a7a0d45831a59930b7a445cbe16f057ed1a255b0.md) | 字幕/转录文本 | [0, 12000)、[12000, 19257) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md)
- [https://research.tudelft.nl/en/publications/route-planning-with-breaks-and-truck-driving-bans-using-time-depe/](https://research.tudelft.nl/en/publications/route-planning-with-breaks-and-truck-driving-bans-using-time-depe/)
- [https://research.tudelft.nl/files/56197012/17745_77862_1_PB.pdf](https://research.tudelft.nl/files/56197012/17745_77862_1_PB.pdf)
- [https://www.icaps-conference.org/recording/route-planning-with-breaks-and-truck-driving-bans-using-time-dependent-contraction-hierarchies/](https://www.icaps-conference.org/recording/route-planning-with-breaks-and-truck-driving-bans-using-time-dependent-contraction-hierarchies/)
- [https://www.youtube.com/watch?v=7PEGqFWjreg](https://www.youtube.com/watch?v=7PEGqFWjreg)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
