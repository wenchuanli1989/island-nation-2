# 导航、人群、交通与空间协调

本类收录 210 条已有资料记录。当前前100中的条目优先列出，随后按题名排列。依据资料题名、来源主题与已有正文机制分析归类；跨领域资料在详情页保留关联链接。

[资料总目录](../README.md)

| 资料与概要 | 已有内容范围 | 当前前100 |
|---|---|---:|
| [dtNavMeshQuery implementation](work-182be8db73d5eb6b3d19.md) | 文章/文档正文、源码/工程文本 | 23 |
| [Spatial Partition — Game Programming Patterns](work-b29dd9b739f4e4cfa286.md) | 文章/文档正文、论文/讲义提取文本 | 25 |
| [Blazing Fast Neighbor Search with Spatial Hashing (Ten Minute Physics slides text)](work-5ff6b681d94eb8188eca.md) | 文章/文档正文 | 26 |
| [Crowds in Hitman: Absolution — Kasper Fauerby](work-40cdc8a8a85212cb1546.md) | 论文/讲义提取文本 | 42 |
| [Friday Facts #317 — New pathfinding algorithm](work-941f60af90e811961cd1.md) | 文章/文档正文 | 43 |
| [Hierarchical Dynamic Pathfinding for Large Voxel Worlds; https://gdcvault.com/play/1025151/Hierarchical-Dynamic-Pathfinding-for-Large](work-0af0c7468eb83c9a09bf.md) | 论文/讲义提取文本 | 44 |
| [Friday Facts #117 - Path Finder Optimisation I](work-13fdbacec1942f0b79d9.md) | 文章/文档正文 | 45 |
| [Godot PR #100497: Change navigation map synchronization to an async process](work-8063d347751ba3d440c9.md) | 讨论正文/已载入评论 | 46 |
| [Reciprocal n-body Collision Avoidance](work-6e5deee1715290e58c59.md) | 论文/讲义提取文本 | 47 |
| [Game Programming Patterns — Data Locality](work-a026fcf37222cc1e1205.md) | 文章/文档正文、论文/讲义提取文本 | 48 |
| [24 — Bounding Volume Hierarchies with a blazing fast implementation using Morton codes](work-f901656802491c2f813c.md) | 论文/讲义提取文本 |  |
| [A comparison of SUMO’s count based and countless demand generation tools](work-5da32a645e6d7db5c1ba.md) | 正文/源码节选 |  |
| [AI Battle in Unity using influence maps](work-7a4200a2df8c798b7b76.md) | 讨论正文/已载入评论 |  |
| [AI Navigation 2.0 - Runtime NavMesh surfaces](work-36c34788aa43eed85ec5.md) | 字幕/转录文本 |  |
| [AI Summit: Living in Procedural Worlds: Creature Movement and Spawning in Nightingale](work-55a6d6b8252f19f5a45f.md) | 文章/文档正文 |  |
| [API to access NavigationRegion associated with Tilemap's TileData](work-c70c2ff5b09c3c914341.md) | 文章/文档正文 |  |
| [API to access NavigationRegion associated with Tilemap's TileData](work-fb8beb12689617c729ba.md) | 讨论正文/已载入评论 |  |
| [API to access NavigationRegion associated with Tilemap’s TileData #8002](work-32bcca3d855ba58f7763.md) | 讨论正文/已载入评论 |  |
| [AStar-JPS-ThetaStar: Basic algorithms for single-shot grid-based 2D path finding](work-5a242eb96f3a2b5db29f.md) | 文章/文档正文 |  |
| [Add NavigationMesh border_size property for tile baking #87378](work-43e1d9b2b2c3d961ea17.md) | 讨论正文/已载入评论 |  |
| [Add a NavigationWorld2D/3D as a navmesh high performance option for large worlds](work-f72bf2d3d7c2b35c2deb.md) | 讨论正文/已载入评论 |  |
| [Add a NavigationWorld2D/3D as a navmesh high performance option for large worlds #12707](work-2a583a7bef4881ced4d4.md) | 文章/文档正文、讨论正文/已载入评论 |  |
| [Add navigation mesh source geometry parsers and callbacks](work-3b7137a1e4fcbec6b70e.md) | 讨论正文/已载入评论 |  |
| [Add navigation mesh source geometry parsers and callbacks](work-ac483295cc7db50ce676.md) | 源码/工程文本 |  |
| [Advanced 1. Incremental Path Planning](work-addade0ed3f62be83255.md) | 字幕/转录文本 |  |
| [Advanced NavMesh Usage - Beyond Simple SetDestination](work-f6bb3eaf9a186450712f.md) | 文章/文档正文 |  |
| [Advanced NavMesh Usage - Beyond Simple SetDestination \| Unity Tutorial](work-4b3d1c4e0eabd0901b21.md) | 字幕/转录文本 |  |
| [Allow other mods to register their node functionality for compatibility](work-f934a1dbd583e64ac440.md) | 讨论正文/已载入评论 |  |
| [Allow other mods to register their node functionality for compatibility · Issue #1 · hkzorman/advanced_npc · GitHub](work-68a2316bdc07f5ae09c2.md) | 文章/文档正文 |  |
| [Ambient Interactions: Improving Believability by Leveraging Rule-Based AI — Hendrik Skubch, Game AI Pro 3 chapter 35](work-261657125ce16bb27862.md) | 论文/讲义提取文本 |  |
| [AreaFloorBaker.cs（Optimizing Runtime NavMesh Generation \| AI Series Part 14.5 关联源码）](work-a571e4bb9f3c7050c822.md) | 源码/工程文本 |  |
| [AreaFloorBaker.cs：玩家移动阈值触发局部NavMesh更新](work-22b65e2c8f026979852f.md) | 源码/工程文本 |  |
| [Avoiding other pawns during pathfinding](work-fba0e69075ed40b25a0b.md) | 讨论正文/已载入评论 |  |
| [Avoiding peeps crowds on more tile stairs - General Discussion - OpenRCT2](work-1b02a5a6d7446daa9396.md) | 讨论正文/已载入评论 |  |
| [Box2D 3.1.0 Dynamic Tree](work-c8af219e16d72cf03ed9.md) | 文章/文档正文 |  |
| [Build Your Own Navigation Stack! \| AI and Games Conference 2025](work-7aea2bb51c501a7af8de.md) | 字幕/转录文本 |  |
| [Build navmesh for very big map](work-d8c04fc361a39efd2140.md) | 讨论正文/已载入评论 |  |
| [Calculating Flow Fields for Rats in 'A Plague Tale' \| AI and Games #73](work-33a4ea06dde6f450e874.md) | 字幕/转录文本 |  |
| [Chasing and fleeing AI using Dijkstra maps? (Reddit roguelikedev)](work-a6557dd74804c9e2e5a3.md) | 讨论正文/已载入评论 |  |
| [CodingTrain/QuadTree — quadtree.js](work-cc048b08e5354edeb3a9.md) | 源码/工程文本 |  |
| [Comments on HowTo: Drawing a metric ton of bullets in Godot](work-1d9815c962ad9a3b293d.md) | 讨论正文/已载入评论 |  |
| [Concept and first insights of a sequential MATSim-SUMO tool coupling to deduce representative 24h velocity profiles for autonomous vehicles](work-a69bbda949fa5254797c.md) | 字幕/转录文本 |  |
| [Cooperative Pathfinding Experiments](work-35cbe78574baac4ebbda.md) | 讨论正文/已载入评论 |  |
| [Coordinated Crowd Simulation With Topological Scene Analysis](work-e13558567ac0be38e2ea.md) | 论文/讲义提取文本 |  |
| [Correct way to implement "one-way" avoidance](work-690f1996dc3709c5d141.md) | 讨论正文/已载入评论 |  |
| [CppCon 2017: Allan Deutsch “Esoteric Data Structures and Where to Find Them”](work-e124980cda0c161db4f2.md) | 正文/源码节选 |  |
| [Crowdsourcing Intelligence in Jeff Orkin's 'The Restaurant Game' \| AI and Games #76](work-9646aadac7d6ad4e8f2b.md) | 字幕/转录文本 |  |
| [Crowdworking Model 1.0.0 — CoMSES Net release by Georg Jäger](work-1f7e8f72a2045231789d.md) | 文章/文档正文 |  |
| [Customizable Contraction Hierarchies -- A Survey](work-fab8e0656be0ab20c3b0.md) | 论文/讲义提取文本 |  |
| [Customizable Contraction Hierarchies – A Survey](work-47bd9163bb0d4cf219e7.md) | 论文/讲义提取文本 |  |
| [D* Lite](work-37e0ac1cc40de9e33d2f.md) | 论文/讲义提取文本 |  |
| [Dangling OmniLight happening randomly](work-29d4d9af92fa8565e6f0.md) | 讨论正文/已载入评论 |  |
| [Dangling OmniLight happening randomly](work-c87ae7c7bc93cbf0a513.md) | 文章/文档正文 |  |
| [Dangling OmniLight happening randomly #41360](work-a39e4777bd3f1121fdb3.md) | 讨论正文/已载入评论 |  |
| [Dealing with Data Gradients: “Backing Out” & Calibration](work-e215f91027093f5c3dd5.md) | 论文/讲义提取文本 |  |
| [Death Stranding's Biggest Problem? Teaching the AI to Walk \| AI and Games #67](work-03963d7bf1c9cab9efea.md) | 字幕/转录文本 |  |
| [Designing AI to flee?](work-a4904cac4522a9d216f9.md) | 讨论正文/已载入评论 |  |
| [Detecting collisions with spatial hash grid](work-3f56acb4af32678f2a27.md) | 文章/文档正文 |  |
| [Deterministic vs. Replicated AI: Building the Battlefield of For Honor — Guilbeault and Doll, GDC2017](work-4c2fcc73c6b56a9d4867.md) | 论文/讲义提取文本 |  |
| [DetourCrowd/CMakeLists.txt](work-ffa5e723529c8d64d7c6.md) | 源码/工程文本 |  |
| [Differences between dtNavMesh and dtTileCache? #464](work-966551496163cea3e147.md) | 讨论正文/已载入评论 |  |
| [Distributed Multi-agent Navigation Based on ORCA Algorithm](work-262cebc396e1e1695cdf.md) | 文章/文档正文 |  |
| [Distributed Multi-agent Navigation Based on Reciprocal Collision Avoidance and Locally Confined Multi-agent Path Finding](work-b4d273e65da51ef2fdba.md) | 论文/讲义提取文本 |  |
| [Dynamic Tree Improvements](work-0aa5dfe533ac1e7e691f.md) | 文章/文档正文 |  |
| [EQS Node Reference: Tests](work-248a53e8aedbc942b3e6.md) | 文章/文档正文 |  |
| [Early quit searching for a path if taking too long](work-0a592fafd7d7fe4823a8.md) | 讨论正文/已载入评论 |  |
| [Early quit searching for a path if taking too long](work-6af172063a960eaa065c.md) | 讨论正文/已载入评论 |  |
| [Early quit searching for a path if taking too long](work-8b198998dc6a01426fcd.md) | 讨论正文/已载入评论 |  |
| [Efficient Route Planning SS2012 Lecture 6: Contraction Hierarchies, Part 1 of 2](work-8b20d74cb91102d73694.md) | 论文/讲义提取文本 |  |
| [Efficient Route Planning SS2012 Lecture 7 — Contraction Hierarchies, Part 2 of 2](work-aff04103f1f9de7f0bc3.md) | 论文/讲义提取文本 |  |
| [Examples For Customizable Routing](work-1e510ec18eb6cf0a0016.md) | 文章/文档正文 |  |
| [Feature: Allow to keep an action performing even if the target became invalid at some point](work-bd1b949e2de9a463e1db.md) | 讨论正文/已载入评论 |  |
| [Feature: Allow to keep an action performing even if the target became invalid at some point #285](work-e8e5fa76ab83af957ef6.md) | 讨论正文/已载入评论 |  |
| [Friday Facts #121 - Path Finder Optimisation II](work-cb68de1200a3fb71c7f6.md) | 文章/文档正文 |  |
| [Further pathfinding fixes (OpenRCT2 PR #4847)](work-c09c1f1893257478eddf.md) | 讨论正文/已载入评论 |  |
| [Generating complete all-day activity plans with genetic algorithms](work-8e78f399a59a1fdcde95.md) | 文章/文档正文 |  |
| [Godot #101147: NavigationAgent2D.velocity_computed emits zero vector when set_velocity not called](work-dc0e0be323c84494bc2b.md) | 源码/工程文本、讨论正文/已载入评论 |  |
| [Godot PR #69988 — Rework Navigation Avoidance](work-451f5fb1105bc911ef1f.md) | 讨论正文/已载入评论 |  |
| [Godot PR #87378 — NavigationMesh border_size for tile baking](work-ffbc396a3ca366da5421.md) | 讨论正文/已载入评论 |  |
| [Godot PR #90876: Add navigation mesh source geometry parsers and callbacks](work-0921d3c9e73e0a590ade.md) | 讨论正文/已载入评论 |  |
| [Godot forum smix8：用warp point更快的路径选择回复](work-e7fa295a2d0e9f5132f8.md) | 讨论正文/已载入评论 |  |
| [Godot issue #82560 — navigation arrival flag](work-7cf193c7cd6b7a6d386a.md) | 讨论正文/已载入评论 |  |
| [Godot游戏开发实践之二：AI之寻路新方式](work-82d962b261d671be1165.md) | 文章/文档正文 |  |
| [Helping It All Emerge: Managing Crowd AI in Watch Dogs 2](work-b86ef7bc5f7e747488f0.md) | 摘要/简介、文章/文档正文 |  |
| [Helping It All Emerge: Managing Crowd AI in Watch Dogs 2（Roxanne Blouin-Payer）](work-d12960d5fea4af093cb5.md) | 论文/讲义提取文本 |  |
| [HiKariのTechLab：UE4大世界寻路效果自动化测试方案](work-3a39e67fd6bcb22190c9.md) | 文章/文档正文 |  |
| [Hierarchical pathfinding (Alex Ene developer article)](work-d119330cd106953331d5.md) | 文章/文档正文 |  |
| [How A Navigation Mesh Works in 3D Games \| AI101](work-9df856a10b0be88e1564.md) | 字幕/转录文本 |  |
| [How Do You Make NPCs Interact with Objects in a 2D Top-Down RPG?](work-5bfb3348663b2e6a9b4e.md) | 讨论正文/已载入评论 |  |
| [How do RTS Games stop Agents from Pathing into each other? visible Reddit main post/comments](work-94c4c0e47d41500dd8ea.md) | 讨论正文/已载入评论 |  |
| [How to handle doors (ie, turn parts of the nav mesh off and on)?](work-db178b4f66da05e17536.md) | 讨论正文/已载入评论 |  |
| [How to make NavigationAgent2D to use a Warp Point to go faster](work-30a34b793c9cfd2dc94d.md) | 讨论正文/已载入评论 |  |
| [How to make NavigationAgent2D to use a Warp Point to go faster](work-3c3355a284db2ecfb45f.md) | 讨论正文/已载入评论 |  |
| [How to make NavigationAgent2D to use a Warp Point to go faster](work-5434d64845cd52bc3c7a.md) | 讨论正文/已载入评论 |  |
| [How to simulate a pedestrian crossing](work-017f390c8628e7f83fc3.md) | 字幕/转录文本 |  |
| [How to use the navigation links? — Godot forum #42351](work-a50ba88611579b47177f.md) | 讨论正文/已载入评论 |  |
| [Implicit Crowds: Optimization Integrator for Robust Crowd Simulation](work-ba4128fc4830a3af0db0.md) | 论文/讲义提取文本 |  |
| [Improvement: Characters should pathfind through transport rides.](work-385ff366f6205e6802d8.md) | 文章/文档正文 |  |
| [Improvement: Characters should pathfind through transport rides.](work-63ae4d56f4cd7f41049a.md) | 讨论正文/已载入评论 |  |
| [Improvement: Characters should pathfind through transport rides.](work-d4987fbd3fcc6415c56a.md) | 讨论正文/已载入评论 |  |
| [Intentionally Imperfect Human-like Pathfinding](work-6f63ff4b98e1426335ba.md) | 讨论正文/已载入评论 |  |
| [Introduction to Modelling — complexity, chaos, criticality and emergence (hoU13URrg0o)](work-e0642a1abb95308590ca.md) | 字幕/转录文本 |  |
| [KD-Tree Nearest Neighbor Data Structure / Stable Sort](work-c4380bc41ee19d40aab6.md) | 字幕/转录文本 |  |
| [Lifelong Planning A*](work-7edbb930f2fdd93009fc.md) | 论文/讲义提取文本 |  |
| [Lifelong Planning A* — author abstract and errata](work-f49272a603023331a5c4.md) | 已有摘要/简介文本 |  |
| [Living in Procedural Worlds: Creature Movement and Spawning in Nightingale](work-44ba027c89f52afca10a.md) | 字幕/转录文本 |  |
| [LlamAcademy MoveToTargetOrEdgeOfNavMeshAction.cs at 72c45e6](work-f0b6f2d0522955c449f4.md) | 源码/工程文本 |  |
| [MASON Continuous2D.java](work-3cd56e881d0cfd3e007e.md) | 源码/工程文本 |  |
| [MATSim](work-be110a967aa7f3253679.md) | 源码/工程文本 |  |
| [MATSim #3008 — Avoiding silent failures: stuck agents disappear between inputs and outputs](work-f5d8152f399095626b46.md) | 讨论正文/已载入评论 |  |
| [MATSim Package org.matsim.core.controler](work-c1d1c055196b919b9ac1.md) | 文章/文档正文 |  |
| [Make Your NavMeshAgents Destroy or Avoid Obstructions \| AI Series 37 \| Unity Tutorial](work-7314c36640174fdd65ae.md) | 字幕/转录文本 |  |
| [Make Your NavMeshAgents Destroy or Avoid Obstructions \| AI Series 37 \| Unity Tutorial](work-b701e62599716832671c.md) | 字幕/转录文本 |  |
| [Massive crowd on ACU: AI Recycling — François Cournoyer and Antoine Fortier](work-7f2764a9e281d6f6234c.md) | 论文/讲义提取文本 |  |
| [Math for Game Developers: Dynamic Bounding Volume Hierarchies — GDC 2019](work-e8a3184a7c6b9c0f4e4f.md) | 文章/文档正文 |  |
| [Megacity Unity Demo研究 — HONT (2024-08-02)](work-1957b1db869b7476c863.md) | 讨论正文/已载入评论 |  |
| [Metrotown: A new city builder where you fix car-centric cities — main post and selected author replies](work-cc9db105e65fd84f3cee.md) | 讨论正文/已载入评论 |  |
| [Modular Tactical Influence Maps — Dave Mark, Game AI Pro 2 chapter 30](work-a14add7f438d81c43c5c.md) | 论文/讲义提取文本 |  |
| [Native Dynamic Road Closure Support #5944](work-f4d298dbf88b612f2c3e.md) | 讨论正文/已载入评论 |  |
| [Navigate To Pose and Pause Near Goal-Obstacle](work-ea7992ef66aa49e96331.md) | 文章/文档正文 |  |
| [Navigation Server for Godot 4.0（2020开发报告）](work-6b80087033d03f5e2c39.md) | 文章/文档正文 |  |
| [Navigation2 WG Meeting Notes 12/5 and 12/12/19](work-bf85bdc4b48f58c84e1a.md) | 文章/文档正文 |  |
| [NavigationAgents' `is_target_reached` returns `false` even within `target_desired_distance` to the `target_position` · Issue #82560 · godotengine/godot · GitHub](work-3d454ba2dcc88dac537e.md) | 文章/文档正文 |  |
| [NavigationLinks created via NavigationServer2D.link_create persist after scene reload](work-0926d7718f67129d3d23.md) | 讨论正文/已载入评论 |  |
| [Now flexible routing is at least 15 times faster](work-9deaf9ef14ef1d43369c.md) | 文章/文档正文 |  |
| [Openage Development News: April 2024](work-e02488a7b23f430bfc62.md) | 文章/文档正文 |  |
| [Openage Development News: March 2024](work-3a4276e267678051fccc.md) | 文章/文档正文 |  |
| [Optimal Reciprocal Collision Avoidance](work-59a33537bd5745ea5f47.md) | 文章/文档正文 |  |
| [Optimal Reciprocal Collision Avoidance / RVO2 README](work-a3278f5645b984dc879c.md) | 文章/文档正文 |  |
| [Optimal Reciprocal Collision Avoidance official page](work-a3d2216650e192b90cbf.md) | 文章/文档正文 |  |
| [Optimizing Crowd Flow for Nijmegen's Biggest Event](work-808aab47c2a56f1cbae8.md) | 文章/文档正文 |  |
| [P&D 过河游戏智能帮助实现](work-e51f5e00a22abb430f1f.md) | 讨论正文/已载入评论 |  |
| [Package tutorial.programming.withinDayReplanningFromPlans](work-5952861cd9755e5d5454.md) | 文章/文档正文 |  |
| [PathFinding.js README](work-22e045ed8e4fa967261e.md) | 文章/文档正文 |  |
| [PathFinding.js README](work-5f1c72601cb291c109c9.md) | 文章/文档正文 |  |
| [PathFinding.js — BiAStarFinder.js](work-0947cffb0ff5dd57b5f9.md) | 源码/工程文本 |  |
| [Pathfinding and Abstraction with Dynamic Terrain Costs](work-052ac978cf33d26df658.md) | 论文/讲义提取文本 |  |
| [Pathfinding conundrum](work-30447be9d6fe7ba3bdfc.md) | 讨论正文/已载入评论 |  |
| [Pathfinding in a Dynamic Destructible Environment](work-5c2267e0626e6e923f51.md) | 讨论正文/已载入评论 |  |
| [Peeps using overlaid paths for pathfinding when they have a goal #23006](work-0966979c7f95bfedafe2.md) | 讨论正文/已载入评论 |  |
| [PhysX 和 NavMesh 在服务器的应用](work-35d83a606b000f5dc03f.md) | 文章/文档正文 |  |
| [Planning and acting in partially observable stochastic domains](work-fe3053d16914d17dd7d0.md) | 论文/讲义提取文本 |  |
| [Prevent navigation baking on specified areas](work-adb9e4ad669c5319df42.md) | 讨论正文/已载入评论 |  |
| [Protest votes in Democracy 4. Final piece of the puzzle?](work-3935c98f463078ab5bd3.md) | 讨论正文/已载入评论 |  |
| [PyQuadTree 0.2 — TalkTown vendored pyqtree/__init__.py](work-bb7c9e8f6aaa7460979a.md) | 源码/工程文本 |  |
| [QuadTree or Spatial Hashing in ECS ? — Reddit 1jopdn4 可见讨论](work-dcc844ab7dc911ce7e1c.md) | 讨论正文/已载入评论 |  |
| [RTS Pathfinding 1 – Flowfields](work-2201a328c8535c7e94f1.md) | 文章/文档正文 |  |
| [RVO2 Agent.cc (commit 1c25b27258d191e26c2df83ff6e31abc8efbdaed)](work-7c3deff553e77424056b.md) | 源码/工程文本 |  |
| [RVO2 Library — Parameter Overview](work-8622c3503896011d7210.md) | 文章/文档正文 |  |
| [RVO2 Library: Blocks.cc 100-agent example](work-d2f694486e73f7f7588c.md) | 源码/工程文本 |  |
| [RVO2 Library: Reciprocal Collision Avoidance for Real-Time Multi-Agent Simulation](work-7e165f0bb3484b1dc0d0.md) | 文章/文档正文 |  |
| [RVO2 commit 1c25b27258d191e26c2df83ff6e31abc8efbdaed - Windows CI setup changes](work-82f2baecaec26b170c7b.md) | 文章/文档正文 |  |
| [RVO2 — Optimal Reciprocal Collision Avoidance repository README](work-90be9885bf9dbd983930.md) | 文章/文档正文 |  |
| [Recast Navigation README](work-bf9eec99dc9bf1b2401c.md) | 文章/文档正文 |  |
| [Recast Navigation README.md](work-767ab4e1de4f15f3fca6.md) | 文章/文档正文 |  |
| [Recast Navigation issue #422: Function to calculate distance left to traverse for agent](work-290d9182451504d826a3.md) | 讨论正文/已载入评论 |  |
| [Recast Navigation: Crowd](work-ff6f499f9ccd4aed951f.md) | 文章/文档正文 |  |
| [RecastNavigation commit 9f4ce644: 空tris防护](work-8e39f298adbaea2b6853.md) | 源码/工程文本 |  |
| [Releasing my C++ struct-of-arrays / hashtable library - critique needed!](work-d92846b04895da2779e1.md) | 讨论正文/已载入评论 |  |
| [Ride-hailing and ride-pooling: State of the art, future research directions, and the role of traffic simulation](work-65bb87789615d89f0901.md) | 字幕/转录文本 |  |
| [RimWorld Alpha 11 - Sappers and Traps — Tynan Sylvester（自动字幕）](work-4e4c499d3f7ce2824d57.md) | 字幕/转录文本 |  |
| [Route Planning with Breaks and Truck Driving Bans Using Time-Dependent Contraction Hierarchies](work-5cd3a91ecc6694b4b3f5.md) | 字幕/转录文本 |  |
| [SUMO 2024 Tutorial](work-5e3d46b719ababb5adaf.md) | 文章/文档正文 |  |
| [SUMO 2024 Tutorial](work-65e154e856d1e1e965e4.md) | 字幕/转录文本 |  |
| [SUMO 2024 Tutorial — Jakob Erdmann](work-1b6ec8337a7d0e33ee88.md) | 字幕/转录文本 |  |
| [SUMO 2024 Tutorial — Jakob Erdmann](work-bf4ae64f417a3255d21c.md) | 字幕/转录文本 |  |
| [SUMO User Conference 2024 Tutorial — Jakob Erdmann](work-c6a85b8a6664bb72f16f.md) | 字幕/转录文本 |  |
| [Sandbox Assassin: The AI of Hitman (2016) \| AI and Games #45](work-95e24ee89c3abead1e5b.md) | 字幕/转录文本 |  |
| [Sebastian Lague Ant-Simulation Ant.cs at e638aa267e0b58eb0092b9c15a2732c501baa2b0](work-faeaed982d9face5ca33.md) | 源码/工程文本 |  |
| [Software Performance: A Shape Not a Number — Kay Ousterhout](work-65bf519cdb9ffb984849.md) | 字幕/转录文本 |  |
| [Some notes on programming objects in The Sims™](work-f06e7a769e9765c7b129.md) | 论文/讲义提取文本 |  |
| [Sopiro DynamicBVH — src/aabbtree.ts](work-6758b97ad37284bd02dd.md) | 源码/工程文本 |  |
| [Source-title above; actual transcript speaker discusses Watch Dogs 2 cover positioning and production issues](work-f60c33b48a965433699a.md) | 字幕/转录文本 |  |
| [Spatial Hashing — Ten Minute Physics 11-hashing.html](work-f750231143e42eb5601f.md) | 源码/工程文本 |  |
| [Strange navigation agent behaviour (Godot 4.2.2, 2024-06-03/04)](work-1b98c8b167de809b7b58.md) | 讨论正文/已载入评论 |  |
| [Strange navigation agent behaviour - Help - Godot Forum](work-9d63b61354c05c1ef9e0.md) | 文章/文档正文 |  |
| [Support for long range off-mesh connection support](work-2ead26c713eb9f18bca9.md) | 讨论正文/已载入评论 |  |
| [The AI of Horizon Zero Dawn \| Part 2: Metal Militia \| AI and Games #38](work-5c6689debdfb73cd415d.md) | 字幕/转录文本 |  |
| [The Role of Heterogeneity and the Dynamics of Voluntary Contributions to Public Goods: An Experimental and Agent-Based Simulation Analysis](work-73dbc9ffa4689872e8e4.md) | 论文/讲义提取文本 |  |
| [The Wisdom and/or Madness of Crowds](work-2680c23af2f929865bca.md) | 文章/文档正文 |  |
| [UAISense_Sight](work-56cbab98d94c5ab9c164.md) | 文章/文档正文 |  |
| [Unexpected Agent Behavior in MATSim Simulation Across Iterations #1103](work-e226210135ccdca93c3e.md) | 讨论正文/已载入评论 |  |
| [Unify action/tasks into Execution API #44](work-27061e7392bcfa31563f.md) | 讨论正文/已载入评论 |  |
| [Unity Sims-style AI tutorial — BaseNavigation.cs](work-fa6d06051745a2eedca3.md) | 源码/工程文本 |  |
| [Unity3D学习(15)之Navmesh使用](work-cf47d5c07326c93a5046.md) | 源码/工程文本 |  |
| [Updating navigation mesh mid-game](work-21137d61e829dbdd80d2.md) | 讨论正文/已载入评论 |  |
| [Updating navigation mesh mid-game](work-601d5812aae165207e6d.md) | 讨论正文/已载入评论 |  |
| [Updating navigation mesh mid-game](work-b7e309a1ac261d853d61.md) | 讨论正文/已载入评论 |  |
| [Vision Zones and Object Identification Certainty — Steve Rabin](work-644e751d3cd3d4e1ad9e.md) | 论文/讲义提取文本 |  |
| [What’s the max distance citizens are willing to commute via bus?（公开主帖及部分评论快照）](work-a39bfdfb89097c5f1acc.md) | 正文/源码节选 |  |
| [\[2022 TGDF\] 挑個好位置：頑皮狗的崗位系統 (周明倫) — 40-page document text](work-bc20cb8c7f73400be6a6.md) | 文章/文档正文 |  |
| [\[3.x\] Support for Dynamic BVH as 2D Physics broadphase](work-8a6dfdd331eca69b3c0b.md) | 讨论正文/已载入评论 |  |
| [\[Help\] A* Pathfinding + Unity Behavior - Agent Keeps Recalculating Path and Never Stops](work-76fa6a162da4c805fb8f.md) | 讨论正文/已载入评论 |  |
| [\[gdal-dev\] FlatGeobuf; proposal for a new performance oriented vector file format](work-2e8007a745a2deb863ca.md) | 讨论正文/已载入评论 |  |
| [advanced_npc — Problem with paralyzed NPCs #38](work-cf77ae6521c5fb8adef9.md) | 讨论正文/已载入评论 |  |
| [detecting collisions with spatial hash grid \| the2nake](work-2ed983f8b483a6a23727.md) | 文章/文档正文 |  |
| [detecting collisions with spatial hash grid \| the2nake](work-9b0933883a0eadecc474.md) | 文章/文档正文 |  |
| [feat!: scale impassable cells to close gaps too small for large actor pathing](work-1fa7dfabaf03f6706d0b.md) | 讨论正文/已载入评论 |  |
| [fix!: various related fixes to CostField mutation](work-a8e47aeb4413a83495ca.md) | 讨论正文/已载入评论 |  |
| [hugoscurti/hierarchical-pathfinding：HPA* README](work-f1491c4291795d7195c7.md) | 文章/文档正文 |  |
| [made a Avoidance system for NPC](work-9f7d7e215360c4e59911.md) | 讨论正文/已载入评论 |  |
| [refactor!: moved LOS from flow layer to integration layer](work-34552b84df7e000c0bc0.md) | 讨论正文/已载入评论 |  |
| [zero activity duration #428 (matsim-code-examples)](work-4c7b54899d65a38a7506.md) | 讨论正文/已载入评论 |  |
| [【日常随笔】UE虚幻引擎游戏大世界自动寻路测试技术 — utmhikari](work-6fce5ccb443eabe4a2fc.md) | 讨论正文/已载入评论 |  |
| [场景查询系统快速入门](work-a04eaa443d6f1da6710e.md) | 文章/文档正文 |  |
| [场景查询系统概述](work-512eba458b6864629e85.md) | 文章/文档正文 |  |
| [塔防小游戏的开发设计经历](work-a402437ccf2c77d83b1f.md) | 讨论正文/已载入评论 |  |
| [游戏AI寻路——八叉树+A*寻路](work-cdea5492488ef7be726f.md) | 文章/文档正文 |  |
| [源码分析UE4的导航系统(1)：场景体素化](work-40f9c70743dbd187af0d.md) | 文章/文档正文 |  |
| [群体的智慧与愚蠢 / The Wisdom and/or Madness of Crowds](work-8d76531e8b796fc83c45.md) | 文章/文档正文 |  |

## 相关配套归档文本

这些源码、结构化讨论或论文提取文字已在原档案中判定为可用文本；未补写语义精读结论，也不计作上表的独立资料条目。

| 文本文件 | 来源与原件 | 相关研究概要 |
|---|---|---|
| [Coding Adventure: Ant and Slime Simulations — README.md](../texts/b3/b3ff01b4c1415b73688b4622a4d6491e1a94143afacb5a1614b594e582ae64ea.md) | [来源](https://github.com/SebLague/Slime-Simulation/blob/6794cfdf584f71c657bd16366e31bf422be99ee6/README.md) · [已保存原件](../../ai-reference/source-archive-2026-10-04/raw/63f8fa64c1b3fd5081135466.html) | [Sebastian Lague Ant-Simulation Ant.cs at e638aa267e0b58eb0092b9c15a2732c501baa2b0](work-faeaed982d9face5ca33.md) |
| [Coding Adventure: Ant and Slime Simulations — README.md](../texts/d7/d7de2f49981ba51199e4a77ae16ce0ed2e098536e0bbbef5e866c18e11af3152.md) | [来源](https://raw.githubusercontent.com/seblague/slime-simulation/6794cfdf584f71c657bd16366e31bf422be99ee6/README.md) · [已保存原件](../../ai-reference/source-archive-2026-10-04/raw/70a74e281351827fa3f1119d.md) | [Sebastian Lague Ant-Simulation Ant.cs at e638aa267e0b58eb0092b9c15a2732c501baa2b0](work-faeaed982d9face5ca33.md) |

