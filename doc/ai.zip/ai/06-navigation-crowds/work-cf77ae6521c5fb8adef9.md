# advanced_npc — Problem with paralyzed NPCs #38

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/hkzorman/advanced_npc/issues/38`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：BrunoMine（Advanced NPC 使用者、问题报告者）。
- 原目录日期：2018-04-17（沿用已有记录）。
- 主要来源：[https://github.com/hkzorman/advanced_npc/issues/38](https://github.com/hkzorman/advanced_npc/issues/38)

## 概要与项目参考

Domino建议：模板发布时校验连续行为顺序、非空type/有效目标，任务入队与可执行状态转移形成明确合同；暂无任务时等待下一唤醒，而不是执行nil或强制生成常驻idle补丁。
Domino建议：日程记录新增与更新的失败要可见，床地点/access点发现、日程登记、人物执行三个层级分别排查；计划中有床不证明已成功睡眠。

## 已有机制分析

源事实：睡眠日程包含walk_to_pos到床access节点→use_bed LAY→idle state program；用户日志呈现空过程队列、执行program_name=nil、随后队列1却不推进。
源事实：维护者先指出数组顺序1,1,2错误，并修补scheduler未处理空队列且无默认state process、以及入队process仍inactive两条状态遗漏；修复后仍有空队列。
源事实：最终实际原因还包括用entry.set更新不存在22点的日程，需entry.put新建；维护者解释put/get/set区分新增/查询/更新，用户最终确认成功。

## 后续行为与玩法启发

休息地点占用、路径阻断、玩家叫醒/攻击等需要可解释取消；权限或状态禁止rightclick不应禁止所有紧急事件。

Domino建议：同样状态遗漏会让盗窃→逃离、调查→问证人、交易→付款链停死；玩家临时移走床/证物或参与者拒绝应产生明确失败/等待记录。

Domino建议：服务地点、access位置与动作目标分开，有助未来潜入和封锁，不能建筑里存在一张床即视为任何人可无条件使用。

## 适用范围与局限

日志同秒重复scheduler体现潜在busy retry与日志开销，未测万人；Domino需变化/到期唤醒和限重试。

局部床搜索可控，但每人每次全建筑查找仍需空间/服务索引。

线程只有一个人物失败日志，不含万人数据；重复轮询和每秒打印空队列扩展到10000人会浪费AI与logger吞吐。

Domino建议：无活动者订阅到期/地点/目标事件并批唤醒，使用可追踪状态游标与有界日志；源mod的连续default idle不应直接搬成全员忙循环。

明确模板每步program类型、参数和执行状态；队列出空与终止/等待分别处理。

owned地点和access点分开表达，不能以到达建筑等同资源使用成功。

新增/更新接口命名及状态转移一致性比引入更通用求解器更重要；局部类型ops和公共生命周期可统一失败原因。

本帖修复包含多个独立原因，不能只引用最后API改名就当整个调度器问题解释；明确日志的队列计数、current type与state。

不能由nil日志认定bed坐标、schedule.entry.set的nil参数或某个引擎bug为唯一根因，接口实现未读。

页面Closed不证明bug修复；当前提取没有评论或提交解释。

on_spawn床不存在时移除实体是用户测试选择，游戏无床应有业务失败后果而非删除人物。

修改条目数组顺序或修地方查找未立即解决问题，作者修复又忘记push；代码主张、发布状态、用户确认是不同证据。

空队列、无state process与inactive process是不同停滞条件；仅非空队列不代表动作正在推进。

set不存在条目静默无效会把外部输入错误传到调度层；默认idle只能掩盖日程登记缺失，不能算任务成功。

完整读本地提取issue正文，未读raw中潜在未提取评论或相关源码。

代码为用户测试，不是整个advanced_npc实现。

无故障复现、构建或运行。

完整修复后issue正文/嵌入timeline已读；未读取补丁源码、整仓执行器或复现。

小型旧Lua/minetest实例用于状态边界反例，不能当成熟万级框架或当前Domino缺陷证明。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [d36a5db62933ebec20d6f978.repaired.txt](../texts/ba/baa5a61eee735754f0a3a2d52927b9df67dcfae7a3e542d7caf118d057b6148d.md) | 讨论正文/已载入评论 | [0, 10903) |
| [d36a5db62933ebec20d6f978.txt](../texts/f9/f9343fdeb130893d69f4e61d24d71192e07ef325aeb771314ed958364b6760bb.md) | 讨论正文/已载入评论 | [0, 4221) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/06-affordances-place-selection.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/06-affordances-place-selection.md)
- [https://github.com/hkzorman/advanced_npc/issues/38](https://github.com/hkzorman/advanced_npc/issues/38)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
