# Support for long range off-mesh connection support

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/recastnavigation/recastnavigation/pull/645`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：niji-k（PR 作者）；illwieckz、RGreenlees、mastahg（讨论及使用反馈参与者）。
- 原目录日期：2023-07-05（沿用已有记录）。
- 主要来源：[https://github.com/recastnavigation/recastnavigation/pull/645](https://github.com/recastnavigation/recastnavigation/pull/645)

## 概要与项目参考

Domino建议：空间候选采用局部范围索引、只处理未连接目标，连接建立/失效与图版本一起管理；当前Domino已有道路图+Floyd，此PR的navmesh结构不能直接迁移。
Domino建议：加载顺序依赖与半完成连接状态是有用反例，保存/加载应先重建实际节点，再依确定ID建立可用连接；路径可达不等于ETA/实际完成移动。

## 已有机制分析

源事实：PR讨论Detour跨非相邻tile off-mesh link，将连接推迟到所有tile加载后避免起点先加载而终点未出现；作者承认局部建tile及二进制加载还需探索。
源事实：评论先用unconnectedOffMeshCount和无offmesh跳过无关tile，再只存有连接tile向量；进一步按终点pos±radius/climb算AABB与tile坐标，仅查询重叠tile，在最近poly后再检查水平距离，按BIDIR标志建立反向link。
源事实：评论者称大tile数快两数量级，但无正式数据；移除再加tile明确未在其用例范围，后续回复仍请求功能/独立gist。尾部GitHub UI/建议提示无技术内容。

## 后续行为与玩法启发

Domino建议：未来码头/通道/建筑局部区域的跨区链接可表达潜入出口、封锁与追逃；常态建筑级模拟只在必要玩法细化，不需要全世界mesh。

Domino建议：玩家拆通道或封锁使连接失效，盗窃逃逸/合作运输计划局部修复；目击只能依据实际空间与时机，不能因两区有offmesh边就认为瞬时移动或全楼可见。

## 适用范围与局限

初版目标tile×全部tile约O(T²)；稀疏有link集合与终点空间重叠查询削减无关扫描，但拥挤/多重叠层/大半径仍增成本，MAX_NEIS=32可能截断。

源码评论未给万人指标或动态更新基准；Domino不应因导航资料引入全员逐tile扫描或每次全图重建。

文档target/tile方向易混，加载、卸载、重加和双向link释放须成合同；allocation失败可能只建立一侧，需要明确原子建立/回滚。

依赖PR讨论与评论代码，不是已合并发布能力证明；外部gist只记录关联缺口，未追抓。

延迟到所有tile完成不支持流式局部加载；单靠未连接计数不能证明移除再加后旧link有效。

start poly无link、最近poly太远、link容量耗尽都能失败；一侧alloc成功而反向失败需处理，评论没有完整维护闭环。

个人两数量级声称无可复现硬件/输入细节，不能用于性能承诺。

完整阅读保存PR讨论与评论代码，不是PR diff/Detour全仓核查，也未验证合并或当前库状态；局部空间索引思路可参考。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [a4bd5adf7c253208f41a43a7.txt](../texts/17/17573fe6c83361cdc3a68485df49a4291ff479ecb909917a33635bd8469ebbf1.md) | 讨论正文/已载入评论 | [0, 11500)、[11500, 12073) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md)
- [https://api.github.com/repos/recastnavigation/recastnavigation/issues/645](https://api.github.com/repos/recastnavigation/recastnavigation/issues/645)
- [https://github.com/recastnavigation/recastnavigation/pull/645](https://github.com/recastnavigation/recastnavigation/pull/645)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
