# Native Dynamic Road Closure Support #5944

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/valhalla/valhalla/discussions/5944`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：VictorYanson（GSoC 方案提议者）；nilsnolde、chrstnbwnkl、kinkard 等维护/贡献参与者。
- 原目录日期：2026-03-10（沿用已有记录）。
- 主要来源：[https://github.com/valhalla/valhalla/discussions/5944](https://github.com/valhalla/valhalla/discussions/5944)

## 概要与项目参考

Domino可把可达性/交通状态overlay与基础道路拓扑分开，并分开实际封锁、告知玩家和个人听闻。
当前Floyd缓存不是按edge扩展A*：即使overlay lookup快，预计算最短路仍需修订/验证/求替代路径策略，不能把Allowed检查直接移植后宣称路由正确。

## 已有机制分析

提案sidecar周期poll外部closureDB，解析成edge IDs，写sorted二进制overlay(edge_id,start,end,mode/direction flags)，edge expansion Allowed/AllowedReverse检查。
提案作者明确Allowed=false会禁止从已处于closed edge的起点出发，不理想；与维护者讨论后转用现有live traffic/incident设施。
维护者区分用于path finding的live traffic与给用户显示事故icon的incident tiles；planned start/end closure是否进graph或live接口取决于更新频率/成本。
维护者强调新增live interface不仅内部维护负担，也增加用户部署/数据mapping复杂度；作者60s polling仅估计，communityreported更新频率未知。

## 后续行为与玩法启发

玩家路障、举报道路关闭、制造/散播假路况可改变路线或主观选择；社区report在Domino应作为信息事件，不能无校验成为物理世界事实。

在闭路上已有NPC必须有离开/等待/回退语义，避免封锁瞬间把人困死或任意瞬移。

## 适用范围与局限

避免频繁graph rebuild是提案目标，非已实现性能证明；overlay时间间隔查询与数据更新/edge映射额外成本。

外部postGIS/FastAPI/sidecar对单机离线宿主不必要，建议普通C稀疏road状态与到期修订。

先定义基础图/当前实际路况/计划的未来关闭/信息展示职责，再决定是否需要另一接口。

OpenLR→edgeIDs与来源特定glue代码是维护者认为困难的边界，不能把一般json转表想成闭合管线。

一律Allowed=false会误伤起点离开；planned closure与active closure混用导致时间可行性错误。

route只在生成时读overlay而移动期间状态已变仍执行旧计划；这些生命周期保障讨论未实现。

完整本地可见discussion载体，含3 comments/9 replies呈现与网页错误壳；提案/维护者观点，不是实现源码或所有live traffic文档。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [191815317eae36954916fc5c.txt](../texts/93/9344c82be905819c0339bf33bfb84d8ee77078d67026a4eefbb1733eb42723a3.md) | 讨论正文/已载入评论 | [0, 12000)、[12000, 12745) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/09-environment-reachability-cost.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/09-environment-reachability-cost.md)
- [https://github.com/valhalla/valhalla/discussions/5944](https://github.com/valhalla/valhalla/discussions/5944)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
