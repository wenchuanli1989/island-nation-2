# Godot #101147: NavigationAgent2D.velocity_computed emits zero vector when set_velocity not called

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/godotengine/godot/issues/101147`。
- 已有内容：源码/工程文本、讨论正文/已载入评论。
- 原目录作者：F483，Godot 使用者、复现代码作者。
- 原目录日期：2025-01-05（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot/issues/101147](https://github.com/godotengine/godot/issues/101147)

## 概要与项目参考

source_fact: 原问题及三个公开评论清楚展示接口理解偏差，修复建议是maintainer说明；未运行Godot，也未核当前版本实现。
domino_recommendation: 未来导航意图/局部避让/实际运动/到达反馈分层，模式切换必须停止旧来源输出并核motion/task revision；路径缓存输出不是身体已到。Domino(0,0)有效，不能照抄Vector2.ZERO当无target的样例约定。

## 已有机制分析

源事实：Godot4.3用户在direct movement禁路径时仍保留NavigationAgent用于到达检查，未调用set_velocity却收到零velocity_computed，覆盖owner.velocity并影响动画朝向；给出完整Movement样例和dash/dodgeroll动机。
源事实：公开回复称此行为by design，并说明无需断开signal，应禁avoidance_enabled使agent退出RVO avoidance simulation。path following、avoidance participation与回调连接是不同开关。
源事实：样例分别算direct/path方向、avoidance velocity、实际move_and_slide、overshoot arrival和knockback；此层次为用户应用代码，不是Godot引擎源码或已验证正确方案。

## 后续行为与玩法启发

犯罪/追捕：逃跑、追逐、击退与躲避可以同时产生候选速度，最终执行只接受当前行为世代；旧追捕输出不能覆盖新急救动作。

调查/欺骗：导航到达不是发现证据或相信口供，观察与实际到达分开提交；零速度或卡住不说明 NPC 撒谎。

协作/玩家干预：改目标、路障、推挤与救援会改变实际进度；到达集合点后仍检查队友、占用和承诺。

Domino 建议：玩家推搡/击退、逃逸、冲刺、追捕中切direct movement时不能被旧避让回调改速度；到达门口与进入区域/接触资产分别确认。

同楼常态可省移动，但潜入/室内追逐/封锁需要局部区域和实际距离；帖子只提供运动开关反例，不包含目击、犯罪或追捕设计。

## 适用范围与局限

复现每物理帧设置 target_position、遍历 speed_factors 并检查移动，不提供万人规模验证。Domino 只在活跃移动实体执行必要空间更新，事件驱动任务切换；不能把所有人每帧导航与全局 Floyd 重建照搬。

断开callback不等于退出avoidance模拟，万人若不可见/远处/被禁用agent仍参与会白算；应按有效局部角色注册/退出。

帖子没有RVO邻居复杂度、数据规模或性能测试。全员avoidance/逐帧路径定位仍可能昂贵，Domino当前无空间桶和运动推进，不能由这个issue认定已完成优化。

显式区分 desired_velocity、safe_velocity、actual displacement；击退累计及到期衰减单独定义。保留任务版本和订阅句柄，避免通过零向量同时表示无目标、无速度和任务终止。

把path_enable、avoidance_enable、movement_mode和输出owner合同明确，减少用户各自disconnect信号的隐式修补；旧输出按稳定实例/version丢弃。

应用代码有外部Statsheet/Utils依赖、重复target设置和零哨兵等细节，不能当独立复现项目或C23模板；只吸收责任边界。

目标 Vector2.ZERO 被用作无目标哨兵，使世界原点无法正常作为目标。

示例 block_finished 会抑制 arrived；导航状态可能未随直线移动更新，不能推出所有到达判断正确。

velocity 被写成零但作者称移动未受影响，只动画选精灵受影响；这是报告现象而非经 reader 运行证实的引擎因果。

没有评论、维护者结论、修复提交、局部避障死锁或实际线程并发证据。

把“不调用set_velocity”等同停止避让，会持续收到旧/零结果；丢callback仍留下系统CPU工作。

owner velocity可与刚完成move位置不一致，动画现象不是身体不动证据；is_navigation_finished不总等实际接触。

用户stop会发stopped且随后arrived，重复触发/旧回调应按当前任务终态校验，不能以标签多发认定多次结算。

完整阅读本地 issue 正文和复现代码，未运行 Godot，也未确认当前问题状态或后续修复。

已完整读归档issue描述/代码与三评论；未核#81761、Godot源码、可运行MRP或当前open状态。

排除理由：具体接口反例有用但高度Godot专用、缺普适调度/业务生命周期或规模证据。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [e249ec8e6df5c33c10ae6f7b.repaired.txt](../texts/0c/0c74fe51627e8ed4c79d1e2141469ca260df68926fdf175270a30df2f5f48afa.md) | 讨论正文/已载入评论 | [0, 8631) |
| [e249ec8e6df5c33c10ae6f7b.txt](../texts/15/15120aa7c6eed0ceee7f9430b0fc4b0e1bfc5ead74f24c4ab6daca13341c404d.md) | 源码/工程文本 | [0, 7555) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/03-local-avoidance-deadlock.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/03-local-avoidance-deadlock.md)
- [https://github.com/godotengine/godot/issues/101147](https://github.com/godotengine/godot/issues/101147)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
