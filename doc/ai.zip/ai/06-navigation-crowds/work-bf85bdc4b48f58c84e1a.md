# Navigation2 WG Meeting Notes 12/5 and 12/12/19

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://discourse.openrobotics.org/t/navigation2-wg-meeting-notes-12-5-and-12-12-19/12020`。
- 已有内容：文章/文档正文。
- 原目录作者：mkhansen；Navigation2 工作组会议记录发布者，正文致谢 cdelsey 记录；列有导航项目参与者。
- 原目录日期：2019-12-19（沿用已有记录）。
- 主要来源：[https://discourse.openrobotics.org/t/navigation2-wg-meeting-notes-12-5-and-12-12-19/12020](https://discourse.openrobotics.org/t/navigation2-wg-meeting-notes-12-5-and-12-12-19/12020)

## 概要与项目参考

Domino inference: invalidated route/service/target should wake only affected tasks immediately, independent of routine planning cadence; keep path computation request, actual travel progress and stop confirmation distinct.

Domino inference: a shared lifecycle interface can expose request/feedback/cancel acknowledgment without requiring a behavior-tree runtime.

Domino inference: region restrictions/speed/preference definitions can be common query data, but physical passability, lawful access and NPC risk must remain separate for infiltration/escape gameplay.

## 已有机制分析

Source meeting proposes immediate replan on plan invalidation even when navigation is not periodically replanned; one candidate is another ComputePathToPose instance in recovery behavior.
Source discusses splitting BT action requests, responses and feedback into separate nodes so other tree branches can explicitly cancel/interact with an existing request; halting an action node is described as a less direct cancellation route.
Source proposes common costmap-layer treatment for slow/keep-out/preferred-lane zones while explicitly noting unresolved lane directionality requirements. Simpler test worlds are said to be insufficient.

## 后续行为与玩法启发

Player blocks a road or cancels assistance; affected NPC requests stop/replan and preserves actual position before selecting an alternative.

Slow zones, security areas and directional lanes can change patrol/escape routes; legally forbidden areas need not be physically impossible for a criminal.

## 适用范围与局限

Event-local invalidation avoids periodic full replanning for 10000 NPCs; replan bursts still require coalescing and bounded queues.

Source offers no latency, graph size or multi-agent cost data; extra recovery planners could duplicate work unless request generations/cancellation are controlled.

Complex-world tests are proposed because simple maps hide failures; this reader ran no tests or engines.

Separate navigation phases and explicit ownership of outstanding requests; late path responses must match current task/revision before acceptance.

Lane semantics require a clear contract rather than using one ambiguous scalar cost for directed travel and preference.

Meeting minutes contain proposals/status, not evidence these designs were implemented or remained current.

Periodic-only replanning leaves an invalid plan active when no regular timer exists.

Halting a node or issuing cancel does not by itself prove physical movement stopped or occupancy released.

Treating preferred lanes as directed lanes silently changes reachable routes and deadlocks/opposition behavior.

A simple CI world can miss route invalidation/cancellation interactions.

Complete local meeting-note text read; linked issues #1395/#1387/#1263, actual Nav2 code, localization comparisons and video not inspected.

No statement of current Nav2 behavior or Domino support; robotics movement/controller semantics require game-specific adaptation.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [1d1767592334d9c2a22ada10.txt](../texts/39/39ccb63d42d4ed88d8bd4608b9b33815bc84e84dfc164d84bef96ed792d17645.md) | 文章/文档正文 | [0, 4586) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/07-navigation-failure-handoff.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/07-navigation-failure-handoff.md)
- [https://discourse.openrobotics.org/t/navigation2-wg-meeting-notes-12-5-and-12-12-19/12020](https://discourse.openrobotics.org/t/navigation2-wg-meeting-notes-12-5-and-12-12-19/12020)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
