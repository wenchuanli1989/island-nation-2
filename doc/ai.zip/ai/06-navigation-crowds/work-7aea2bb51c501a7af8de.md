# Build Your Own Navigation Stack! | AI and Games Conference 2025

- 分类：导航、人群、交通与空间协调。
- 资料标识：`identity-limited-unit:13088b3c98f4ad450d5b8f93af7fa4c362a9d50912c545a6689d39a040406e58`。
- 已有内容：字幕/转录文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录日期：2026-09-30（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=wOfrvaZLn6I](https://www.youtube.com/watch?v=wOfrvaZLn6I)

## 概要与项目参考

当前Domino整组Floyd失效、坐标最近路口O(V)和路径不含运动闭环存在明确接点；作品提供共享预计算、局部版本化及空间能力数据机制，非要求立即替换道路图为Recast。

## 已有机制分析

source_fact: 讲者将导航生成拆为有依赖的阶段，复用中间高度场/多边形数据；扩展分类器生成攀越、跳跃及掩体，并把执行所需几何写入瓦片。
domino_recommendation: 未来局部强互动可预计算动作接入点和必要参数，查询与执行职责分开；可先用直接C阶段/类型ops，不需要通用插件框架。
source_fact: 按高度、水深等属性编码通行条件，供不同能力角色使用共享导航表示；具体寻路消费这些属性的方法被明确留在讲座范围外。
domino_recommendation: 共享道路/局部区域事实，查询时按体型/能力/运输方式限制；制度许可与非法潜入意图单列，避免把违法等同物理不可达。
source_fact: 独立瓦片存储控制加载与时间切片；预生成多个环境版本，切换前校验基础数据哈希，匹配区复用，不匹配区重生成。
domino_recommendation: 动态封路/洪水/玩家建筑导致局部版本变化时，只使依赖路线失效并分批重建；现有Floyd整组缓存可作为粗层，精细局部层需明确升级触发。
source_fact: 把移动导航存于局部原点，查询时转换坐标，输出再映射世界坐标；扩展数据也随局部表示使用。
domino_recommendation: 车辆、船舱或移动载体内部活动按局部空间建模，上下车/船仍需世界运动、承诺和实际到达反馈。

## 后续行为与玩法启发

潜入攀越、掩体、室内追逐及逃跑路线可用局部动作边；玩家封锁/破坏/洪水触发真实拓扑变化。

水深/体型/跳跃能力改变物理候选，而权限、被发现风险、违法后果留给任务/认知领域。

交通工具内犯罪、调查或合作需载体局部坐标与世界身份同时有效；不能把整栋/整船空间视作等价。

## 适用范围与局限

author_claims:
讲者描述2×2 km地图、32核/64GB机器和与引擎默认配置比较的生成速度/内存优势；字幕数值句含歧义，未核看图表，不认定精确倍数。

domino_cost_inference:
共享预计算能减运行查询成本，但瓦片版本、能力标注和扩展几何也增加内存及一致性成本；没有10,000 NPC路径吞吐或行为正确性证据。多能力不应各自复制全图。

依赖阶段和序列化扩展有清楚所有权/版本合同；保持查询结果、运动执行、资源占用与业务完成分离。

以实际局部强互动需要引入小范围精细图；不要为了抽象完整性在当前粗路网中重建泛化插件系统。

动态替换必须校验几何版本、路径引用与占用，未匹配缓存不能继续当真。

预生成洪水版本若忽略玩家改变的基础地形，会产生过期路线；讲者明确要求哈希匹配检查。

共享属性数据不等于已实现所有角色寻路，讲者说明路径算法消费部分不在讲座内。

上下文自报更快生成不保证万人实时更新；移动局部坐标也不解决跨载体入口/离场资源协议。

自动字幕Recast/Unreal等专名大量误转，分类/性能图及示例画面均未核看。

完整保存自动字幕载体已读；未看demo、图表/代码、未核听音轨或复现生成/查询性能。

Full saved external caption carrier is present and fully parsed, but no claim of complete original video or audio coverage.

Last export time is a cue start. Saved source duration is a historical page/owner metadata claim, not a current media probe; a long tail is an uncertainty flag, not proof of missing spoken content.

本轮现有nav接口静态不一致仍存在，不能把此映射写成已可运行导航能力。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [external-wOfrvaZLn6I.full-caption.txt](../texts/51/51e77911b872399d0468066464e242579e151e6e6e1286528adb678770d63523.md) | 字幕/转录文本 | [0, 11000)、[11000, 22000)、[22000, 30496) |

## 原研究概要与相关链接

- [https://www.youtube.com/watch?v=wOfrvaZLn6I](https://www.youtube.com/watch?v=wOfrvaZLn6I)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
