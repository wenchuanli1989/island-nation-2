# Metrotown: A new city builder where you fix car-centric cities — main post and selected author replies

- 分类：导航、人群、交通与空间协调。
- 资料标识：`reddit-post:1udqm4c`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：u/SystemSE (Metrotown developer)。
- 原目录日期：2026-06-23（沿用已有记录）。
- 主要来源：[https://www.reddit.com/r/transit/comments/1udqm4c/a_new_city_builder_where_you_fix_carcentric_cities/](https://www.reddit.com/r/transit/comments/1udqm4c/a_new_city_builder_where_you_fix_carcentric_cities/)

## 概要与项目参考

domino_recommendations: 服务选址、岗位/住房布局通过实际通勤成本影响选择，路径权重与距离/ETA分开后才能接入。
停车与服务容量的占用/释放、找位等待和放弃需真实生命周期，不能把预测地价变化直接结算资产。
用局部居住/职业/目的地候选及有界交通模式比较，先做普通C规则。

## 已有机制分析

source_facts: 载体包含实际主帖与选定作者答复的引用，而非只有分析；作者称出行模式评价、停车需求与混合用途机制存在。
停车少增加寻找车位时间，降低郊区到市中心便利及郊区地价；市中心地价上升可能转移成本，公共交通/分散就业可抵消。
作者称高密度住宅必须比其他可供同人数方案每户成本更低才开工；出行选择比较不同模式时间，不因公共交通供给多就自动选择它。

## 后续行为与玩法启发

玩家调整车位、公交、混合用途和岗位位置，NPC改变出行方式与住宅/岗位偏好，形成可观察空间后果。

运输、合作通勤或逃跑路线可共享真实通行成本，违法停车/欺诈广告须另加许可与主观信息规则。

## 适用范围与局限

作者没有给人数、分配算法、开销/公式，不能推断万级多模式路径成本。

若每NPC查询所有房屋/岗位/车位退化全体互配，需地域索引、缓存revision和有限选择。

选定答复讲因果但无精确参数；实现应保留时间、容量、建设成本和价值估计各自来源。

本地全文件已读不等于Reddit完整线程、媒体或网站技术文档已读。

公交多但更慢仍会选车；减少停车不保证全城所有地区获益。

每户建造成本比较不保证融资、材料和施工可行，计划不能直接出现新楼。

作者机制宣称不是源码或实测结果；不可补写未见评论。

全文3020字符引用/访问说明载体已读；主帖完整可见文本和选定作者回复，非完整讨论归档。

未取得源码、公式、参数、独立测量或附带媒体；正文机制是作者主张。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [metrotown-evidence.md](../texts/e7/e744f18b243ed9f6aa31065f8c0cfb70f187cabf882fa11b6685b3ed39501b8e.md) | 讨论正文/已载入评论 | [0, 3020) |

## 原研究概要与相关链接

- [14-three-sites-2026-10-04/06-economy/housing/metrotown-evidence.md](../../ai-reference/14-three-sites-2026-10-04/06-economy/housing/metrotown-evidence.md)
- [https://www.reddit.com/r/transit/comments/1udqm4c/a_new_city_builder_where_you_fix_carcentric_cities/](https://www.reddit.com/r/transit/comments/1udqm4c/a_new_city_builder_where_you_fix_carcentric_cities/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
