# UAISense_Sight

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/AIModule/Perception/UAISense_Sight?application_version=5.5`。
- 已有内容：文章/文档正文。
- 原目录作者：Epic Games。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/AIModule/Perception/UAISense_Sight?application_version=5.5](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/AIModule/Perception/UAISense_Sight?application_version=5.5)

## 概要与项目参考

Domino 推导：先按空间与权限形成稀疏候选，再预算视线验证、调度和未完成请求；将目击更新的延迟、观察版本、失效监听者写清楚。
感知只能生成某个体的观察/记忆候选，物理可见不自动等于认出身份、判定犯罪、报告警方或共享全世界事实。

## 已有机制分析

UAISense_Sight 暴露每 tick 同步/异步 trace 上限、时间片上限、时间检查粒度，并将查询分成 InRange、OutOfRange、Pending 三组。
文档明确称 SightQueries 是 n² 问题；远距查询的距离分数为零、只随 age 变化，因此减少远距列表排序并主要排序近距列表。减少排序不等于已消除候选对数或内存增长。
PendingQueriesBudgetReductionRatio 依据本轮开始时未完成的异步查询减少新 trace 预算；查询有 QueryID、Index 或 TraceHandle 的完成回调与 listener/target 删除接口。

## 后续行为与玩法启发

夜间盗窃、追捕与遮挡应允许漏看和延后看见；已有世界事件仍可发生，不因感知预算耗尽而被删掉。

可按距离、紧迫度和个体注意力分配目击预算；关系、风险和举报意愿在观察之后另外决策。

## 适用范围与局限

API 确认多种执行预算和 n² 排序问题，没有提供 10000 NPC 的总候选数、CPU 或内存测量。

预算限制单 tick 工作量；如果候选生成仍为全体配对、Pending 不受容量限制或持续超负荷，队列和观察滞后仍会增长。

监听者/目标被移除或位置版本改变时，使挂起查询无效；晚到结果须校验目标 ID/版本和所属观察请求。

内部删除方法注明 QueriesListAccessDetector 写访问要求，说明列表所有权和并发访问应明确；不能由 API 列表推出线程安全实现。

把 OutOfRange 分类当成 O(N) 证明，会忽略原 n² 查询建立和存储成本。

预算耗尽时把未检查目标记成不可见，会形成假的否定事实；不能把查询未完成当成证据。

读完 API 不代表读过 Update/回调实现，也不能确认删除与异步完成竞态已经正确处理。

完整本地 UE 5.5 API 页已读，证据是声明与字段注释，未读 AISense_Sight.cpp 实现或运行场景。

每 tick 是原引擎语境；Domino 必须使用未冻结现实时间 _ms，不能把游戏日历倍率用于 trace 业务预算。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [16c6cc5bd74dbd37116fe537.txt](../texts/db/db23da3307c00dbee893f8302249b7f4200cae70376beeb6e217ac77997304e1.md) | 文章/文档正文 | [0, 6365) |

## 原研究概要与相关链接

- [03-world-perception-navigation/02-perception-attention.md](../../ai-reference/03-world-perception-navigation/02-perception-attention.md)
- [https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/AIModule/Perception/UAISense_Sight?application_version=5.5](https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/AIModule/Perception/UAISense_Sight?application_version=5.5)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
