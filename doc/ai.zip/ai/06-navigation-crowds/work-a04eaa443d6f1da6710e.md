# 场景查询系统快速入门

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://dev.epicgames.com/documentation/zh-cn/unreal-engine/environment-query-system-quick-start-in-unreal-engine`。
- 已有内容：文章/文档正文。
- 原目录作者：Epic Games。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://dev.epicgames.com/documentation/zh-cn/unreal-engine/environment-query-system-quick-start-in-unreal-engine](https://dev.epicgames.com/documentation/zh-cn/unreal-engine/environment-query-system-quick-start-in-unreal-engine)

## 概要与项目参考

Domino建议：候选生成、约束过滤、评分分离为普通C共享定义，先对有限局部候选做便宜物理/资源过滤，再用路线/感知等昂贵测试，保存过滤原因与分项分数。
查询结果是待执行地点，不是已到达/资源已领取；统一执行者核实当前位置、路线版本和实际完成事件。
感知变化发局部事件，中断/恢复走公共生命周期；现实_ms timer通知带目标/task/wake版本，旧失视超时不得清除后来新目标。

## 已有机制分析

EQS把Generator、Context与Tests分开：示例在查询NPC周围生成Grid点，以玩家actor为情境，trace过滤可见点，distance仅计分，再把Winner位置写黑板供MoveTo。
测试自动将过滤优先并按开销排序，便宜距离过滤可早于视线，缩小后续昂贵测试集合；文档明确grid范围/spacing决定点数，过大影响性能。
TargetActor触发高优先战斗分支并中止巡逻；HasLineOfSight切换Attack/MoveIntoPosition，感知事件更新键，丢失视线启动8秒timer，重见时清除并失效timer，超时清TargetActor回巡逻。
巡逻随机可达点生成失败时用当前位置并完成该任务，随后有限Wait；调试工具显示每点分数/剔除与Winner，EQS测试Pawn及VisLog提供查询解释。

## 后续行为与玩法启发

潜入、追捕、掩护、堵门、观察与逃跑可复用空间候选pipeline；用本人的已知/最后观察位置作为情境，区分看得见、走得到、获准进入和愿意承担风险。

玩家改变遮挡、封路、诱饵或资源位置时只修正受影响候选；躲过视线可令NPC搜寻/遗忘，而真实犯罪事实及证词另存。

## 适用范围与局限

网格点数近似随(范围/间距)²增长，每点多次trace/路线query昂贵；10,000人同时查询不可直接沿用教学配置。

限定局部服务/区域候选、共享静态候选集、预算昂贵测试、事件唤醒和分批续算；未知/待算不能当不可达。

官方教程没有具体NPC数量、查询耗时或C23性能数据，蓝图/C++对比仅定性建议。

共享candidate tests与参数、实例仅存context/结果，方便增删空间条件；分项debug应按需开启，避免所有点每次日志。

法许可和道德风险属于领域条件/效用，不要用通用物理filter提前删除违法动作。

弃追timer应保存业务截止与状态版本，加载后重建timer；不能持久化UE句柄或复制GetAllActors的全图查询习惯。

Get Player Character提供实时全知玩家位置，离视线后继续拿它查询可能不符合有限知识；项目应使用观察记忆。

终点有视线、距离近不保证路径安全/有通行权；正距离评分可能使NPC为远点穿过敌人，文档自身解释这一副作用。

多目标感知时一个LostSightTimer与PerceivedActor变量可能互相覆盖；示例单玩家不证明多人语义。

巡逻生成失败被标Success只表示设置当前位置任务结束，不是移动、搜寻或战斗目标成功。

9,510字符官方中文教程全文已读，未核看蓝图图片/嵌入视频、未运行UE项目或审EQS实现。

原文教学场景没有攻击效果、复杂目标记忆、任务持久化或万人测量；提名其有限候选pipeline、测试排序与解释工具机制。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [0e8a765d06b6a2e3ba88a074.txt](../texts/b4/b428d778238c37526ec12e92d47413cbf962f97fb63b927717816b00372af57a.md) | 文章/文档正文 | [0, 9510) |

## 原研究概要与相关链接

- [03-world-perception-navigation/07-spatial-queries.md](../../ai-reference/03-world-perception-navigation/07-spatial-queries.md)
- [https://dev.epicgames.com/documentation/zh-cn/unreal-engine/environment-query-system-quick-start-in-unreal-engine](https://dev.epicgames.com/documentation/zh-cn/unreal-engine/environment-query-system-quick-start-in-unreal-engine)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
