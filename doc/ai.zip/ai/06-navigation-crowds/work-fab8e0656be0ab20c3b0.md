# Customizable Contraction Hierarchies -- A Survey

- 分类：导航、人群、交通与空间协调。
- 资料标识：`arxiv:2502.10519`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Thomas Bläsius; Valentin Buchhold; Dorothea Wagner; Tim Zeitz; Michael Zündorf。
- 原目录日期：2025-02-14（沿用已有记录）。
- 主要来源：[https://arxiv.org/pdf/2502.10519](https://arxiv.org/pdf/2502.10519)

## 概要与项目参考

Domino 推论：导航从当前 Floyd 全对全走向动态权重和大量按需查询时，三阶段共享图索引是强备选；实体稳定 ID 与 rank/index 必须隔离，图版本变化使 scratch/cache 失效。现阶段不因论文通用性立即替换现有 nav。
Domino 推论：设施候选先按地域/服务条件缩小，再复用单源距离或 k-nearest 查询；距离和任务效用估计只进只读草案，执行仍确认实际位置、路线版本、容量与进度。

## 已有机制分析

原文：把 metric-independent topology preprocessing、weight customization、shortest-path query 分开；无向拓扑承载双向不同非负权重，∞ 表示单向不可通行。按秩收缩高秩邻居补团，lower-triangle relaxation 保持最短路，并允许 up-down search。
原文：nested dissection 小平衡分隔，DFS post-order 重排提高缓存；升向图扁平邻接与父节点数组形成 elimination tree，无优先队列查询。排序去重后只将子节点剩余升邻接并入父节点，避免重复补边。
原文：basic customization 可选单线程线性三角扫或 batched triangle relaxation；批内集中修改该点的边，按 separator 子任务依赖顺序并行。perfect customization 自顶向下识别可删方向边，分块计数+前缀和+拷贝+旧新 edge ID 重映射构造精简图。
原文：快捷边显式保存两条 unpacking edge，路径还原按输出长度付费；Lazy RPHAST memoize 同源多目标距离；POI separator lower bound 剪枝加排序 targets，而非为每目标重复完整查询。CCH distance 只有确实是下界时才可作 A* potential。

## 后续行为与玩法启发

封路、拥堵、潜入路线、追捕与逃逸可用同一实际拓扑和方向成本，角色对风险/目击/收费的权重可分离为主观 metric；违法性不能统一设∞，物理阻断与制度禁令要分开。

玩家改变道路和设施会影响可达候选与替代目的地，便于形成可观察导航因果；论文不提供犯罪发现、证据传播或抓捕结算。

## 适用范围与局限

原文基准为 Rust release/native、双 Xeon E5-2670/16 cores/64GiB，Stuttgart约110k vertices、252k edges，百万随机点对查询；这只证明作者测试环境的道路图算法，不证明 10000 NPC 完整模拟。

原文 Stuttgart perfect-customized distance约14.5µs（travel metric）另还原5.4µs，total customization约11.67ms/8 threads；Europe query约137.5µs，customization约1.25s/16 threads，metric-independent preprocessing约361.1s。不能照搬到 Domino 地图或硬件。

补团空间与三角数量依赖 separator 与图结构，高度/填充可很差；CRP 每 metric 空间更小。每 worker 重用独占 graph-sized scratch，不给每 NPC 分配整图 distance arrays；任务集中唤醒仍须预算。

拓扑较稳定是三阶段收益前提；道路新增需要重做 topology index，已有边关闭可用∞ metric，但定制完成前不能混用旧权重/新路径。

保留最小 basic customization 作为正确性层；perfect pruning 与 unpacking 是明确性能取舍。扁平邻接、方向权重、旧新 edge ID 映射和按 vertex 的依赖任务可用普通 C 实现，但 nested dissection、动态索引发布和路线取消接口仍属较大引入成本。

分隔器并行只在任务读写域独立且依赖满足时可用；小图增加线程会降低性能，不能按地域盲分线程。

坏 rank order 可使 augmented graph 超内存；图拓扑高频改变抵消预处理收益。

两个 upward searches 首次相遇不能结束；需正确 µ 上界剪枝。

perfect pruning 后必须用删除前的 elimination tree，且更新 unpacking edge IDs；漏映射会还原错误路线。

turn-cost graph expansion 的性能恶化超过大小倍率，需专门 rank/preprocess 优化；cost 含负值或 CCH potential 不是下界时原保证不成立。

全文提取载体读完；未看图像、未审计 linked Rust/C++ implementations、未复现 benchmarks。PDF文本含 CVIT 2016 template header 与公式排版挤连，实际 arXiv 2502.10519v1 日期为2025-02-14。

性能为作者主张和表格；当前 human 只遍历日志，此文不补齐需求/任务/执行/存档闭环。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [dc8aeb6316802f34e825e49c.txt](../texts/6c/6c111a8611b2d00777927ac0638d59cc38769ddb1d937a1f1e5478b25dd59f30.md) | 论文/讲义提取文本 | [0, 11000)、[11000, 22000)、[22000, 33000)、[33000, 44000)、[44000, 55000)、[55000, 66000)、[66000, 77000)、[77000, 88000)、[88000, 98568) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md)
- [https://arxiv.org/abs/2502.10519](https://arxiv.org/abs/2502.10519)
- [https://arxiv.org/html/2502.10519v1](https://arxiv.org/html/2502.10519v1)
- [https://arxiv.org/pdf/2502.10519](https://arxiv.org/pdf/2502.10519)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
