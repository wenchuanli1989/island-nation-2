# RecastNavigation commit 9f4ce644: 空tris防护

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1`。
- 已有内容：源码/工程文本。
- 主要来源：[https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1](https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1)

## 概要与项目参考

为局部几何构建的有效数据前置条件提供小例；与人类任务规划关系弱，不代表Recast整体寻路机制。

## 已有机制分析

唯一实际diff在buildPolyDetail中访问&tris[0]之前增加if (tris.size()==0) continue；空三角形列表不再进入distToTriMesh。

## 后续行为与玩法启发

细化室内潜入/封锁空间时可能需要有效几何，但此补丁没有行为互动逻辑。

## 适用范围与局限

单次空列表判断，未提供导航构建成本/吞吐或万NPC证据。

明确在使用元素0前检查有效集合；C数组版也须维护计数与指针条件。

跳过点不能证明最终mesh非空/完整；整条几何失败传播不在diff内。

完整短diff页，非Recast源码全读；能证明补丁内容，不能外推库完整行为。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [a819d18ed22b3a610bd533dc.txt](../texts/58/58894d72b68e13cc291d9345d520f45712483981e690853cb925e34a2dde2477.md) | 源码/工程文本 | [0, 808) |

## 原研究概要与相关链接

- [11-open-source-projects/03-navigation-environment/recastnavigation.md](../../ai-reference/11-open-source-projects/03-navigation-environment/recastnavigation.md)
- [https://github.com/recastnavigation/recastnavigation](https://github.com/recastnavigation/recastnavigation)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp#L973-L1018](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp#L973-L1018)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp#L1046-L1110](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp#L1046-L1110)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp#L439-L462](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp#L439-L462)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp#L77-L134](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp#L77-L134)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp#L583-L637](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp#L583-L637)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/License.txt](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/License.txt)
- [https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1](https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
