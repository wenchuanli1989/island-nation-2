# Prevent navigation baking on specified areas

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://forum.godotengine.org/t/prevent-navigation-baking-on-specified-areas/74773`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：guuuuui，复现报告者；smix8，Godot 导航贡献者。
- 原目录日期：2024-07-30（沿用已有记录）。
- 主要来源：[https://forum.godotengine.org/t/prevent-navigation-baking-on-specified-areas/74773](https://forum.godotengine.org/t/prevent-navigation-baking-on-specified-areas/74773)

## 概要与项目参考

domino_recommendations: 将静态可通行区域构建与运行时局部避障分开，局部潜入/室内追逐细化时只启必要区域。
可视化编辑器transform不一定等于计算几何实际输入，保存/验证有效顶点并显示真实禁止区域。
value_reason: 好反例，当前道路/Floyd不直接需要Godot navmesh。

## 已有机制分析

source_facts: 提问者希望bake排除屋顶/室内，collision box仍在顶部生成导航；回复区分4.2 dummy geometry与4.3 obstacle bake选项。
提问者报告90fps降8、ready删除obstacle恢复；答复指默认avoidance开销，关闭avoidance仍保留仅bake参与。
答复称obstacle除position不支持transform scale/rotation，改vertices；axis-aligned shape栅格化占用voxel后丢弃格，精度受cell size。

## 后续行为与玩法启发

潜入/犯罪/调查：屋顶、室内禁入区和门口封锁需物理区域与制度权限分开，犯罪可以进入未许可但物理可达区域。

合作/玩家互动：玩家建障碍或改入口产生真实路径变化，非全世界精细avoidance。

## 适用范围与局限

source_claim:
单用户fps观察，无NPC数/硬件、未独立复现。

domino_boundary:
复杂动态obstacles广播更新可昂贵；静态bake与活跃局部avoidance预算分开，不能称关闭后一般零成本。

保留bake数据、运行状态、显示gizmo三种语义；版本/API仅2024讨论。

把collision box当排除体仍生成其顶面路线；UI缩放/旋转不改变实际obstacle。

误开avoidance造成频繁运行成本，删除整个对象会混淆解决原因。

全文保存九帖已读，原PR/code未读；技术答复与fps仅来源陈述。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [4402ca4f58a44164a67820b6.txt](../texts/69/69616f4287bebc2282469b50913be1337d191d02a67d4e596b6852b895022a01.md) | 讨论正文/已载入评论 | [0, 3328) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/03-local-avoidance-deadlock.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/03-local-avoidance-deadlock.md)
- [https://forum.godotengine.org/t/prevent-navigation-baking-on-specified-areas/74773](https://forum.godotengine.org/t/prevent-navigation-baking-on-specified-areas/74773)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
