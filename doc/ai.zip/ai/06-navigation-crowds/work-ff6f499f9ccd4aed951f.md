# Recast Navigation: Crowd

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://recastnav.com/group__crowd.html`。
- 已有内容：文章/文档正文。
- 原目录作者：Mikko Mononen; Recast Navigation project。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://recastnav.com/group__crowd.html](https://recastnav.com/group__crowd.html)

## 概要与项目参考

Domino建议：高层Floyd路线/任务目标与局部移动控制分工，路径权重不能直接当ETA/位置完成。
接管者只有一个真实位置写入口；室内追逐或密集临场场景局部升级，常态建筑级模拟保留。

## 已有机制分析

dtNavMeshQuery/dtPathCorridor提供路径/走廊，dtCrowd额外接管位置与速度，按max speed/acceleration和局部目标每更新产生受navmesh约束的移动与避让。
局部steering最多考虑6邻居、4角点（实际有用少一个）、8种避障配置；更新flags区分separation、anticipate、obstacle avoidance、visible/topology path优化。
文档限制局部目标不得远过256polygon，长距离规划需外部提供中间目标；任意外部覆盖位置/速度会破坏crowd控制假设。

## 后续行为与玩法启发

堵门、群体逃离、追逐/潜入可产生真实通行限制；玩家推挤或封锁要走统一移动请求，不能反复外部瞬移破坏局部避障。

观察/举报仍要基于实际局部空间与目击，不能从路径点推断犯罪已发生。

## 适用范围与局限

文档给20..30active agents、25人约0.5ms/frame起步建议，属于该文档作者说明且未给硬件/新版本条件，不能当全库硬上限或当前万级容量。

6邻居上限是局部steering可控成本的具体证据；世界全员每帧crowd不受本页支持。

局部高精度区域需跨区域进入/退出/中间目标边界，不能在未模拟区域随机补造支付/消费/目击。

本页summary说所有agent用同dtQueryFilter，但后文又列16 filter types及queryFilterType；需要源码/详细dtCrowdAPI澄清，不能直接假定只有一种许可过滤。

Detour是C++，应提炼边界和局部邻居容量而非替代C23总体架构；共享navmesh/定义与个人corridor/velocity分开。

超长目标可能无法到达，即使全局路由可达。

外部持续覆盖位置/速度导致crowd控制失效。

邻居裁剪不等于所有拥堵/死锁或身体碰撞都已解决；本页没有生产正确性保证。

完整读本页0..6552；未审计Recast/Detour源码、其他API、实际吞吐或图像。

本页数字是文档建议且有过滤器表述矛盾，绝非万级NPC证据。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [ba0a104554b5f1a9c6c9b25f.txt](../texts/04/042378628da33e07c07e417e5b30644ee491757cbbc7acf8a4be9d91cadd062a.md) | 文章/文档正文 | [0, 6552) |

## 原研究概要与相关链接

- [03-world-perception-navigation/04-crowd-local-avoidance.md](../../ai-reference/03-world-perception-navigation/04-crowd-local-avoidance.md)
- [https://recastnav.com/group__crowd.html](https://recastnav.com/group__crowd.html)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
