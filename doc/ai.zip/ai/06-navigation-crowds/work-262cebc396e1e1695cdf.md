# Distributed Multi-agent Navigation Based on ORCA Algorithm

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/pathplanning/orca-algorithm`。
- 已有内容：文章/文档正文。
- 原目录作者：Stepan Dergachev; Konstantin Yakovlev。
- 原目录日期：2021-07-01（沿用已有记录）。
- 主要来源：[https://github.com/pathplanning/orca-algorithm](https://github.com/pathplanning/orca-algorithm)

## 概要与项目参考

Domino建议：常态建筑/道路级Floyd路由保留，仅在必要的精细狭路/追逐场景启用局部占位与协调；路径权重不能作为实际到达时间。
给移动behavior加入实际blocked/progress反馈，局部异常唤醒替代全员重规划；协调记录保存参与者/目标/版本，执行器发布一致位置。

## 已有机制分析

源事实：全局Theta*独立规划几何waypoints，每步ORCA对可见邻居速度障碍构造线性约束，选接近preferred velocity的可行速度，再dt推进位置并检查下一waypoint可见性。
源事实：狭路自利避让会deadlock；检测speed-buffer低平均速或common-point人数阈值，局部群切到MAPF，共享同一local world与goals，确定性地各自求同一Push-and-Rotate/ECBS解，取自己的路径执行，全部完成再回正常ORCA。
源事实：agentsmaxnum/sightradius限制邻居，timestep/timeboundary/半径控制模拟；组merge/update、协调成功/失败、MAPF runtime及collisions分别计量。

## 后续行为与玩法启发

玩家封门/挡桥可造成拥堵并触发有依据绕行/让路；追捕、撤离、押送、协同潜入可在局部场景细化空间。

罪犯可能故意不互惠，需行为层允许阻挡/撞击/拒绝让路；不能把ORCA合作假设当所有人物约束。

## 适用范围与局限

README没有万人benchmark；每步对所有活跃agent做避碰，视距高/稠密时近似O(Nk)甚至邻居检索O(N²)，局部MAPF也会组合爆炸。

每人重复求同一MAPF的分散架构对单机增加重复成本；Domino单写者可一个局部协调job计算一次并分发，需限制组大小/预算。

固定dt物理步与累计未冻结现实ms业务时钟分开，冻结不推进移动；远区LOD不可造虚构目击/犯罪。

配置显式保留邻居/速度阈值和MAPF预算，诊断记录成功率与阻塞；源码常量隐藏实验参数是扩展风险。

共享定义与局部运行态分开，不整体移植C++14框架/XML实验器；有需要才新增导航局部层。

途中新增参与者/组merge后旧plan必须隔离；取消/离场释放空间占用。

ORCA collision-free不保证到达，狭路互让会卡死；停滞检测触发后求解也可能失败。

不同agent快照/目标不一致时确定性求解不保证结果一致；异步变化或敌对不互惠会破坏模型。

建筑内全部位置等价无法表达封锁/追逐，但全世界精细避碰也成本过高。

完整读完20107字符仓库页README；没有读src实现或所列论文、没有运行实验，diagram未核图。

ORCA充分避碰条件为源主张，真实碰撞、动态变化及完成性需独立实现验证。

当前Domino暂无该局部层；此候选价值是局部升级/停滞机制，不是要求替换当前图算法。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [58ed41f58cb38535c7afe1f1.txt](../texts/c7/c7d05072c9e581d40e60caa9c82305d792274c0475b4edb4d779432bba26d1d1.md) | 文章/文档正文 | [0, 11500)、[11500, 20107) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/06-crowds-bottlenecks.md)
- [https://arxiv.org/abs/2107.00246](https://arxiv.org/abs/2107.00246)
- [https://arxiv.org/pdf/2107.00246.pdf](https://arxiv.org/pdf/2107.00246.pdf)
- [https://github.com/PathPlanning/ORCA-algorithm](https://github.com/PathPlanning/ORCA-algorithm)
- [https://github.com/pathplanning/orca-algorithm](https://github.com/pathplanning/orca-algorithm)
- [https://www.youtube.com/watch?v=jE2YrXQ_pNs](https://www.youtube.com/watch?v=jE2YrXQ_pNs)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
