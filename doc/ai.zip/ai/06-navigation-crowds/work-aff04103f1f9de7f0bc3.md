# Efficient Route Planning SS2012 Lecture 7 — Contraction Hierarchies, Part 2 of 2

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-7.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Hannah Bast。
- 原目录日期：2012（沿用已有记录）。
- 主要来源：[https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-7.pdf](https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-7.pdf)

## 概要与项目参考

Domino建议：未来道路规模/查询频次超出Floyd代价时，可作为静态基图层级预处理方案；当前先保持有向路语义、图变更失效边界和实际行走步骤。

Domino建议：评估cost而不变更图的模式适合只读规划草案；执行阶段仍逐段验证道路/封锁/服务，shortcut权重不能当实际距离或ETA。

Domino建议：沿visited节点重置临时数据可避免每NPC查询全图清零；本讲最终dist交集仍建议scan数组，不能声称全查询没有Θ(V)环节。

## 已有机制分析

源事实：收缩节点添加shortcut保留剩余节点间最短路径距离，最终G*保留原节点/边及所有shortcut；任意节点顺序保证正确性但效率受排序影响。
源事实：从s向上图前向Dijkstra、从t在向下图反向Dijkstra，交集节点取dist_s[v]+dist_t[v]最小；只有对称图才可两次都在上向图前向搜索。
源事实：用edge difference=新增shortcut数−相邻边数选收缩节点；懒更新、只更新邻居、定期全更新是排序启发式，并可加入已收缩邻居数保持空间多样性。
源事实：预处理在原图添加边、以flags忽略已收缩节点，computeEdgeDifferenceOnly评估不修改图；查询flags固定，visitedNodes避免每次Θ(V)距离数组清零。
源事实：shortcut存被收缩节点v，查到路径后递归将u→w还原成u→v→w，区别求最短代价与返回实际路径。

## 后续行为与玩法启发

物流、追捕、逃逸、玩家封路或破坏桥梁需要实际路径展开与局部中断，预处理路径只是候选依据。

违法潜入候选可以物理可达但制度禁止；不可用统一合法性过滤删除动作，也不能将角色主观风险混进所有NPC共用图而不处理权重版本。

调查/欺骗/关系冲突不由CH提供；它只支撑角色能到达互动现场的路径计算。

## 适用范围与局限

大量静态路网查询可受益于shortcut和局部搜索；万人成本还取决图大小、shortcut量、排序及候选次数，材料没有NPC吞吐。

频繁建路/封路/权重变化可能要求重预处理或另有动态方案；节点排序只更新邻居是启发式，原文指出非邻居也会受影响。

随机排序可能增加shortcut空间，逐收缩全体更新为O(V²)且讲座明确不推荐；规模不应以讲者μs/node片段估算单机游戏实测。

正确性证明和路径展开规则帮助验证实现；引入CH会增加预处理、排序、shortcut恢复和动态失效维护。

可先比较现有Floyd与按需Dijkstra/缓存的实际成本，再确定升级触发条件，不强制改当前nav。

把有向道路误作对称图会选到不存在的逆向通路；上/下是收缩次序而非地理高低。

shortcut未展开就移动会绕过真实封路/容量/事件，图更新后使用旧shortcut会给出不可执行路径。

只看edge difference局部更新会错估预处理效率，但不等于已证明的最短路正确性失败；需区分启发式性能与算法不变量。

完整读10917字符Lecture7提取文字，未核图像；Part1和原论文未由本reader读取。

教学路由机制，无Domino图规模/动态更新实测；不作为当前必须替换Floyd的依据。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [f3bf58603f61543c462f8a7f.txt](../texts/50/5036d84b438ea5b2825e330db76c0210d6bce96c25d5099153cd8c72e938cfcb.md) | 论文/讲义提取文本 | [0, 10917) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md)
- [https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-6.pdf](https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-6.pdf)
- [https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-7.pdf](https://ad-teaching.informatik.uni-freiburg.de/route-planning-ss2012/lecture-7.pdf)
- [https://ad-wiki.informatik.uni-freiburg.de/teaching/EfficientRoutePlanningSS2012](https://ad-wiki.informatik.uni-freiburg.de/teaching/EfficientRoutePlanningSS2012)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
