# dtNavMeshQuery implementation

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-repository-bundle:recastnavigation/recastnavigation@9f4ce64458dfae86e1239c525ddc219c4e9e06f1`。
- 已有内容：文章/文档正文、源码/工程文本。
- 当前前100：第 23 项；[RecastNavigation固定提交：六个源码成员保存束](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/023-182be8db73d5.md)。
- 主要来源：[https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp)

## 概要与项目参考

Domino建议：当前Floyd图寻路仍可保留，提取局部空间候选、预算化长查询和移动结果协议；未来局部室内细化时再评估navmesh。
对道路/门禁突变，任务执行者必须重新验证当前位置与路线版本，不能以DT_SUCCESS或最接近终点的部分路径自动结算到达。

## 已有机制分析

共享导航事实与每查询scratch分离；可借鉴工作线程复用query上下文，而非每NPC长期占节点池。
输入校验、无结果、部分结果、容量不足和完整路径分开，路径规划只生产可解释草案。
maxIter切片与局部图查询约束一次工作预算；filter定义物理可通行性，成本定义偏好，两者分别扩展。

## 后续行为与玩法启发

玩家摆放路障、炸毁通道、临时封门可生成局部导航变更，只有完成实际重建/发布后才影响新路径；逃逸者/追捕者的旧路径要按版本局部失效，不能计划中封路就宣告已不可通行。

几何通行与制度区域权限、NPC知道封路与真实封路是独立记录；源码障碍bounds并不提供目击、犯罪归因或合法性判断。

玩家封路/设置门禁、追逐和潜入让路线请求过期；NPC等待、改路或取消，实际到达由执行者确认。

路线结果只证可用方案，不提供实际距离/ETA、空间占用或犯罪许可。

玩家封门、阻路、占用交通节点可导致真实路径失效、排队和替代路线。

犯罪潜入、警察追逐、押送和群体协作可使用局部邻居/区域粒度；法律许可与几何可达性分别判断。

玩家封路或拆除连接可使正在进行的移动局部失效；NPC 改道、等待或取消，并保留未到达的原因。

追捕、逃逸、潜入可共享物理路线机制，角色风险代价与制度许可由上层决定。

建筑内局部门户/墙支持门禁与封锁，但目击、隐蔽、证词必须另有观察事件。

局部人群拥堵、护送、追逐、堵门与逃跑可影响真实移动进度；失败路径必须反馈到上层任务。

避障几何不能决定是否允许抢劫或潜入，区域许可和犯罪风险要独立；玩家推挤/封路若修改位置，要明确谁控制移动。

玩家封路、移动目标、开启门/连接可导致追逐/逃逸路线修复、局部失效和替代路线。

过滤应区分物理不可达、权限规则和NPC主观风险；违法路径不能因为制度禁止一律物理剔除。

source_facts:
支持动态目标、局部偏离和offmesh连接；无犯罪/调查/信念或合作合同。

domino_recommendation:
追逐嫌疑人、护送队友、玩家堵路或开门可更新局部目标/路径；路线失败和到达服务点分别报告。潜入行为的权限属于制度风险而非全部物理候选排除；可达走廊不能证明无人目击。合作在瓶颈仍需容量占用/拒绝/等待，不由这个走廊类处理。

犯罪逃跑、警卫追击、玩家封堵狭窄入口可依赖局部避让和真实位置；任务成功需要实际到达并重新检验交互。

不同角色避障/查询过滤可反映能力或空间权限，但违法通行仍须区分物理和制度许可。

封路、追捕、逃跑或玩家改变通行权限会触发有限局部路线修复，未完成时人物可等待/选择其他可行任务；路径结果不等于实际移动/ETA。

局部封锁、室内追捕、护送、挤占通道和移动中改道能有真实位置与阻碍后果；NPC 可因堵路等待/换路，而非计划耗时到期就传送到目标。

合法通行与非法潜入可共享物理寻路，权限、发现和警报另由信念/法律层判断，避免导航过滤器自动抹除犯罪可行性。

潜入可把物理墙和可翻越/开锁off-mesh动作区分；制度禁入不能无条件成为passFilter的物理禁止。

追捕、逃逸、封锁道路和寻找附近出口可通过局部可达成本候选实现；犯罪目击与法律归因仍需独立感知/知识系统。

玩家路障、封锁、爆破、潜入与追捕造成局部可通行性变化

罪犯利用更新期间道路旧认知，NPC需区分自己的地图与实际封路事实

场景必要时室内局部空间细化，避免同楼所有动作等价

## 适用范围与局限

受影响tile去重且一次重建一tile限制峰值工作，但单tile重建成本可变，dt参数在update未使用，不能将一次调用当固定时间预算。build/update仍遍历maxObstacles，密集障碍或大范围变化会积压。

queryTiles与update列表容量固定；query超maxResults仍返回DT_SUCCESS，没有显式truncation标志。10000个移动NPC不应全部作为频繁rasterize障碍；需区分局部动态阻碍和人物避让，本文未证明万人导航性能。

maxIters限制每次update搜索成本，固定队列/最大路径限制内存，但MAX_QUEUE数值在未读头文件，不能猜容量。

请求/状态/结果按槽线性扫描，万人同时请求需按活跃相关人数分批和ID索引，不能直接扩大槽数到万人后反复全扫。

预算耗尽时同请求继续占头，长查询可延迟后方请求；不是严格公平的并发多请求轮转。

邻居查询MAX_NEIS32、有限局部容量避免全员O(N²)，高密度仍可能截断危险邻居。

每帧多次O(maxAgents/activeAgents)扫描，所有request的20迭代快搜不受总100迭代约束；集中重规划有尖峰。

每agent初始化256路径corridor，网格maxAgents*4；万级常驻内存/CPU需测量，本文没有万级性能结果。

proximity grid ID为unsigned short；此实现不是无限规模。

空间查询成本取决于覆盖 tiles、局部多边形和展开节点，未证明 10000 个同帧全图 A* 可运行。

每 query 的 node/open-list scratch 与 64-node tiny pool 有固定容量；工作器复用优于每人常驻大池。

local-neighbourhood 对候选结果做重叠比较，可呈局部二次成本；需要小半径、有限结果与唤醒限流。

原文文档称crowd昂贵，建议20-30个、25 agents约0.5ms/frame；该数字无硬件/版本/测法，不能外推10000人能力。

10000人逐帧维护corridor/boundary/速度采样不是低频自主行为调度；可限定local crowd活动子集，其他人仍须真实路线/资源/时间约束。

邻居数组6上限限制局部决策开销，但邻居发现、障碍采样、路径队列实现未读，不能凭header断言O(N)。

visited固定16、局部优化结果32/迭代32、角数有上界，路径合并O(path_len*visited_len)，内存每corridor预分配maxPath；适合有界个人近期路线。

为全部NPC每帧局部修复仍N倍成本，原文件无万人测量；采用事件影响集、按移动活跃者和预算分批。

大位移可能局部查询找错/找不到目标，正文要求比较期望和结果poly并可能全局重寻。

source_facts:
局部visited16、优化res32/iter32有界；merge最坏O(P×V)并移动O(P)缓冲，valid前瞻O(min(P,L))。其他NavMeshQuery内部成本与全crowd感知不在本文件，无万级benchmark。

domino_recommendation:
N个活动NPC全部每帧更新仍有O(N×P)数据移动和N×maxPath常驻缓冲；按实际移动/拓扑变动触发、分批优化，短近端缓存/共享长路径可降低成本。单次局部上限不证明全体预算足够。

文档老式建议25agent约0.5ms/frame、20-30上限是作者指导且条件未知，明确不支持把10k全放一个每帧crowd。

固定邻居数只限后续计算，邻居收集要借proximity grid；本文只有头文件不能证明其查询复杂度。

固定队列内存 O(MAX_QUEUE×maxPathSize)，每次推进限定搜索迭代而非真实耗时；重请求占队首直到完成，可能影响其他请求等待。

查询 status/result 扫有限槽可接受，但扩大到万人槽会变贵；需要队列容量、丢弃/拒绝和等待上限合同，不能假设零成本。

可见预算降低路径/近邻爆发，但每 update 仍多次遍历 maxAgents/activeAgents、重建整个局部 grid，addAgent 线性找空槽；不是 10000 完整 NPC 的成本证明。

每 agent 预分配 256 corridor entries，pathq 4096 nodes、局部 navquery 512 nodes、固定 6 circle/8 segment obstacle capacity；邻居候选 32 和 unsigned short grid id 都是密度/规模边界，不能无成本扩大。

速度采样乘 active walkers、有限邻居和4次碰撞处理仍昂贵；应限定局部活跃域与刷新预算，sleeping/远程人物使用真实业务状态与粗粒度移动约束，不能伪造目击/支付。

Domino推论：全员每帧A*或Dijkstra仍昂贵；用稀疏触发、共享只读nav、按worker scratch及有限maxIter。

findRandomPoint扫描tile，局部neighbourhood含对已有结果的重叠循环，范围扩大会接近局部二次成本；返回buffer不足不意味着搜遍全世界。

sliced任务保持节点池和filter借用生命周期，不能在同一query上插入非切片修改；容量限制可能使搜索产生部分结果。

每update最多一个tile平摊峰值，但更新完成延迟取决于积压。

build每tile扫描maxObstacles，update状态也全扫描障碍；万人动态障碍不能无分析直接照搬。

查询touched与update/request列表有固定上限、contains线性去重，范围过大或队列满需明确处理。

共用salt验证、free list、请求状态和临时context易追踪生存期；新增障碍形状会在add/bounds/rasterize三个分支扩展，需要约束保持一致。

移植独立机制到C可用显式清理goto和类型ops，无需照搬C++构造/析构或全部navmesh流水线；物理/权限变更与业务任务生命周期分开维护。

把状态、版本、结果消费和释放集中在公共query接口，领域任务不直接操控底层搜索。

filter借用必须在请求全周期有效，不能跨kvec扩容保存人物/任务指针；共享定义或值快照更合适。

业务时间用现实毫秒，源码2个update tick回收仅运行策略，不是任务截止或保存语义。

具名目标状态与阶段化循环便于追踪失败；debug记录速度采样数和优化端点。

局部avoidance不能代替座位、室内权限、门锁等真实资源竞争；勿盲目移植全部C++类。

状态位让截断与不可达可诊断；保留单位明确的实际移动进度，成本权重不能当现实 ETA。

虽然 findPath 标 const，实际会清空并写入指针指向的 nodePool/openList；线程共享 query 实例不能仅按 const 判断安全。

type filter 与几何 query 分离有助新增交通模式；缓存需跟随拓扑/能力/过滤条件修订。

普通C接口可保留有限移动状态、请求ID和共享参数；无须为了crowd迁移整个导航到navmesh。

dt单位为秒且若干time字段无后缀；Domino改映射现实_ms/_s，避免游戏显示倍率进入移动进度。

下部文档说所有agent同filter，而上部明确有queryFilterType和16 filters，存在文档漂移，需以实现核实。

接口明确当前位置/目标总受mesh约束，desired不等于actual；路径有效与最优不同，便于显式失败理由。

init只能调用一次、setCorridor容量由caller保证；固定缓冲/类型接口可转C，现文本去缩进不等于完整仓库审计。

明确请求点、返回点、部分有效路径、完整成功的不同结果；trim后不能悄悄把clamped替代目标当原任务完成。

路径实例需要容量和有效性前置契约；assert是内部约束，外部目标/path必须调用前校验。

调用失败是否已改变状态须逐函数写明：moveOverOffmeshConnection先剪路径后查端点，端点查询失败仍可能已剪路径，不能假设false表示无修改。

路径发布与回收安全、执行代次、真实移动进度和存档恢复由Domino执行层补齐。

状态/参数共享定义与实例分离，位置只有一个权威；dt是秒需按Domino现实ms统一换算。

文末“all agents same filter”与前部16 filters/queryFilterType并存，说明文档可能滞后；以具体源码/调用约束核实后才采用。

取消/模型版本/mesh 修订在本文件无接口；调用方必须保证 filter 生命周期、完成后才能取结果及失效请求重试。

MAX_KEEP_ALIVE 按 update ticks 计，不能直接当 Domino 现实毫秒 TTL；运行队列在加载后重建。

路径有效性、异步请求、拓扑优化、局部感知与运动分阶段，状态/flag 与 debug sample 可观察，适合用 C 模块接口解耦。

原实现为 C++、第三方 navmesh 与 allocation helpers；只取接口/预算思想或明确桥接依赖，不能宣称单文件可无改动移植 C23。

池对象重复使用需 active 检查；Domino 借用指针不能跨全局 kvec realloc，持久化保存语义位置/目标/进度并在加载重建队列，源码没有存档协议。

清楚的输入/输出/status detail合同与可复用查询回调有调试价值；直接移植C++类/虚过滤器不符合当前普通C实现，应提取协议而非整库迁移。

保留图版本、工作所有权、节点池和filter生命周期，加载后重建scratch，不保存裸指针。

明确请求/处理中/处理完/移除的公共生命周期适合Domino各类型ops。

按tiles查询和bounded queues易调试，必须保留失败重试与物理事实的独立含义。

update调用buildNavMeshTile返回失败后仍移除该tile并减少所有pending，可能标PROCESSED/EMPTY；源调用方必须处理失败语义，Domino不能把pending=0等同成功。

buildNavMeshTile先删除旧tile再add新tile，若add失败地点为空而非自动回滚；这不满足Domino最后可失败步骤的回滚设计，需要独立决定失败后世界状态。

有限salt最终可能复用；source getTileByRef返回数组借用指针仍不提供跨线程安全。构建tile时idx判定为 >maxTiles，该单文件文本不能当外部输入完整验证证明。

getPathResult本身未验证已完成且返回success，必须服从调用者先核status的合同；不能将拿到handle当成功路径。

结果因未读取失效会导致重复请求/工作，不能据TTL失效处罚NPC或消耗资产。

没有取消/图版本核验；旧路线或任务取消后返回结果需无效果丢弃。

addAgent nearestPoly失败仍产生active INVALID对象，返回槽位不代表移动可行。

路径结果合并依赖起点仍一致，异步期间移动或目标改变可失败，需要版本隔离。

checkPathValidity源码TODO承认重新定位可产生瞬移；不可据此生成目击、犯罪或抵达效果。

预算排队可长等，局部有限邻居和四轮穿透迭代不保证密集群体无死锁。

将 nearestRef==0 的 SUCCESS 当找到点会使用无效 nearestPt。

用 xz raycast 证明二楼可达或视线无阻挡会错误。

将合法权限写成硬 filter 会抹除所有可行潜入路线。

部分路径、节点耗尽或输出截断被当完整成功，会让人物在未到目标时结算行为。

crowd独占位置控制，外部每帧硬改位置/速度会破坏假设；追逐/玩家干预不能无契约地覆盖控制器。

partial valid path不代表最终请求点可达，长途256 polygons边界可能让请求停在中间。

高separation weight让狭窄空间更难操纵；六近邻并不保证密集人群无穿透/死锁。

成功movePosition仅表示局部约束位置已更新，不表示到达计划目标或任务成功。

moveOverOffmeshConnection在查询端点前剪路径，失败后caller不可继续当原走廊完整；本文件不回滚该修改。

trimInvalidPath把目标夹到前缀末端，若执行者用夹后目标误当原服务地点会提前结算。

maxLookAhead未查远端，新封锁可能延后发现，需版本/影响事件防认知与世界状态混淆。

maxLookAhead只检前缀，后段被删而isValid暂true，必须在推进时继续验证。

目标大幅移动超过local查询范围会被clamp；返回true不等于到达原始请求点。

局部修复可能形成非最优路线，持续追逐不能无限保持旧走廊不复核。

offmesh端点查询失败发生在路径剪除之后，失败调用可留下部分状态变更。

partial VALID误当到达导致隔空交易/工资成功；外部不断覆盖position破坏避障约束。

长路径超过局部窗口失败，邻居超过6或大separationWeight在窄区可能堵住；聚集式高精度更新突发。

过早 getPathResult 会释放还在规划的槽并返回成功标记，调用方合同不能忽略；未读结果到期也不等于角色行为成功。

保存 filter 裸指针而请求跨帧会产生寿命风险；路网/目标改变后旧路径须按版本和当前位置拒收。

顶部文档明确局部移动而非长距离全自动路径服务，256 走廊限制可能截断长路；局部 partial 无法证明目标可达。

源码 TODO 承认 nearest-poly 修复会突然 snap；若潜入/追捕中盲目重定位会跨权限边界或漏掉接触/目击事件。

固定邻居候选会遗漏拥挤时更危险对象；4轮位移修正不是严格无碰撞保证。

reset/remove 只清目标/active，本文件未展示统一取消 pathq work 的协议；只靠无效 ref/位置校验不足以证明任务取消与 slot 重用安全。

nearestRef可为0而status成功；路径末端可能最接近而非实际目标。

raycast目标在楼上阳台但XZ相同会报告到达，不能用作真实3D视线、目击或跨层到达证明。

moveAlongSurface只支持小位移；缺节点、栈/缓冲不足或图变动都需要明确失败/部分结果处理。

成本modifier<1可能违反A*启发条件；不得直接把route cost当距离/ETA。

update即使buildNavMeshTile失败也从update队列移除ref并减少pending，因此队列空/upToDate不能当效果成功。

移除旧nav tile后add新tile失败会留下空位置，本文件未实现回滚。

getTilesAt/queryTiles容量只保留上限结果；大障碍可漏覆盖，不能把局部结果当完整事实。

salt有限会回绕，不等于无限代数安全；buildNavMeshTile的idx检查为>maxTiles而非>=，不能无条件称验证完备。

完整阅读该固定commit单一源码文本；未阅读头文件容量、构建器/压缩器/navmesh内部或整仓，未运行或验证故障。风险是可见路径的评审，不宣称完整项目缺陷已复现。

引用机制对局部动态导航和通用生命周期有价值，万级NPC成本及实际寻路质量没有本载体测量。

完整读单一源码文件；未读头文件、sliced算法/调用者或运行寻路。

不能称整仓或万人导航性能已审计；迁移的是调度与生命周期机制。

仅DetourCrowd.cpp，不含PathQueue、ProximityGrid、避障求解器内部和整仓审计。

未运行或测试，未核看游戏表现；分配文字是固定commit历史提取。

仅全文读取一个固定提交源码载体，未审计整个 Recast 仓库、所有头文件、navmesh 构建与 crowd 系统。

未编译、运行或测量万人吞吐；C++ 实现不直接代表 C23 集成成本。

完整读单个header及内嵌文档，未读DetourCrowd.cpp/PathQueue/ObstacleAvoidance实现或运行任何benchmark。

可并入Recast/Detour独立作品的证据包，不作为新的独立作品重复排名。

一个固定SHA源码全文；NavMeshQuery/Crowd调度/避免碰撞未读，无运行或万人基准；不是当前Domino道路图的直接替换。

全文单文件[0,17856)，未读所有Recast/Detour/NavMeshQuery或crowd源码，未构建/运行。

局部拓扑修复不能证明Domino道路图适用性/性能；只迁移机制与结果契约。

载体是repaired源码，非原PDF/视频。

完整只读此header与附带Doxygen，不是整个DetourCrowd实现；未运行基准、未验证源码对doc历史限制的实际行为。

完整 [0,4730) DetourPathQueue.cpp 源码已读，未核头文件/MAX_QUEUE 值、DetourNavMeshQuery 算法或运行性能。

完整读取本地修复后的 DetourCrowd.cpp 38144 字符，未审计其他 Recast/Detour 文件、算法实现、头文件常量定义或整个仓库。

源码证据说明步骤和预算，不能替代运行、吞吐、线程安全或高密度碰撞正确性验证；本轮不构建/运行。

完整阅读单一源码载体105015字符；未审计完整Recast仓库、头文件/图构建或运行性能。

旧显示窗口按当时helper文本长度记录；未伪造中断前UTC。

完整21611字符单C++文件，未读依赖头/压缩器/底层navmesh，未执行或测试。

本材料证明源码路径与局限，不证明万人动态导航吞吐；与其它Recast载体需按作品归并。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [cfc4822cb61feb862b71a970.txt](../texts/06/069cd2ca3f798cbe1b2fc410e9d66f3386cfde09b322360106b76f5d30f81478.md) | 源码/工程文本 | [0, 17162) |
| [b2c0365c72f4bed630718c5c.txt](../texts/1f/1f5149698773831860fa98a86ee6d221e22b8073e8238e0bc879cd29be194242.md) | 文章/文档正文 | [0, 17751) |
| [a5e3fda0119e434ac3f7be2a.txt](../texts/21/21539d5387e9a27285810c77a1457f66c94dbcc14550bbcd79b2d74fa1fe7389.md) | 源码/工程文本 | [0, 18000)、[18000, 36000)、[36000, 54000)、[54000, 72000)、[72000, 83500)、[83500, 95000)、[95000, 96650) |
| [b2c0365c72f4bed630718c5c.repaired.txt](../texts/66/66053c29eddcdb8794569e4f60d0a3d2102740f403822d451d63a1b336cf4855.md) | 源码/工程文本 | [0, 11000)、[11000, 18147) |
| [82770fe938777ff954486c1f.txt](../texts/70/7021dbef428af9aaeed9e781eab4f96035184ea8058a5d080451218cdea7de51.md) | 源码/工程文本 | [0, 4453) |
| [dcf4903cf820a6ececec76e0.txt](../texts/72/72f13dae515f356f0ced259118c73d7f98d5792a74f0312f2f290159ef25ca76.md) | 源码/工程文本 | [0, 11500)、[11500, 20316) |
| [4afef0b719be4d70f0a89c4b.repaired.txt](../texts/ba/bad7b709e92cda82b95c664e03b6f724ef454e269a311bf762b04cb870aeacc8.md) | 源码/工程文本 | [0, 11500)、[11500, 21611) |
| [3b53335ec933317691ec7a24.repaired.txt](../texts/c0/c0d5164dabc3e68ee25ba479d13ae7f77066ccf7bfb461963d16a144caaf3ac5.md) | 源码/工程文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 38144) |
| [af7ce835306e8b38f00d363c.repaired.txt](../texts/c3/c3074da527f1795efa9e9cabd9365b93230eba8b79c0e85bfc4a37d645e41a97.md) | 源码/工程文本 | [0, 17856) |
| [15c8968fd97336378ee9d0b7.repaired.txt](../texts/cf/cff27d6ad0e2a938ba201f60ec7df1316dd9acb6cb544f3d66627910adca0acd.md) | 源码/工程文本 | [0, 4730) |
| [3b53335ec933317691ec7a24.txt](../texts/e5/e5a88a5e693d30f243238fa7c493f0ff2f0a25ee82d4a82f11951a129e208cd3.md) | 源码/工程文本 | [0, 11000)、[11000, 22000)、[22000, 33000)、[33000, 35268) |
| [4ba9fcc127467a7a41377828.repaired.txt](../texts/ed/ed7729f44b85f379aeaefec8426bbd2ee201491436cc0df991d12f9b09225bf2.md) | 源码/工程文本 | [0, 18000)、[18000, 36000)、[36000, 54000)、[54000, 72000)、[72000, 90000)、[90000, 105015) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [dcf4903cf820a6ececec76e0.repaired.txt](../texts/08/08ba9c382fbfd742a083d45e7fd5a18f01ee073550ee539648f65b3d715a570e.md)
- [cfc4822cb61feb862b71a970.repaired.txt](../texts/09/09fd84d977b48789fc5d999e53850ce9f47bcc3ab6d4c9dea98beec2789ced05.md)
- [6056f992e767c39ad9a40ea0.repaired.txt](../texts/47/4772e0308948403e80aaa2a60c337fe0f883d5b913349b3fb6de0caed590f2b5.md)
- [82770fe938777ff954486c1f.repaired.txt](../texts/69/69360fd1e15efb427fa43948234a3fb516ec1b53db2154c1bbf3e0df36f8bfea.md)
- [a5e3fda0119e434ac3f7be2a.repaired.txt](../texts/73/73651e2cea3c162cd01574e24668a30ab4c3dc985e07d51a9d7038c0523b0db1.md)
- [e476ae90f4f59f64cc833e3c.repaired.txt](../texts/84/84f6529b6c0dc3241437416539e08f2b3d55922c658c9164b151587fc29dedc4.md)

## 原研究概要与相关链接

- [11-open-source-projects/03-navigation-environment/recastnavigation.md](../../ai-reference/11-open-source-projects/03-navigation-environment/recastnavigation.md)
- [https://github.com/recastnavigation/recastnavigation](https://github.com/recastnavigation/recastnavigation)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp#L973-L1018](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp#L973-L1018)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Include/DetourCrowd.h](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Include/DetourCrowd.h)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp#L1046-L1110](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp#L1046-L1110)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp#L439-L462](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp#L439-L462)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp#L77-L134](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp#L77-L134)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp#L583-L637](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourTileCache/Source/DetourTileCache.cpp#L583-L637)
- [https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/License.txt](https://github.com/recastnavigation/recastnavigation/blob/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/License.txt)
- [https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1](https://github.com/recastnavigation/recastnavigation/commit/9f4ce64458dfae86e1239c525ddc219c4e9e06f1)
- [https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/Detour/Source/DetourNavMeshQuery.cpp)
- [https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Include/DetourCrowd.h](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Include/DetourCrowd.h)
- [https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourCrowd.cpp)
- [https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathCorridor.cpp)
- [https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp](https://raw.githubusercontent.com/recastnavigation/recastnavigation/9f4ce64458dfae86e1239c525ddc219c4e9e06f1/DetourCrowd/Source/DetourPathQueue.cpp)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
