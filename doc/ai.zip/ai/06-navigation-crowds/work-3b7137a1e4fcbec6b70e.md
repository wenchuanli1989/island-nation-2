# Add navigation mesh source geometry parsers and callbacks

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://api.github.com/repos/godotengine/godot/pulls/90876`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：smix8（Godot 导航贡献者及 PR 作者）；TokisanGames（Terrain3D 参与者）；akien-mga（合并）。
- 原目录日期：2024-04-18（沿用已有记录）。
- 主要来源：[https://api.github.com/repos/godotengine/godot/pulls/90876](https://api.github.com/repos/godotengine/godot/pulls/90876)

## 概要与项目参考

Domino建议：若以后有局部地形/室内导航，可定义各领域几何供给接口，导航模块独占发布派生结构；领域规则不直接修改寻路缓存。
当前路网Floyd不需为此迁移navmesh；先保留更新通知、定义所有者与缓存失效，能力扩展须有实际场景。

## 已有机制分析

PR正文：注册source geometry parser及Callable，parse_source_geometry_data遍历每个node时调用，参数分别给导航网格烘焙设置、待添加的source geometry和当前node。
2D/3D示例：插件只往source geometry添加自定义几何，不直接编辑navigation mesh；禁用插件/不需要时free parser RID并清句柄。

## 后续行为与玩法启发

玩家搭障碍、锁门、挖洞、犯罪潜入或追逐可由局部几何源影响真实可达性；构建几何仍不代表已观察到障碍或机构许可。

## 适用范围与局限

每个被解析node都会回调，成本随节点与注册parser数量增长；无烘焙耗时、局部增量或万人NPC基准。

Domino应批量处理变化区并共享派生导航，不能因每NPC感知变化重烘全图。

插件贡献source数据、统一bake/publish的边界便于扩展；明确parser句柄所有权和禁用释放。

回调捕获对象寿命/在途解析停止未在此描述，需要具体实现保证，free RID不可视为已完成所有工作。

直接改navigation mesh绕过统一烘焙设置/发布，会让派生状态与源数据脱节。

插件停用仍留parser或回调引用失效可有残留调用，正文未提供停止确认。

Terrain3D/VoxelTool更顺畅的动机不证明所有Navmesh规模或动态图重建适用。

完整读3484字符PR描述和GDScript示例，未读补丁、讨论、关联proposal或Godot实现/图片。

路径绑定PR90876及作者变更意图，不从尾部4.3文本推出已合并/当前API可用；未联网或运行。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [c5471568610ce8fe7cc62fb9.txt](../texts/4c/4c6b041889420a153882c1e93092af5f5564246786cbdc45ea8f6585bb5a42a3.md) | 讨论正文/已载入评论 | [0, 3484) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/01-dynamic-navmesh.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/01-dynamic-navmesh.md)
- [https://api.github.com/repos/godotengine/godot/pulls/90876](https://api.github.com/repos/godotengine/godot/pulls/90876)
- [https://github.com/godotengine/godot/pull/90876](https://github.com/godotengine/godot/pull/90876)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
