# Advanced 1. Incremental Path Planning

- 分类：导航、人群、交通与空间协调。
- 资料标识：`youtube:_4u9W1xOuts`。
- 已有内容：字幕/转录文本。
- 原目录作者：Joe Leavitt, Ben Ayton, Jess Noss, Erlend Harbitz, Jake Barnwell, Sam Pinto。
- 原目录日期：2016（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=_4u9W1xOuts](https://www.youtube.com/watch?v=_4u9W1xOuts)

## 概要与项目参考

Domino 建议：用于评估道路封锁/恢复后按受影响边局部修复路线的升级路线；把世界图变化与 NPC 已观察到的变化分开。当前 Floyd 全对路线与 D* Lite 单目标重复搜索不同，不能从讲义直接推出应替换现有实现。

## 已有机制分析

原文：图边变化后保留既有 g 值及优先队列，以 rhs=后继 g+边权的最小值识别局部不一致；只在优先扩展时修改 g，合并多条边导致的重复传播。
原文：D* Lite 从固定目标逆向搜索，使移动起点不要求全量改写 cost-to-go；用 key modifier 比较旧队列与新起点启发值。g>rhs 时下降修复，g<rhs 时先设无穷再重新松弛。
原文：达到起点一致且无更低 key 后即可停止，不必清空队列；演示障碍发现、追随移动、虚拟目标遍历与 inflated heuristic anytime 修复。

## 后续行为与玩法启发

Road blockades, pursuit/escape and smuggling can change true topology or the NPC believed graph separately. A guard report may update a belief, while a physically closed door changes executor feasibility; route planning must preserve this distinction.

Greedy unexplored-node routing can support bounded patrol/search investigations, but finding a path does not create a witness, catch a suspect or settle stolen assets.

建议：玩家设路障、开启门、破坏桥梁、追捕或营救会改变物理路线；NPC只根据已观察的变化调整自己的计划。

制度禁行、主观危险权重与物理不可达分开，允许罪犯选择可行但违法道路；路径权重不当距离/ETA。

建议：封锁、追捕、潜入后因局部观察重新绕路，玩家移除障碍或给出路线消息可改变后续行动。

建议：调查者探索未访问区域可用虚拟目标候选思路，但不得把规划过某区域视为实际到访或目击。

## 适用范围与局限

State reuse saves expansions only when changes affect a limited portion of relevant search. A dense central blockage or changes near the backward search goal can invalidate extensive state; A* restart can be cheaper.

10000 independent queues and g/rhs copies cost O(NV); group identical destination/topology/knowledge cases, cap cached searches and repair work per scheduling slice. Lecture gives no 10000-NPC benchmark.

每个不同目标的D*运行态需要g/rhs/队列，10000 NPC逐人全图缓存可能O(NV)内存；优先局部图、目的地共享缓存和有限活跃请求。

来源说每次修复中节点至多两次扩展；小图、广泛改变或破坏搜索根附近大量旧值时，增量额外维护可能输给重启A*；未提供万人实测。

原文并无 10000 NPC 测量；每个移动体独立 g/rhs/队列可达 O(NPC×图节点) 内存。

增量收益依赖保留结果仍有用、变化局部且能少扩展节点；大量全图变化可使失效修复比新 A* 更昂贵。

建议：先按共享目标/图版本评估缓存与局部查询，并对同时封路的重规划设分批预算；不能无证据共用角色不同知识的搜索状态。

Separate graph updates, rhs refresh, queue membership, stale-key comparison and movement selection. Stable node IDs/versioning are needed across topology edits; preserve directed predecessor/successor semantics.

Fake goal and anytime variants require their own correctness contracts and are optional future tools; do not expand first implementation scope based on a lecture example.

需要正确维护有向前驱/后继、非负成本、启发式与key modifier及失效节点。普通C可独立实现，不要求迁移整个规划器。

讲者曾混淆over/underconsistent并在38:41之后纠正；实现须据算法正文核验，不能复制口误。

稳定边/节点 ID、正反邻接与变化通知是维护前提；需记录搜索所属图版本及目标，否则旧 key/g 可能污染新请求。

使用边权无穷代表不可通行方便复用结构；可通行性、距离、时间和风险成本须分清。

A five-node example updates almost every node and gains little; topology changes affecting the entire graph defeat reuse. Exploration is greedy rather than an optimal traveling-salesman tour.

Graph-optimal paths may be far from geometry-optimal under cell decomposition. Nonholonomic vehicles require dynamics-aware connectors; straight graph edges alone can be physically invalid.

Transcription confuses stock/start and over/underconsistency; speakers correct earlier labels around 38:41, so the later explicit conditions are stronger evidence than an isolated sentence.

若全图阻断变化影响大量最短路，保留旧状态未必省时；每人目标频繁变更降低缓存价值。

虚拟目标逐个访问只是贪心近邻，不是全局TSP最优；离散图路线依赖车辆尺寸/运动约束建模，不证明任意角色可穿过。

讲义自身的前向搜索例子：近搜索根的变化使大量旧路径失效，先撤销再重搜可能比 A* 从头开始更差；逆向 D* Lite 的根在目标，不能照搬前向位置判断。

五节点例子经常需要全更新；增量算法额外 bookkeeping 并不保证任何小图获益。

cell decomposition 只保证其离散图上的最优，几何路径可明显不最优；2D polygon/holonomic 假设不能覆盖车辆运动。

Complete 84207-character transcript carrier read, ending applause at 1:22:39; not video/slides viewed or code executed. No first-party benchmark measurements recovered.

The actual D* Lite formula/termination proof is only partially spoken; formal implementation needs local primary paper or code if this candidate advances.

完整读本地1:22:39字幕文字，未观看对应演示图或性能复现；字幕含INAUDIBLE和明显转写错词。

MIT学生讲义是算法解释载体；数学正确性与复杂度采用需与D* Lite原论文归并核实，不能算不同算法作品。

完整读到 01:22:43 的字幕载体，不等于视频/幻灯片图示已观看。

多处自动转写或口头术语误用及讲者现场纠正；实施需核对算法原论文的 key/终止条件。

仅有教学机制与例子，无 Domino 或万级运行性能证据。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [browser-export.txt](../texts/1b/1beab1af3daac7d04996ec502ba76985bca06b28c1579bef3afc6d96046f32da.md) | 字幕/转录文本 | [0, 11000)、[11000, 22000)、[22000, 33000)、[33000, 44000)、[44000, 55000)、[55000, 66000)、[66000, 77000)、[77000, 84295) |
| [d7ae767715614c16e8dfa31a.txt](../texts/82/82106366827ad0bbd3466d2b765d7ea2a75f0a31efda9baae1f0cc1cf2b64b1e.md) | 字幕/转录文本 | [0, 11000)、[11000, 22000)、[22000, 33000)、[33000, 44000)、[44000, 55000)、[55000, 66000)、[66000, 77000)、[77000, 88000)、[88000, 99000)、[99000, 110000)、[110000, 121731) |
| [transcript.txt](../texts/be/bea68db22e05cb2cee1a6f4ee3627c40507f51570d29a9c136040b1e0cffb702.md) | 字幕/转录文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 46000)、[46000, 57500)、[57500, 69000)、[69000, 80500)、[80500, 84207) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/05-dynamic-routes-cache.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/05-dynamic-routes-cache.md)
- [https://glasp.co/youtube/p/advanced-1-incremental-path-planning](https://glasp.co/youtube/p/advanced-1-incremental-path-planning)
- [https://ocw.mit.edu/courses/16-412j-cognitive-robotics-spring-2016/ddbe85085fea5e40af2be202de0a8569_4u9W1xOuts.vtt](https://ocw.mit.edu/courses/16-412j-cognitive-robotics-spring-2016/ddbe85085fea5e40af2be202de0a8569_4u9W1xOuts.vtt)
- [https://ocw.mit.edu/courses/16-412j-cognitive-robotics-spring-2016/resources/advanced-lecture-1/](https://ocw.mit.edu/courses/16-412j-cognitive-robotics-spring-2016/resources/advanced-lecture-1/)
- [https://www.youtube.com/watch?v=_4u9W1xOuts](https://www.youtube.com/watch?v=_4u9W1xOuts)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
