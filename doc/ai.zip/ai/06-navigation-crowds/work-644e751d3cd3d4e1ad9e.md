# Vision Zones and Object Identification Certainty — Steve Rabin

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Steve Rabin。
- 原目录日期：2015（沿用已有记录）。
- 主要来源：[https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf](https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf)

## 概要与项目参考

Domino 推论：未来感知层只产生带来源、时间与识别状态的观察事件；效用/任务决定调查，执行器提交动作。共享视觉定义与有限活跃目标置信状态可以支撑社会犯罪证据，而无需NPC全知。

## 已有机制分析

源事实：按距离、FOV、raycast逐级过滤视野候选，便宜条件先执行；布尔阈值会在边界形成不自然的突然识别。
源事实：视觉区域产生0..1 identification certainty，表示识别程度，不能直接作为每帧随机发现概率；区域随距离先变宽再变窄，动作与伪装可修改识别。
源事实：部分识别可驱动转头、眯眼、搜索和询问，而类型识别、身份识别及世界真相不同；目标明确时头部转动又改变视区。
作者案例/建议：TLOU观察sweet spot约1—2秒，运动/伪装加减约0.3是可调示例；组合时间与确定度是作者建议，不是TLOU已实现机制证明。

## 后续行为与玩法启发

玩家潜行、伪装、缓慢移动和遮挡可令NPC察觉但未识别身份；后续询问、追踪和证人报告产生可利用的不确定性。

目击犯罪必须基于实际可见事件；报警、认定身份和处罚是后续独立阶段，部分识别不自动等于确定证据。

## 适用范围与局限

没有10000NPC射线预算。必须先按空间/距离/FOV产生有限局部候选，再对活跃可见目标做raycast和置信更新；避免全人物两两检查与全历史confidence。低频远处更新不能捏造目击。

视觉区、识别类型、身份置信与观察时刻独立配置，帮助扩展运动/光线/伪装修饰。显式检测进度或动画反馈让玩家理解状态；每帧概率导致FPS依赖，应按明确现实时间语义更新。

把0..1当每帧伯努利概率将使长时间暴露几乎必然检测，且不同帧率行为不同。

可见目标不一定被正确认出，缓存身份不能绕过遮挡变化或证据来源。

单章感知机制没有调查、法律、队伍协作或资源提交完整实现。

全文9337字符章节提取文本；没有观看图表、审源码或复現TLOU。

修饰数值和观察秒数是示例；万级CPU成本需要项目实现后测量。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [07821c3dab5fc5bc79ae4f7a.txt](../texts/e3/e3294e94aba44f1ea540c59fc28ce38d9f81a1dd58cf531dd9fbdabdf397acbb.md) | 论文/讲义提取文本 | [0, 9337) |

## 原研究概要与相关链接

- [03-world-perception-navigation/02-perception-attention.md](../../ai-reference/03-world-perception-navigation/02-perception-attention.md)
- [https://gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf](https://gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf)
- [https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf](https://www.gameaipro.com/GameAIPro2/GameAIPro2_Chapter04_Vision_Zones_and_Object_Identification_Certainty.pdf)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
