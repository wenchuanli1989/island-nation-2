# Feature: Allow to keep an action performing even if the target became invalid at some point #285

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/crashkonijn/goap/issues/285`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：Racines（GOAP 使用者、功能提议者）。
- 原目录日期：2024-10-25（沿用已有记录）。
- 主要来源：[https://github.com/crashkonijn/GOAP/issues/285](https://github.com/crashkonijn/GOAP/issues/285)

## 概要与项目参考

Compact genuine failure/feature boundary for task targets, effect commit and continuation; worthwhile nomination as supporting executor contract evidence.

## 已有机制分析

source_facts:
Reporter collecting an item destroys it during collect animation but wants the current action to continue until animation ends. Request is to disable internal target checks in GoapActionBase; proposed workaround forces ITarget.IsValid from BeforePerform to End and resends target through sensor.

Maintainer comment says feature released in 3.0.21-beta. No implementation, precise new API or runtime result is included.

domino_recommendations:
Separate target validity required before effects from after-effect continuation. A successfully collected/despawned item can remain represented by stable task outcome while animation/cleanup completes.

Do not globally force target validity: an item destroyed by another actor before collection must fail/reselect; an already committed own collection must not refund/recollect on target disappearance.

Expose target ID, phase and commit/result state so cancellation and load recovery know whether the action still owns resources or only presentation/cleanup remains.

## 后续行为与玩法启发

crime:
Stealing removes the original world item; disappearance after committed theft must not invalidate the carrier cleanup or cause a second transfer.

deception_investigation:
Destroying evidence before search commit differs from evidence consumed/recorded by the investigator.

cooperation_player:
Player/partner takes or destroys a shared target mid-action; distinguish lost race from self-completion and release occupation once.

## 适用范围与局限

One small feature report, no 10000 measurements. Phase-based validation can be O(1), but global sensor re-sends or forced-valid targets can create stale work.

Target lifetime, execution lifetime and animation lifetime need named phases; broad skip-validation flags hide critical invariants.

Feature-release comment is a maintainer claim; exact beta change was not inspected.

Always aborting on target disappearance can cut off cleanup after own successful effect.

Always allowing invalid targets can commit theft/collection of an item already lost to another actor.

Presentation completion is not another resource commit.

Entire issue/carrier and one maintainer comment read; Discord thread, release diff, implementation and runtime not inspected.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [579a8bda5b3f127e0d3c1ee3.repaired.txt](../texts/62/6200fd82654ffb1ca3e85a28843336d2af6d2ab9d5e4ea94c1514c9102aa2beb.md) | 讨论正文/已载入评论 | [0, 1686) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/06-affordances-place-selection.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/06-affordances-place-selection.md)
- [https://github.com/crashkonijn/GOAP/issues/285](https://github.com/crashkonijn/GOAP/issues/285)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
