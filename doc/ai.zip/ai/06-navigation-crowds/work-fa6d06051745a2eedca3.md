# Unity Sims-style AI tutorial — BaseNavigation.cs

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-repository-bundle:gamedeveducation/unitytutorial_simsstyleai@1b55006454e2de884b959dbce5caa4efa08a96d0`。
- 已有内容：源码/工程文本。
- 主要来源：[https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/BaseNavigation.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/BaseNavigation.cs)

## 概要与项目参考

recommendation: Domino移动行为保留请求/等待/跟随/失败/实际到达状态，将目标和路径版本作为任务参数；实际到达触发后续活动，停止确认后释放路径/占用。
integration_boundary: 当前nav图/Floyd提供路线而非完整移动执行；路径权重不得直接当距离或ETA，此基类也不提供它们。

## 已有机制分析

mechanism: 寻路与移动完成边界
process: 发起请求进入Finding，路径返回进入Following，实际到达回调才Idle；IsAtDestination额外检查当前位置到Destination阈值。
mechanism: 目标去重
process: 忽略一定阈值内的重复目标减少不必要寻路请求；调度与物理跟随分不同tick。

## 后续行为与玩法启发

玩家封路/移除目标导致计划中的移动失败，犯罪逃跑、调查到场和交易交付必须据实际到达继续。

本文件只有nav适配，没有感知、门锁、区域权限或角色协作机制。

source_facts:
随机interaction没有需求、关系、犯罪/调查/欺骗或多人同意机制。

domino_recommendations:
吃饭、合作加工、盗窃等共享有限定义，但个人意图与资格不同；CanPerform只能检查实际可执行条件，违法性不是通用硬过滤。

玩家移除对象/占用服务/改变路线时给明确失败，从真实位置改排；共同活动需要另一个人接受且重检参与者，而非随机触发。

source_fact:
文件只有移动与debug，无犯罪/玩家后果。

domino_recommendation:
玩家封路造成NoPath，NPC搜查/逃跑/送货应有明确失败或替代；到附近不等于跨门/权限有效。

可用于店铺、工作、社交或非法夺取的共用移动/服务骨架；能力与意愿、合法许可和真实资产效果须分离，当前样例没有犯罪/调查/欺骗规则。

玩家使导航失败、服务取消或对象销毁时应释放占用并重评；多参与者协作不能由随机选单一interaction推定接受。

犯罪追捕/逃逸可改变目标并取消旧回调；位置满足不等于抓获/逃脱。

调查/欺骗要求主观目的地与真实网格查询区分，源码不提供感知/知识。

协作/玩家干预：封路导致路径失败应返回明确原因，邀请取消释放活动占用。

玩家封路/逃跑/改变目标会使追捕/护送/配送重寻路；失败或中断产生可解释后续而非到期直接成功。

室内潜入可根据局部区域目标而非整楼等价，但本基类只有平面位置跟随。

## 适用范围与局限

按NPC每tick检查UnityAgent并DebugDraw，未给10k成本；Domino可到期/道路版本事件唤醒活跃移动批次，不复制MonoBehaviour体系。

每帧O(N)调用，即使多数人在移动/等待也被遍历。随机索引O(1)却可能不断采到不可用对象，不能替代可用索引/有限候选。无容量、路径/animation/回调内存测量，不能证万人；Unity MonoBehaviour对象分散与Domino连续数组不同。

source_claim:
无性能测量。

domino_assessment:
每NPC Update/FixedUpdate加transform查询为O(N)，具体寻路成本未知；万级需到期/位置变化唤醒和导航请求预算，最大速度/阈值不能给吞吐保证。

全体MonoBehaviour每帧Update，即使只2秒选一次也有全员轮询，RegisteredObjects全局随机不控制距离/可达；万人需到期事件与局部候选。

无预算/同步到期分散/性能数据，且失败再选成本与锁泄漏可能累积。

小wrapper无算法成本信息，NavMesh查询/逐帧所有agent检查不能直接支持万人。

每帧/FixedUpdate均调用，需要万人时只推进活跃移动或到期事件；去重不等于全图寻路成本已解决。

文件没有寻路算法、批处理、缓存或性能数据。

BaseNavigation状态迁移/停止通知不在本文件，接口契约需关联源码才能判断。

RequestPath忽略SetDestination结果并总return true，following若hasPath丢失没有显式失败分支；不应直接作为可靠生命周期。

把请求、获得占用、行程、有效执行、结束结果清楚分开，避免散落清理；共享interaction定义不持某人可变进度。稳定ID+generation解决数组移动/晚callback，C23同步规则另设计。

回调接口简洁，但没有请求ID、取消确认、部分进度或持久化。源码仅平面XZ距离，需保持室内层级/楼层空间语义。

将共享定义和单人当前状态分开方向有用；公共结束/取消/失败都应统一释放，回调携实例ID/版本以隔离旧通知。

导航抽象隔离API依赖可复用；C23将状态与ID集中，不保留Unity组件对象。

路径算法可由子类替换，公共状态callback简明；应补取消/挂起/恢复和旧请求版本。

持久化目标与真实进度，不保存Unity Transform/裸pointer或运行callback。

ResetPath不等于任务已取消/停止确认/占用释放；必须由任务执行状态合并处理。

remainingDistance不是既定ETA，且近目标门槛不能证明业务交付达成。

导航失败后锁未释放可造成幽灵占用，源码直接可见。

RegisteredObjects/Interactions空时仍取随机index；相关管理器是否保证非空本文件未知。

callback不验证interaction==当前/任务版本，迟到回调可能清掉后来活动或重复unlock。

CanPerform与Lock之间是否原子、行程途中对象被删/容量改变的结果、本文件未处理。

SetDestination近当前位置时返回true而未更新Destination/State，也未明确停止旧路径；调用方不能把true当已经到达新目标。

同目标近似合并可保留旧请求，若版本/障碍已变化需要业务判断。

Idle仍可能不在目标，IsAtDestination同时要求距离；失败状态不能等同终结所有资源。

SetDestination=false路径设置CurrentInteraction=null但无UnlockInteraction，会残留已锁服务。

对象/交互列表为空会访问失败；没有到达途中CanPerform复核、取消回调或超时，perform未完成可永久等待。

OnInteractionFinished不核与当前interaction一致，旧回调可清新任务；done通知没有成功/失败参数。

忽略SetDestination返回值却总return true，不能代表请求已被接受。

ResetPath无停止确认/进度保存，路径状态complete并不意味着已到场；原文remainingDistance语义不迁移到DominoFloyd权重。

SetDestination在已接近newDestination时直接true，不更新Destination/状态或停止旧Follow；可能继续旧路且IsAtDestination仍用旧目标。

旧路径异步返回未校验版本，可能覆盖新请求。

抽象StopMovement无停止完成状态，不能假设取消已完成。

只忽略y轴可能忽略上下楼/垂直可达性，不能推广室内空间等价。

全文仅nav适配文件，未读BaseNavigation或UnityNavMesh内部；静态失败分析未经运行。

完整读2037字符固定commit源码，只审SimpleAI.cs；未读Navigation/Interaction/Manager内部，不运行Unity。

具体锁含义、回调同步/重入约束由依赖决定，本文件只能证明自身控制流。

完整BaseNavigation文件，但整仓fragment_read；派生导航、停止和pathfinding实现未读。

未运行，不裁定上述边界在整个教程工程中已造成bug。

完整单文件原始源码，未读BaseInteraction/BaseNavigation/SmartObjectManager依赖或观看教学视频，不是完整Sims系统。

完整单文件1950字符，不是Sims教程全仓；未读BaseNavigation，也无运行/性能证据。

完整单基类源码已读；具体寻路/停止/跟随子类和Unity运行未读未验证。

可借状态边界，不能当完整导航或万人实现。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [3d11902a4e1e89186ddecdd6.repaired.txt](../texts/2f/2f106e0bc7354a42cb656d0622f8d3b153b60b48597ebddcbeaf7352b827c58e.md) | 源码/工程文本 | [0, 1950) |
| [7f986ffc2f9ff016c71015d8.txt](../texts/4f/4f446ceaa96e51bea278c7e6f01af1268c0bd3d920f83b75fa78043cd83d7ebc.md) | 源码/工程文本 | [0, 1524) |
| [508f01d48f052d2d97a4d0eb.repaired.txt](../texts/51/51059d0f89dfd63ab1db1a5cae978d12893163be8d7c3a3434227187df68606c.md) | 源码/工程文本 | [0, 2596) |
| [8bad6371f1174277a7eca12d.txt](../texts/9b/9be8112b5ed7c6e14fecfd965075026758dae68f94e8b5545bffd0de9c88a0dd.md) | 源码/工程文本 | [0, 2037) |
| [08cc2e446d4205fbb96d98b8.repaired.txt](../texts/c3/c3070771b238b48c83c515f8fe84536b4df407bc250c72361a2d29e56c55197c.md) | 源码/工程文本 | [0, 3172) |
| [3d8c53ab0767ec0d0f8efd04.txt](../texts/e6/e6479622079595f70478c5b12dd4831542ed8e7ea7fdc4ee718c194988527a40.md) | 源码/工程文本 | [0, 2604) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [7f986ffc2f9ff016c71015d8.repaired.txt](../texts/03/0379330649bca24ef1deeecff8e1e9f4793529b9d6b2e303696bc04c8fa0dad4.md)
- [3d8c53ab0767ec0d0f8efd04.repaired.txt](../texts/85/8575b510825c03db093b8b0ef2e68dc63c7f82744055cf04e3427f9ff7c4ca5d.md)
- [8bad6371f1174277a7eca12d.repaired.txt](../texts/dc/dcc4fd5e68cb3181e0fd1de67ce100d3ac35595f63239e2e03ab1b77dc2f7606.md)

## 原研究概要与相关链接

- [https://github.com/GameDevEducation/UnityTutorial_SimsStyleAI/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/Systems/SmartObjects/Scripts/SimpleAI.cs](https://github.com/GameDevEducation/UnityTutorial_SimsStyleAI/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/Systems/SmartObjects/Scripts/SimpleAI.cs)
- [https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/BaseNavigation.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/BaseNavigation.cs)
- [https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/Navigation_UnityNavMesh.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/Navigation_UnityNavMesh.cs)
- [https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/Systems/SmartObjects/Scripts/SimpleAI.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/Systems/SmartObjects/Scripts/SimpleAI.cs)
- [https://raw.githubusercontent.com/GameDevEducation/UnityTutorial_SimsStyleAI/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/Navigation_UnityNavMesh.cs](https://raw.githubusercontent.com/GameDevEducation/UnityTutorial_SimsStyleAI/1b55006454e2de884b959dbce5caa4efa08a96d0/Assets/AI/Scripts/Navigation/Navigation_UnityNavMesh.cs)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
