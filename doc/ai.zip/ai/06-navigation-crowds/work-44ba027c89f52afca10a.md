# Living in Procedural Worlds: Creature Movement and Spawning in Nightingale

- 分类：导航、人群、交通与空间协调。
- 资料标识：`youtube:Dy6K6sM3teE`。
- 已有内容：字幕/转录文本。
- 原目录作者：Arta Seify; Nathan R. Sturtevant。
- 原目录日期：2023-03-31（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=Dy6K6sM3teE](https://www.youtube.com/watch?v=Dy6K6sM3teE)

## 概要与项目参考

A strong navigation-to-gameplay bridge: efficient exact candidate queries, dynamic terrain preferences, reachability-based alternatives and local update boundaries can support trade/logistics and interactive pursuit without converting the whole project to navmesh.







## 已有机制分析

source_fact: 每个 Recast tile 内将相邻且同地形类型的 polygon 合为抽象节点，再跨 tile 接边；起终点映射抽象图，搜索后返回 polygon strip，仅在 strip 内细化。地形进入/离开/驻留权重可按 creature 动态指定。
author_claim: 示例约 200000 polygon → 50000 节点，其中高坡孤立节点约占三分之一，其他区域压缩更多；未提供本地基准数据。
source_fact: closest creature 查询把多个目标放入 open list，从目标反向 A* 到查询者；必须完成搜索后沿父链确认最便宜目标，而非以直线最近或 partial path 推断。
source_fact: 连通标签初始 BFS，tile 改变后取修复节点的邻居两两做双向搜索，连接则合并标签，拆分则从先耗尽的小组件重标；标签支持屋顶不可达、破门行为及按 island 面积筛出生点。
source_fact: 少量重要 persistent creatures 长距离实际移动；大多数由激活/停用半径动态生成销毁。POI 用 k-means++ 初始化、3D 距离分簇，每簇随机一个 spawn 点，清空后簇内换点；K 通过试玩调密度，玩家 realm cards 可减 K。

## 后续行为与玩法启发

crime:
Road/terrain preferences and closed-door connectivity enable ambushes, route blocking and break-in alternatives; physical access remains separate from legal permission.

deception_investigation:
Nearest reachable witness or investigator should use route accessibility, not Euclidean distance; this is an inferred extension, not an implemented Nightingale investigation system.

cooperation:
Shared POIs and accessible roads support rendezvous and logistics; role acceptance and occupancy need separate executor contracts.

player_interaction:
Talk explicitly shows doors built/destroyed, inaccessible player prompting door destruction, invisible creature travel corridors players can learn, and realm cards changing encounter density.

crime:
隐蔽/巡逻/危险地形可作主观路线成本；破门必须由执行者实际消耗工具/损坏门并触发可被目击事件。

deception_investigation:
调查者可按已知路线/区域搜目标；知道连通不等于知道目标在哪里，本讲座没有信念模型。

cooperation:
搭桥、开门、伙伴选择基于实际可达；玩家可邀请/改变通路产生因果链。

player_interaction:
玩家关门阻断追击、修建/摧毁坡道、改变生物密度卡与无形道路偏好形成可学的遭遇位置。

## 适用范围与局限

No 10000 persistent-agent throughput claim. Speakers explicitly say persistent creatures are expensive and most wildlife uses dynamic spawning/short routes.

Tile size trades graph compression against rebuild cost; merge relabeling can touch a whole component and neighbor pairing is quadratic in local boundary count. Bidirectional failure is small only when an endpoint has a small disconnected component.

Example reduction is graph node count, not an end-to-end 4x speed guarantee. Localization caches trade memory for lookup time; refined paths and many agents still cost CPU.

K-means costs O(iterations*POIs*K), does not guarantee uniform density, and Euclidean clusters can straddle connectivity barriers. Suitable as amortized generation/indexing, not each NPC each tick.

示例是地形节点数，不是 10000 NPC 同时规划吞吐。末尾 Q&A 明说未广泛 benchmark、部分长途路径仍未完成预算。

局部边界候选两两连通检测为 O(k²) 查询；拆分或大组件合并仍可能扫描远区，不能宣称每次恒定成本。

tile 尺寸在构建/压缩与重建成本间权衡，低层映射缓存占内存；需共享静态定义和批次调度。

k-means 约 O(POI×K×iterations)，适合世界生成/有限更新；不得对每 NPC 每帧运行。

动态生成销毁可用于无持续因果的环境 wildlife；不能替换 Domino 有资产、犯罪、目击、契约历史的持久人物。

Keep mapping/revision validation and abstract-path/refined-path responsibilities separate; local graph repair must notify dependents.

Speakers choose tiles and K through profiling and playtests and acknowledge incomplete benchmarking and occasional unfinished paths; adopt only after the concrete Domino workload justifies the representation.

先实际 profile 关键场景；讲者强调完美寻路不能掩盖 physics 崩坏，并由少数专责程序维护复杂 nav。

本阶段可提取多目标查询与明确 complete/partial/unreachable 结果；无需直接迁移 Recast/UE 或建立通用 nav 栈。

Straight-line nearest creature can be on an unreachable roof or beyond costly water; partial route search cannot establish the best reachable target.

A single world-wide merged terrain node forces broad repairs when small edits occur.

Erasing unseen citizens as wildlife spawns would destroy persistent crime, debt, witness and cooperation causality.

Teleporting trapped wildlife is described as fallback; it cannot silently move persistent citizens across custody or barriers.

直线最近目标在屋顶/水对岸不可达；多个独立 A* 重复工作。

closed door 分割 nav 后若只跟 partial path，NPC 停门前；需要行为层选择真实破门或放弃。

以 teleport stuck creature 修复行为会绕过 Domino 真实位置、占用和犯罪/目击因果，不能原样采用。

出生点均匀随机抽 POI 会受 POI 密度偏差影响；欧氏 k-means 在不连通岛屿上也不能保证可达/面积均匀。

Complete 0:01-1:02:05 transcript read; video images, slides, demos and full code were not inspected. ASR corrupts some terms/names.

Claims about behavior and graph reduction are developer statements in a prerelease talk, not our runtime evidence.

No economic settlement, social memory, task restoration or persistent citizen LOD implementation appears in this carrier.

全读 0:01 至 1:02:05 自动英文字幕；未观看视频/检查图像、未取得论文/实现代码。

自动字幕对名字、polygon/graph 等有误识别；机制取连续上下文，不把口误当正式 API。

2019 关联论文及 tile repair 实际代码未在本材料内，性能为讲者示例与经验。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [transcript.txt](../texts/28/28bb5e548fade023fcb3d0872188aac43684c98a4e372adba90e0e84c88a5d6d.md) | 字幕/转录文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 46000)、[46000, 57500)、[57500, 68591) |
| [browser-export.txt](../texts/30/30f2f45aa5b4318bc126e5c1340c2b5fe75e9d40f275e968fd93ff57ed019214.md) | 字幕/转录文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 48000)、[48000, 60000)、[60000, 68670) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/04-hierarchical-pathfinding.md)
- [https://sites.google.com/ualberta.ca/ai-seminar/past-seminars/2023](https://sites.google.com/ualberta.ca/ai-seminar/past-seminars/2023)
- [https://www.gdcvault.com/play/1028813/AI-Summit-Living-in-Procedural](https://www.gdcvault.com/play/1028813/AI-Summit-Living-in-Procedural)
- [https://www.movingai.com/gdc23/](https://www.movingai.com/gdc23/)
- [https://www.youtube.com/watch?v=Dy6K6sM3teE](https://www.youtube.com/watch?v=Dy6K6sM3teE)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
