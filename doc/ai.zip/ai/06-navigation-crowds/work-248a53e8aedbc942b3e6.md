# EQS Node Reference: Tests

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://dev.epicgames.com/documentation/en-us/unreal-engine/eqs-node-reference-tests-in-unreal-engine`。
- 已有内容：文章/文档正文。
- 原目录作者：Epic Games。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://dev.epicgames.com/documentation/en-us/unreal-engine/eqs-node-reference-tests-in-unreal-engine](https://dev.epicgames.com/documentation/en-us/unreal-engine/eqs-node-reference-tests-in-unreal-engine)

## 概要与项目参考

source_fact: 官方测试节点说明，解释条件/分值/上下文语义，未给完整查询调度/业务执行或规模数据。
domino_recommendation: 直接契合Domino有限近期候选与只读规划；共享Test定义+个人context可局部扩展需要、承诺、服务选择和调查位置，而无需UE完整EQS/DSL或通用求解器。

## 已有机制分析







## 后续行为与玩法启发

source_fact:
Trace典型用例为敌人能否看见玩家；其余为通用空间/标签/路径候选测试。

domino_recommendation:
潜入选择盲区、抢劫选择可达资产与撤离位、调查选择可观测证物、合作选择多人都可到达服务；玩家封路/占资源/假身份或证词改变条件与主观风险。真实视线与NPC知道的情况可用不同context，检测/举报/判责/处罚必须独立状态，不能score直接制造后果。

## 适用范围与局限

source_fact:
文档未承诺查询索引或10000 NPC成本，Test种类含昂贵路径/复杂碰撞且多个context扩张评估。

domino_recommendation:
全体约O(N×I×T×C)加路径/trace成本；限制item数、context数、查询频率与预算，事件/阈值唤醒并复用只读数据。当前nav首次cache miss可O(V³)、坐标定位O(V)，不能给每候选同步重算整图或当ETA。

C中每test保留单位、filter/score目的与失败原因；共享静态ops、个人少量context无需大黑板/世界拷贝。

all/any/average语义要写在领域定义中：多人合作全员可达不同于任意一人可达，多个目击者平均距离不是证据成立。

当前host尚无感知/空间query；复用概念需新增领域实现，官方API说明不等于Domino现有能力。

relative normalization随候选集合/极值改变，远差候选加入可能改变本已有候选分值，形成不稳定选择。

把合法性设为无条件filter会使盗窃/欺骗完全消失；把物理约束只设score又可能选择不可达/无资源行为。

把cost/length/distance统一解释ETA，或把成功projection看成真实到达，会跳过运动、占用与结果。

多个context使用any-pass可能错误放行需要全参与者的协作；平均距离掩盖单人不可达。

投影bunching/高度offset错误会误判可见/重叠；需要局部空间语义，不能默认楼内所有区域等价。

已完整读12932字符官方网页正文文字，不代表完整EQS所有节点/源码/图示阅读。

没有query scheduler、claim/cancel/save或性能证据，执行/恢复合同仍需其他机制补足。

游戏犯罪/合作/认知领域映射为Domino建议，文档未实现这些玩法。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [b9c708b4eb840c2fa7f738f3.txt](../texts/51/510d95ceb040c9829c13cff5b152a0d18e67d4675be54dd2446771c436ca2cfc.md) | 文章/文档正文 | [0, 12000)、[12000, 12932) |

## 原研究概要与相关链接

- [03-world-perception-navigation/08-influence-maps.md](../../ai-reference/03-world-perception-navigation/08-influence-maps.md)
- [https://dev.epicgames.com/documentation/en-us/unreal-engine/eqs-node-reference-tests-in-unreal-engine](https://dev.epicgames.com/documentation/en-us/unreal-engine/eqs-node-reference-tests-in-unreal-engine)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
