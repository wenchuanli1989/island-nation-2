# Add a NavigationWorld2D/3D as a navmesh high performance option for large worlds #12707

- 分类：导航、人群、交通与空间协调。
- 资料标识：`saved-original-url:https://github.com/godotengine/godot-proposals/issues/12707`。
- 已有内容：文章/文档正文、讨论正文/已载入评论。
- 原目录作者：smix8（Godot 导航维护者、提案作者）。
- 原目录日期：2025-07-01（沿用已有记录）。
- 主要来源：[https://github.com/godotengine/godot-proposals/issues/12707](https://github.com/godotengine/godot-proposals/issues/12707)

## 概要与项目参考

对万级的空间候选、局部更新和粗细导航边界有直接价值；可提炼而无需迁移Godot/navmesh。源是公开提案讨论，没有完成实现与基准。

## 已有机制分析

source_facts: 提案批评单大场景/几何汤：全域解析、体素化、烘焙、动态更新和长路径成本；建议合理chunk、按需要激活、portal/waypoint高层连通。
NavigationWorld隐藏内部块数据，管理不同agent type导航图；已知所有更改才可缓存层级连通、合并多边形和减少同步精度错误。
NavigationGeometry区分static缓存和dynamic变换更新，并共享几何资源；NavigationSeed在实体周围激活有限距离navmesh；实际重活在server异步执行。
评论解释当前做法：每chunk静态源几何缓存，加动态对象到副本，合并邻块数据，用baking bounds/border重烘焙；未来World内部跳过中间流程并提供RID接口。
维护者说明avoidance独立于navmesh；async更新会让数组顺序/平局决策不同；Geometry仅处理父节点，无树爬取/嵌套支持，规模用户宜server API。
domino_recommendations: 保留现有有向道路图为粗层，只在潜入、室内追逐或阻挡有需求的场景引入局部精细图，脏块/版本失效明确。
异步局部导航结果携带图修订与执行代次，到达/服务效果须由执行者确认；稳定ID和平局规则单独定义，不能以后台更新顺序作为世界语义。

## 后续行为与玩法启发

玩家关门、封路或移动障碍触发受影响局部图更新，NPC改道/等待/取消，形成追逃或合作运输后果。

潜入/调查可按必要场景细化建筑内部，不能把同楼免移动直接推成所有房间可达；seed控制加载成本，不能决定目击/犯罪事实。

封路、移动障碍、室内警戒和不同体型/权限路径可让玩家改变逃逸、潜入与追捕；细化区域必须保留真实位置、占用/通行与目击条件。

高层路径只能表示可达方向，不能自动等同距离/ETA或让远处NPC凭空到达；犯罪/调查的现场历史不能被精细mesh未加载抹掉。

## 适用范围与局限

全域加载/烘焙不可按巨大世界直接扩展；粗层portal、局部chunk能限制更新与查询范围。

10000 NPC若各自seed/每帧重烘焙会制造重叠激活和同步峰值，需合并区域需求、限重烘焙预算和按路变化失效。

原文技术demo大小10倍主张无硬件/耗时数值，本轮未运行，不是万级证据。

单局部路径/分块更新可限制几何成本，但10000个分散NPC各自seed的激活区并集可能仍覆盖整个世界；必须给精度调度独立预算，不能称seed天然万人省成本。

提案没有硬件、实例数量、区块尺寸或CPU/内存数据；demo运行快及Horizon多类型图只是作者主张/图示，未在本轮核看。

高层缓存改进跨区路线时，动态门户失效与多agent map倍增也有成本；不按一地域一线程或每NPC一个navigation world。

内部管理所有变更简化缓存契约，但用户自由编辑内部几何会破坏假定；ID/RID、动态变换和changed-chunks接口可迁移成C句柄。

需要明确静态/动态几何所有权、边界border、agent尺寸类型和调试可视化；不应把完整node/scene架构带入扁平数组引擎。

区块/nav缓存归单一子系统所有有利于避免未通知修改；static/dynamic配置错仍能工作但性能退化，需要诊断而非隐藏兜底。

Godot节点/渲染/physics读取路径依赖该引擎，不直接移入Domino；只取粗细路网接口与共享几何机制，升级触发为确有精细局部玩法。

GPU存储网格回读、TileMap全格查询、非线程安全节点会让导航外部系统成为瓶颈；仅把求路放工作线程无效。

局部avoidance不保证路径可行；async tie-breaking不确定不意味着必须世界所有业务单线程。

portal粗路径到未加载区域只能给大方向，后续精细路不存在时需合法失败/替代，不可算到达。

作者概括All open-world games仅加载局部mesh，不是系统性证据；不能借其证明所有引擎或Domino安全降级。

异步烘焙仍可能因父节点不支持或GPU几何获取而stall，后台线程本身不消除输入瓶颈。

缓存门户与用户自由修改冲突；分块能降低局部工作但不解决世界几何无限增大或全员跨区查询。

本地讨论快照截止2025-10-21；未核实后续合入状态，不能宣称当前Godot已经支持。

未读Godot/Horizon实现或观看demo；跨引擎类比仅作者提案/个人评论。

10839字符提案主帖与网页元数据完整读完，主帖有效，页顶error是局部GitHub壳提示并非全文失败。

2025-07-01归档提案，未核上游今天是否实现、未读实现/评论/图片/演示；建议价值与实现/性能证据严格分开。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [e2e3d10d8c0ab200b7d48c55.repaired.txt](../texts/46/465673f838db21b702eff294e938bf72ca64400ae07a6f49c29ad4cc9ac761cd.md) | 讨论正文/已载入评论 | [0, 16000)、[16000, 23218) |
| [e2e3d10d8c0ab200b7d48c55.txt](../texts/6f/6fbf134b97c176d27c582db201530ab1f5d6eb62feefdc8aed3632217e6a7ec8.md) | 文章/文档正文 | [0, 10839) |

## 原研究概要与相关链接

- [12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md](../../ai-reference/12-community-2016-2026/03-navigation-perception/02-hierarchical-path-cache.md)
- [https://api.github.com/repos/godotengine/godot-proposals/issues/12707](https://api.github.com/repos/godotengine/godot-proposals/issues/12707)
- [https://github.com/godotengine/godot-proposals/issues/12707](https://github.com/godotengine/godot-proposals/issues/12707)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
