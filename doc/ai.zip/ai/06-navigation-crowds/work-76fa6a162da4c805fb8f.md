# [Help] A* Pathfinding + Unity Behavior - Agent Keeps Recalculating Path and Never Stops

- 分类：导航、人群、交通与空间协调。
- 资料标识：`reddit-post:1j8b6sp`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：bazoca33a。
- 原目录日期：unknown（沿用已有记录）。
- 主要来源：[https://www.reddit.com/r/unity/comments/1j8b6sp/](https://www.reddit.com/r/unity/comments/1j8b6sp/)

## 概要与项目参考

Domino 推论：导航完成必须被 executor 消费为终态，planner 仅在新意图/修订触发时再启动，不能把旧目标每次重新激活。
失败、取消及目标失效要按实际执行状态释放/停止，不能将 Failure 返回值当成物理运动已经停止的事实。

## 已有机制分析

原 OP 描述已到达仍重算、不停下；OnStart 设置左右 child target、isStopped=false 与 Run，OnUpdate 用 reachedDestination 停止/Idle/Success；目标位移超过 0.5 时更新 target 与 lastTargetPosition。
OnUpdate target null 直接 Failure，没有同分支停止清理；OnStart 先拿组件后检查 target，LeftRightTarget 找不到 child 可返回 null；类没有 OnEnd/OnAbort。

## 后续行为与玩法启发

追踪玩家、调查地点或逃离犯罪现场时，目标修订与到达边界可避免反复重启；本贴不提供目击、追捕制度或资产效果实现。

## 适用范围与局限

单 agent 未解决的重算问题，无 10000 性能。若每帧重算同目标可放大导航负载；阈值/目标 revision 可减少无效请求，但要由实际距离单位与采纳边界决定。

把导航运行、终态、abort 与新请求的交接用小接口明确，保持具体行为简单；不由这个故障贴引出通用 BT/DSL。

反复 OnStart 可能重新解除停止，但未读行为树/上层调用，不能确认这是 OP 的真实根因。

位移阈值会忽略小幅移动，reachedDestination 和 child target 含义取决于未读 A* 组件；并未证明修复方案。

载体含原 OP 与源码，不是仅本地分析；完整载体阅读仍不代表完整 Reddit 讨论。

缺树配置、截图、解决评论与实际重现，根因和修复没有验证。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [s3.md](../texts/69/69bf4719828ea5cfc9e3f868756cf3962cc235e1657caf0725421a32a1d14eb9.md) | 讨论正文/已载入评论 | [0, 3696) |

## 原研究概要与相关链接

- [14-three-sites-2026-10-04/02-execution/navigation-handoff/public-content/s3.md](../../ai-reference/14-three-sites-2026-10-04/02-execution/navigation-handoff/public-content/s3.md)
- [https://www.reddit.com/r/unity/comments/1j8b6sp/](https://www.reddit.com/r/unity/comments/1j8b6sp/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
