# Using Deep Reinforcement Learning to Coordinate Multi-Modal Journey Planning with Limited Transportation Capacity

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:0687a7e9929d5a36b0af6b3358cb8555a09e4dbf3806910742e647c68783acb5`。
- 已有内容：已有摘要/简介文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Lara Codeca; Vinny Cahill。
- 原目录日期：2021-10-06（沿用已有记录）。
- 主要来源：[https://www.tib-op.org/ojs/index.php/scp/article/view/89](https://www.tib-op.org/ojs/index.php/scp/article/view/89)

## 概要与项目参考

current_human_gap: 当前nav路径权重不是ETA、human无实际移动执行；摘要支持资格/容量与计划预测分开，但不能提供实现细节。
domino_recommendations: 有限旅行模板同时保存现实deadline、模式资格、服务容量/预约与实际到达；路线估价只是计划输入。
第一版不引入多agentDRL；用局部可行候选、服务预约和失败后重选先表达问题。

## 已有机制分析

可确认的高层约束是个体模式资格/车辆拥有、共享交通/停车容量与到达期限联合评价；不能据摘要重建DRL算法。

## 后续行为与玩法启发

玩家封路、改变票价/停车/班次、借出车辆能影响赶会、交接、追捕和合作集合。

犯罪逃逸/截货也可选非法模式/越权，但实际容量与物理可行仍须执行检验；这些是Domino扩展。

## 适用范围与局限

摘要说large numbers没有给10000证据；DRL训练成本/推理/交通模拟粒度未知。

多人同时独立用最短ETA可能争用同车位；应共享服务实例，不做全员两两协商。

模式资格与交通容量是可扩充冷域参数，不必扩大中央移动行为分支。

实际移动进度、拒绝、取消、预约释放/重载在此页均缺证据。

朴素旅行时长估计忽略拥堵/容量，但本页不能确认具体修复效果或数据集。

到期通知不是已到达，共同准时到达目标也不应强制人物放弃所有个人目标。

书目SUMO/RLlib等链接不等于已读软件/论文。

完整读10912字符出版页，未取得/读取链接PDF正文或同题YouTube视频；不可称完整论文。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [abd7fb9361092017a21b690c.txt](../texts/07/07118ad0db741d6b201d5b112623a8005fe429735d903259d3c7766cd6dd489c.md) | 摘要/简介 | [0, 10912) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/08-activity-transport.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/08-activity-transport.md)
- [https://doi.org/10.52825/scp.v2i.89](https://doi.org/10.52825/scp.v2i.89)
- [https://sumo.dlr.de/hugo/2021/](https://sumo.dlr.de/hugo/2021/)
- [https://www.tib-op.org/ojs/index.php/scp/article/download/89/271](https://www.tib-op.org/ojs/index.php/scp/article/download/89/271)
- [https://www.tib-op.org/ojs/index.php/scp/article/view/89](https://www.tib-op.org/ojs/index.php/scp/article/view/89)
- [https://www.youtube.com/watch?v=OF--8wm81QQ](https://www.youtube.com/watch?v=OF--8wm81QQ)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
