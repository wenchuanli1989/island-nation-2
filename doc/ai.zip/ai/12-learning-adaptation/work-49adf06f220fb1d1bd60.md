# ROMA: Multi-Agent Reinforcement Learning with Emergent Roles — project site

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://sites.google.com/view/romarl`。
- 已有内容：文章/文档正文。
- 原目录作者：Tonghan Wang; Heng Dong; Victor Lesser; Chongjie Zhang。
- 原目录日期：2020-07（沿用已有记录）。
- 主要来源：[https://sites.google.com/view/romarl](https://sites.google.com/view/romarl)

## 概要与项目参考

current_human_gap: 当前human没有队伍角色、局部协调或实际任务执行；仅凭项目页无法直接导入角色学习算法。
domino_recommendations: 可先用有限任务模板给小队按位置、装备和当前能力分配临时职责，人物保留自主需求与拒绝原因；把角色建议和组织授权区分。
若以后研究学习分工，应从局部战斗/协作回放评估，先读取论文和实现；本页只作问题与原作线索。

## 已有机制分析

局部队伍中从角色表示得到行为分工，角色可随位置/类型条件变化；本页只提供结果解释，没有角色分布、网络、奖励或训练实现。
消融把可辨认/多用途与行为专业化分开，提示分工质量并非只靠给人物固定标签。

## 后续行为与玩法启发

建议在盗窃小队设放哨、诱导、运送等临时职责，逃跑/盘查变化触发局部重分工；也可用于合作搜证或围堵。页面没有这些社会玩法。

## 适用范围与局限

展示规模主要为小队且最大列出27对30单位，与10000+持久人物不同；没有运行推理成本、模型大小或全城协调基准。

建议用局部小队、有限候选和共享规则控制成本，训练只离线研究；不依据标题对全体人物逐帧推理。

角色含义、可观察输入和实际动作接口需明确，新增职责应能由有限模板表达。

项目页图/嵌入回放缺失，不能重建训练损失或消融数值；与PMLR论文合并为同一work线索。

战斗胜率或进攻弧不证明日常经济、私有知识、欺骗和制度权限建模正确。

同质队伍位置分工可能因遮挡、不可达或目标冲突失败，不能把策略角色当作已提交任务。

完整读1922字符项目页正文；没有论文正文、网络代码、数值图或回放画面，不宣称完整论文/视频已读。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [b38716f1e76ac5758d64d4c1.txt](../texts/06/06181a5661e5d767180a3854c9d798f1a4ff016b300e685d2d2d06b53262c213.md) | 文章/文档正文 | [0, 1922) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/05-organizations-institutions/02-roles-authority.md](../../ai-reference/13-youtube-2011-2026/05-organizations-institutions/02-roles-authority.md)
- [https://arxiv.org/abs/2003.08039](https://arxiv.org/abs/2003.08039)
- [https://proceedings.mlr.press/v119/wang20f.html](https://proceedings.mlr.press/v119/wang20f.html)
- [https://proceedings.mlr.press/v119/wang20f/wang20f.pdf](https://proceedings.mlr.press/v119/wang20f/wang20f.pdf)
- [https://sites.google.com/view/romarl](https://sites.google.com/view/romarl)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
