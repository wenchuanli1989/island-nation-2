# [BUG] Agent encounters 400 at runtime

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:8e97e5df8150e33f702e597d29c6b8bf68fd9cbd0a85b93563ca772120d8de23`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：DengSSya，运行问题报告者。
- 原目录日期：2025-05-18（沿用已有记录）。
- 主要来源：[https://github.com/camel-ai/oasis/issues/113](https://github.com/camel-ai/oasis/issues/113)

## 概要与项目参考

残差与上述完整field归并；不按差异载体增加作品数量。

## 已有机制分析

OASIS QWEN例子丢tool_call_id对应tool响应后400反复出现，重新激活仍坏；新field恢复unfenced if __name__ == "__main__":，旧成if name == "main":。error string本来已在旧正文。

## 后续行为与玩法启发

只作外部推理/执行接口失败反例，不能让模型叙述自动成为犯罪/帖子实际产出。

## 适用范围与局限

残差自身不构成任何额外性能证据。

error字符串、入口标识、缩进与真实源码分别保存；本地仅静态读，不把恢复guard说成运行已修复。

不能用current repaired另一评论相同guard字面行抵消original issue code block损坏；已实际读三个具体上下文。

正文称30轮、所示代码10轮；重复错误根因未独立验证，日志附件未读。

仅残差carrier已全文；完整field另有独立条目、范围与SHA。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [84ba92af96935e6c20a27fdf-b45658b6deba.txt](../texts/70/7081b3ed67098beee82e70c44fa41a3c50112a2f4e6ba051c2c1cea89c4b5eea.md) | 文章/文档正文 | [0, 488) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/07-oasis-social-actions.md](../../ai-reference/12-community-2016-2026/09-learning-generative/07-oasis-social-actions.md)
- [https://github.com/camel-ai/oasis/issues/113](https://github.com/camel-ai/oasis/issues/113)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
