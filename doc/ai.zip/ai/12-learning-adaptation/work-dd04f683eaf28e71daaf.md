# Voyager PR #70：Add openai_api_base option

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/minedojo/voyager/pull/70/files`。
- 已有内容：正文/源码节选。
- 原目录作者：RayBytes，PR 作者；adrianfiedler，2023-11-05 本地运行情况报告者。
- 原目录日期：2023-06-04（沿用已有记录）。
- 主要来源：[https://github.com/minedojo/voyager/pull/70/files](https://github.com/minedojo/voyager/pull/70/files)

## 概要与项目参考

Domino 研究实验若接外部推理服务，可把端点配置与任务行为分开；这一改动本身没有 NPC 规划或执行机制。

## 已有机制分析

原文实际 diff：Voyager 构造参数新增 openai_api_base，默认值为 https://api.openai.com/v1；文档参数说明同步新增。
原文实际 diff：初始化中给进程环境 OPENAI_API_BASE 赋该值，再初始化后续代理；此快照共 5 行新增，并伴 GitHub 页面加载错误外壳。

## 后续行为与玩法启发

原文未展示犯罪、关系或世界模拟行为，不能由接入兼容端点推导强玩法能力。

## 适用范围与局限

没有代理数量、吞吐、推理预算或并发数据。进程全局环境赋值也不是每个代理的独立配置证据。

把端点等实验配置集中管理；本 diff 未展示实际客户端读取方式、隔离性或错误处理。

多个实例希望不同 endpoint 时，进程级变量可能互相覆盖；需由完整调用链确认，本片段没有解决。

GitHub 外壳多数为空，但确实含真实 diff；不能全部归为纯元数据，也不能当完整 voyager.py 已读。

assigned 网页载体已全文读取；只含 PR diff 片段，不代表完整源文件、仓库、运行验证或后续讨论。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [897bfbb2fb7c35a8f2ec889c.txt](../texts/54/5467ab53d766bc070d43eb0d14f86d693009d95857053cd8e12c051579899279.md) | 正文/源码节选 | [0, 3862) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/04-embodied-community.md](../../ai-reference/12-community-2016-2026/09-learning-generative/04-embodied-community.md)
- [https://github.com/MineDojo/Voyager/pull/70](https://github.com/MineDojo/Voyager/pull/70)
- [https://github.com/MineDojo/Voyager/pull/70/files](https://github.com/MineDojo/Voyager/pull/70/files)
- [https://github.com/minedojo/voyager/pull/70/files](https://github.com/minedojo/voyager/pull/70/files)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
