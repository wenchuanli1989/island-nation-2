# Deep Dive: Gymnasium Step API

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://farama.org/Gymnasium-Terminated-Truncated-Step-API`。
- 已有内容：文章/文档正文。
- 原目录作者：The Farama Foundation（项目官方文章；页面未列个人署名）。
- 原目录日期：2023-10-27（沿用已有记录）。
- 主要来源：[https://farama.org/Gymnasium-Terminated-Truncated-Step-API](https://farama.org/Gymnasium-Terminated-Truncated-Step-API)

## 概要与项目参考

source_facts:
2023-10-27官方API设计文章完整正文，不是NPC执行器案例。

domino_recommendations:
有助不把停止/到期/完成混一个布尔，显式结果类型提高调用者正确分支；RL估值内容暂不引入。

adoption_boundary:
reset语义不能直接移植开放世界，资源和已发生效果必须持续保留。

current_code_connection:
8现实小时保存退出尚未自动实现，当前Exit保存v5世界实体但不存任务/行为进度；session截断不应代表任务成功。当前Task四状态未有明确成功/取消/挂起协议，显式reason为未来接口方向。

## 已有机制分析

源事实：将done拆为terminated/truncated；前者是MDP任务终态，后者为任务外观察/采样边界，两者都可能需要环境reset但只有terminated切断价值bootstrap。
源事实：真正有限horizon任务若时间限额属于任务定义则算termination，并需remaining time入状态保Markov；API用五返回项暴露原因，避免兼容布尔隐藏语义。
Domino建议：业务终结原因与会话保存/调度暂停分开，八小时会话边界不判NPC任务成功；任务内超时与外部停止分别记可恢复性。

## 后续行为与玩法启发

合作合同自身期限可导致失败，玩家暂离/保存退出仅中断观察；调查阶段完成不意味着嫌疑人已处罚，犯罪逃离完成不意味着机构结案。

欺骗/玩家改目标改变任务定义而非外部截断，需说明新的承诺和已提交效果；原文无犯罪机制。

## 适用范围与局限

单步双标志的开销常数；文章无全体NPC感知/规划或万级性能数据。

显式类型可减少无谓全体重置/重规划，但暂停恢复仍需要有界个人状态和事件重建。

可用结果枚举与reason区分success/failure/abort/suspend/session_save；把语义写进接口更可靠于只加文档。

不为兼容保留含糊done；实现错误需核每个消费者分支，而非只新增字段。

把环境到时间限额的done用于DQN bootstrap会误把截断值设0，是文章主反例。

把会话退出当NPC成功会结算未完成工资/货物；恢复重放起始效果可重复扣款。

双标志未解决取消ACK、占用释放、真实动作停止或保存身份，不可当完整生命周期方案。

只提供结果语义/RL边界，不是完整任务执行、存档或万人调度实证。

未引入RL训练；按local文章而非2026当前库版本表述。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [ebd91a77b06117972aa446d1.txt](../texts/e7/e76a903d32464ecfd3b8c6f1d1aa72af4b5462297565bfbe866f2a06c637fbda.md) | 文章/文档正文 | [0, 9130) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/02-training-evaluation.md](../../ai-reference/12-community-2016-2026/09-learning-generative/02-training-evaluation.md)
- [https://farama.org/Gymnasium-Terminated-Truncated-Step-API](https://farama.org/Gymnasium-Terminated-Truncated-Step-API)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
