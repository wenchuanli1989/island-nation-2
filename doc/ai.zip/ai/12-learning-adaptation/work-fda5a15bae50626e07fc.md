# Work with ollama

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/joonspk-research/generative_agents/pull/155`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：ketsapiwiq，本地模型适配 PR 作者；sjdthree，实际尝试者。
- 原目录日期：2024-05-20（沿用已有记录）。
- 主要来源：[https://github.com/joonspk-research/generative_agents/pull/155](https://github.com/joonspk-research/generative_agents/pull/155)

## 概要与项目参考

若未来允许LLM生成草案，字符串输出应在执行前校验完整结构/时长单位，解析失败不能产生动作；当前C23近期模板不需该外部provider架构。

## 已有机制分析

原讨论：为generative_agents引入ollama，使用phi3和nomic-embed-text；用户报告缺依赖/缺模型以及duration字符串解析IndexError。
参与者建议手动合并fork的cleanup改写与provider配置，新PR/WIP交叉引用存在，但本载体没有代码diff或完成验证。

## 后续行为与玩法启发

对话/规划输出不应直接产生资产或犯罪效果；本讨论未提供可玩因果或交互机制。

## 适用范围与局限

run10仍IndexError是用户报告，非万级基准；local模型不自动满足10k成本。

provider替换会暴露prompt/schema/embedding兼容与缺依赖，来源更换不是简单改URL。

fork维护状态仅参与者声称，不能确认原repo停止维护。

模型返回格式不符导致duration取split第二项失败，界面步骤跑完仍有解析错误。

没有diff/复现，不确认根因已修；网页含Loading error但仍有实质讨论，不能整页排无正文。

原PR讨论全文已读，非源码；主张/报错未经复现，作为输出校验反例，边际价值低。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [93bd43a81ad4a79d201b931b.txt](../texts/98/985d480d6863f330e353548bc8f298878037fe2cb9261ca7fbc6c49490a91a6f.md) | 讨论正文/已载入评论 | [0, 4966) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/05-generative-agents-practice.md](../../ai-reference/12-community-2016-2026/09-learning-generative/05-generative-agents-practice.md)
- [https://github.com/joonspk-research/generative_agents/pull/155](https://github.com/joonspk-research/generative_agents/pull/155)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
