# Can't run simulation "TOKEN LIMIT EXCEEDED" error

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/joonspk-research/generative_agents/issues/141`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：justtiberio，社区复现者；不是已核实的维护者。
- 原目录日期：2024-02-08（沿用已有记录）。
- 主要来源：[https://github.com/joonspk-research/generative_agents/issues/141](https://github.com/joonspk-research/generative_agents/issues/141)

## 概要与项目参考

实际集成失效案例，对可选LLM接口隔离和草案校验有负面证据；并非生成式NPC算法或规模机制原作。

## 已有机制分析

source_facts: 2024/2025用户报告最少1步也输出TOKEN LIMIT EXCEEDED，字符串进入NPC日程和task decomposition并在duration数组解析处IndexError。
评论者定位原wrapper把所有异常统一返回该文案，从而模型名停用、endpoint/SDK/response shape不匹配等原因被误诊token超限。
一批评论建议替换硬编码模型名；另一些说明completion与chat messages/response content路径区别，且不同参与者采用的替换后仍有失败。
后续评论用打印真实exception定位，但样例仍把ERROR字符串当返回值，可能再次污染规划。
domino_recommendations: 未来若LLM为可选创作/玩家对话补充，只返回有类型的草案成功/失败，不把故障文案作为task描述或动作依据。
统一外部模型配置、输入/输出边界与真实执行validator，保留可追踪错误种类；不为当前C模拟引入在线依赖。
输出时长要校验单位与合法范围，错误草案不能推进模拟时间、创建资产、声誉或犯罪证据。

## 后续行为与玩法启发

若生成谈话/欺骗计划失败，玩家世界事实与正在执行的合约/调查应不受错误文本改写。

合法自然语言计划也只能提出协作/交易/违法目标，不能凭一句生成文本让另一NPC同意或进行结算。

## 适用范围与局限

没有延迟/调用量/费用/10k benchmark，付费tier不是可运行证据；联网API不适合必需的离线万级调度环。

每个failure再解析/重试可放大负载，故障应停在边界并由已有本地任务系统继续具体工作。

硬编码散布配置与统一catchall造成定位困难；历史model/SDK建议互相不一致，不能当2026使用指南。

完整讨论展示多个修复声称与未成功反例，但没有合并PR、测试或维护者验证。

TOKEN LIMIT EXCEEDED不等于真实token问题，扩大quota或改计数无效。

替换模型名而未换API与response读取格式仍失败；把ERROR返给planner会产生相同串联污染。

评论个人成功不证明所有安装环境；生成1440 display minutes也不能嫁接Domino现实_ms时间轴。

完整读取[0,18657)issue主帖与本地嵌入timeline评论，未验证仓库源码/PR或重现API。

所有具体模型停用、接口修复为历史社区陈述，未作为当前OpenAI事实或操作建议。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [41a17e5ebcfc62759fd2fbee.repaired.txt](../texts/f4/f45def23605e3e451b8fce2c277cf914f189a9880deba2cc649b850e5c618eac.md) | 讨论正文/已载入评论 | [0, 18657) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/05-generative-agents-practice.md](../../ai-reference/12-community-2016-2026/09-learning-generative/05-generative-agents-practice.md)
- [https://github.com/joonspk-research/generative_agents/issues/141](https://github.com/joonspk-research/generative_agents/issues/141)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
