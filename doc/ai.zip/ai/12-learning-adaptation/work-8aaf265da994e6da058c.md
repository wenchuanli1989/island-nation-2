# ROMA: Multi-Agent Reinforcement Learning with Emergent Roles

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:a8ae3fdad7a54fe4cc4a4ce8965ab1eeae4d79c5f10a3e61a766253ffed18089`。
- 已有内容：论文/讲义提取文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Tonghan Wang; Heng Dong; Victor Lesser; Chongjie Zhang。
- 原目录日期：2020-07（沿用已有记录）。
- 主要来源：[https://proceedings.mlr.press/v119/wang20f.html](https://proceedings.mlr.press/v119/wang20f.html)

## 概要与项目参考

fit: 组织分工与动态职责的研究参考；人物承载组织决策与小队局部协作吻合，直接替换日常模板规划成本高。
separation: 论文的学习性能和角色可视化是作者实验结果；符号角色、事件换岗是 Domino 提案。

## 已有机制分析

source_facts: CTDE：训练时局部 Q 经 QMIX mixing network 产生全局 TD loss，执行时去掉 mixing network，个体只用局部策略。局部观察经 role encoder 产生三维高斯角色分布，采样角色经 hyper-network 生成局部 utility 最后一层参数。
用角色与个体观察行动轨迹的互信息变分下界/GRU 估计鼓励可识别、时间稳定的角色；另用两两轨迹差异模型和角色互信息约束，鼓励行为相似者同角色、行为不同者分化，避免全体角色塌缩。
SMAC 动态角色按位置、生命值、单位类型切换，形成弧形阵、健康者承压保护伤员、牺牲近战减少范围爆炸损伤；两种 regularizer 做消融，specialization 对性能贡献大，identifiability 对稳定性贡献。
domino_recommendations: 可提炼为局部团队的明确职责模板与换岗条件：角色选择依赖能力/位置/负荷，角色保持条件避免微小变化频繁换岗；不需引入神经网络。
角色只是候选职责，仍由参与者接受、执行者校验资源/位置后启动。ROMA 没有承诺、拒绝、占用释放或恢复存档机制，不可把采样角色直接当真实组织状态。

## 后续行为与玩法启发

source_facts:
展示合作、保护、牺牲、埋伏与队形，目标为完全合作共享奖励，没有个人利益、欺骗或制度调查。

domino_recommendations:
犯罪小队可分为望风/运输/接应，警察可分为封锁/追踪/救治；玩家堵路、招募或使成员受伤触发职责调整。每人仍可拒绝及隐瞒情报，角色不意味着统一信念或共同收益。

## 适用范围与局限

source_facts:
训练正则对所有 i≠j 求和/差异矩阵为 O(n²)；角色/轨迹/utility 网络、回放、完整 episode unroll，2080 Ti GPU，8 并行环境，batch32，约百万至千万步。展示的最大可控方为27名，不是万人实验。

domino_recommendations:
推理去中心化是每实体前向网络的 O(N) 加局部观察成本，仍不能证明万人 CPU预算。仅对限额局部团队采用显式角色及稀疏关系，避免全世界每次两两职责相似度计算。

直接采用需维护训练环境、共享奖励、观测/动作编码、模型版本和消融验证；符号角色版本只需共享职责定义、个体实例及可解释换岗原因。

角色采样和动态网络权重会增加重现/调试难度；论文角色 embedding 的可解释图不等于可编辑职责合同。

共享奖励下牺牲代理可能提高队伍胜率；有自主利益的 NPC 未必愿意被牺牲，不能当普遍社会合作。

新观察、玩家策略或规模改变会造成训练分布外行为；全体相似角色可能塌缩，regularizer 需调参。

计划中的分工不能自动结算工资/战利品，团队成功需真实行动提交；成员取消和事实变化必须重新分配与释放。

全文64264字符含正文、参考文献和附录已读；没有观看演示视频或运行代码，也没有核看PDF图像。

不具备10,000+人物、保存恢复、长期经济和冲突利益证据；本轮共享源码基线已全文核读。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [4993c39fc71d776e00b87852.txt](../texts/ab/abb4467e863a81c5d6d0d1c5de7a93c0adae65dd65c5a57b95a09eef94b8238d.md) | 论文/讲义提取文本 | [0, 16000)、[16000, 32000)、[32000, 48000)、[48000, 64000)、[64000, 64264) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [2350a3e0e923e3d4584c8703.txt](../texts/32/327b6accd1e696986ac57313487fa7caccf8baf139bc0450eb4821627ce2de05.md)

## 原研究概要与相关链接

- [13-youtube-2011-2026/05-organizations-institutions/02-roles-authority.md](../../ai-reference/13-youtube-2011-2026/05-organizations-institutions/02-roles-authority.md)
- [https://arxiv.org/abs/2003.08039](https://arxiv.org/abs/2003.08039)
- [https://proceedings.mlr.press/v119/wang20f.html](https://proceedings.mlr.press/v119/wang20f.html)
- [https://proceedings.mlr.press/v119/wang20f/wang20f.pdf](https://proceedings.mlr.press/v119/wang20f/wang20f.pdf)
- [https://sites.google.com/view/romarl](https://sites.google.com/view/romarl)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
