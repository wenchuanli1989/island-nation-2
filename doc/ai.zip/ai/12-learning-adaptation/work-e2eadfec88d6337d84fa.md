# [Proposal] Permit AECEnv and ParallelEnv to have AgentIDs other than str

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:b26707a4ea4614e378694ddc24adc7404ca5918948aaa57fa6d70b2d7473a827`。
- 已有内容：讨论正文/已载入评论。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：pimpale（提案与实现贡献者）；elliottower（配套 PR 评审与合并者）。
- 原目录日期：2023-08-19（沿用已有记录）。
- 主要来源：[https://github.com/farama-foundation/pettingzoo/issues/1070](https://github.com/farama-foundation/pettingzoo/issues/1070)

## 概要与项目参考

Domino推论：保持现稳定整数ID，持久化及任务引用不保存数组指针/瞬时index。

## 已有机制分析

PettingZoo提议AgentID像ObsType/ActionType为泛型变量，修复有处AgentID有处str的不一致，允许整数ID避免字符串来回转换。

## 后续行为与玩法启发

稳定对象身份支持调查证据/交易所有权；原文只类型提案。

## 适用范围与局限

减少转换可能有价值但原文无数值/人数性能。

本资料未证明Domino 10000+ NPC实时成本。

统一类型合同而非猜测所有下游都兼容；新增仅重复issue检查勾选。

混用str与泛型会使边界解析/序列化不一致；没有完整迁移实现。

已读完整文字field，不等于完整网页所有线程/附件、完整仓库源码或已执行复现。

图片/视频引用没有在本reader进行视觉或观看验证。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [7290c9ed6d53e2cb9a9b9015-33166d54aa9e.txt](../texts/b1/b1b52b918a63668ac6bb6b410a21d704b1f9ff00f5d15ed1dca44cb9e423dc94.md) | 讨论正文/已载入评论 | [0, 1290) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md](../../ai-reference/12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md)
- [https://github.com/Farama-Foundation/PettingZoo/issues/1070](https://github.com/Farama-Foundation/PettingZoo/issues/1070)
- [https://github.com/Farama-Foundation/PettingZoo/pull/1071](https://github.com/Farama-Foundation/PettingZoo/pull/1071)
- [https://github.com/farama-foundation/pettingzoo/issues/1070](https://github.com/farama-foundation/pettingzoo/issues/1070)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
