# [Proposal] Permit AECEnv and ParallelEnv to have AgentIDs other than str

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:4d3d9d41dd2834e8c9cf50a766e010cc138fb3b38f2bb2c4ecb29f03cda88167`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：pimpale（提案与实现贡献者）；elliottower（配套 PR 评审与合并者）。
- 原目录日期：2023-08-19（沿用已有记录）。
- 主要来源：[https://github.com/farama-foundation/pettingzoo/issues/1070](https://github.com/farama-foundation/pettingzoo/issues/1070)

## 概要与项目参考

残差与上述完整field归并；不按差异载体增加作品数量。

## 已有机制分析

PettingZoo提议AgentID像ObsType/ActionType为泛型变量，修复有处AgentID有处str的不一致，允许整数ID避免字符串来回转换。

## 后续行为与玩法启发

稳定对象身份支持调查证据/交易所有权；原文只类型提案。

## 适用范围与局限

残差自身不构成任何额外性能证据。

统一类型合同而非猜测所有下游都兼容；新增仅重复issue检查勾选。

混用str与泛型会使边界解析/序列化不一致；没有完整迁移实现。

仅残差carrier已全文；完整field另有独立条目、范围与SHA。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [7290c9ed6d53e2cb9a9b9015-18a0f32d70a0.txt](../texts/af/af819fb81b5035a87da7e2f2245973dde8765c8574e9c5f15dbfea41353f0537.md) | 文章/文档正文 | [0, 62) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md](../../ai-reference/12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md)
- [https://github.com/Farama-Foundation/PettingZoo/issues/1070](https://github.com/Farama-Foundation/PettingZoo/issues/1070)
- [https://github.com/Farama-Foundation/PettingZoo/pull/1071](https://github.com/Farama-Foundation/PettingZoo/pull/1071)
- [https://github.com/farama-foundation/pettingzoo/issues/1070](https://github.com/farama-foundation/pettingzoo/issues/1070)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
