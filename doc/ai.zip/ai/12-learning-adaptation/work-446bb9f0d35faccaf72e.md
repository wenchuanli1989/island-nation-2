# Using Deep Reinforcement Learning to Coordinate Multi-Modal Journey Planning with Limited Transportation Capacity

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://www.tib-op.org/ojs/index.php/scp/article/download/89/271`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Lara Codeca; Vinny Cahill。
- 原目录日期：2021-10-06（沿用已有记录）。
- 主要来源：[https://www.tib-op.org/ojs/index.php/scp/article/download/89/271](https://www.tib-op.org/ojs/index.php/scp/article/download/89/271)

## 概要与项目参考

有限容量导致个人预测互相改变，支持把路线可达、ETA估计、真实进度和设施占用分开。
活动同一到期时刻提供集中唤醒/出发峰值的具体压测场景；当前引擎未测试。

## 已有机制分析

source_fact: 每个参加者选等待或开始某交通方式，共享同一个PPO策略；输入含位置、距活动时间、各方式预计时长、使用量、尚未出发需求和车辆所有权。时间与ETT离散为3分钟。
domino_recommendation: 交通候选应包含出发时段、容量竞争、方式可达及真实资产；预计时长是选择信息，实际到达由执行和拥塞推进。
source_fact: Simple奖励只关注准时窗口，OTT再惩罚实际旅时/早到等待/迟到，OTTCoord按他人未完成目标再调奖励；不同指标改变方式分布，没有一致证明显式协调总是更好。
domino_recommendation: 区分个人偏好与组织协调成本；用实际迟到、等待、方式利用率评估设计，不仅看最短路径。
source_fact: 停车改为先到最近车位后步行；满位继续巡游。所有权实验全部动作仍暴露但不能使用不拥有车辆，策略通过试错学习限制。
domino_recommendation: 停车/换乘/候车可拆为可取消任务和容量占用；已知物理不可行先筛，未知事实允许失败；盗车非法仍可做独立行为候选。
source_fact: 训练1000活动参加者；20K背景人流仅在少数背景交通实验出现，其他消融无背景。从收敛后末25轮选择10episode均值最好的策略；真实规模与偏好为未来工作。
domino_recommendation: 仅读取约束与指标机制，现阶段不导入Ray/RLlib或在线DRL。

## 后续行为与玩法启发

crime:
偷车/逃离和合法出行共享物理容量，但制度许可单独判断；这是Domino建议，源文无犯罪模型。

deception:
假车位/错误时刻表改变主观信息，真正资源可用性仍由执行查验。

investigation:
调查人员追赶会受迟到、停车、换乘及封锁影响；不能用预计到达直接结案。

cooperation:
组织错峰、共享运力、邀请共乘，参与者不配合会破坏源文假设。

player_interaction:
玩家可增加运力、改变价格、封路或举办活动，NPC提前出发/改方式并承担实际等待后果。

## 适用范围与局限

没有10000自主NPC单机吞吐证明；1000训练参加者与20K背景交通不是同一学习规模。

共享策略避免每人一网络，但查询ETT/微观交通/全局残余需求及训练仍有成本，文中未给C23热路预算。

建议按出发/容量事件更新局部方式摘要，避免所有NPC每步重新计算所有模式路线；O(NM)预算是推论。

抽取容量与时段接口，不引入完整DRL架构；奖励改变会造成行为偏差，要保留解释指标。

3分钟状态/5分钟奖励离散属交通实验参数，Domino应换成累计未冻结现实_ms而不是显示日历。

PDF公式乱码，OTTCoord的分式不能从提取文本精确抄实现；原排版/源码为关联缺口。

移除公交仅保留更可靠地铁并未增加公交选择，因为PTW竞争与道路容量共同变化。

减少迟到常伴更多早到等待，单看旅时或出发时刻会误判。

有限时间/容量下全体准时可能无解，偏好更复杂还可能扩大无解空间。

真实用户不遵守计划或不愿共享信息会破坏假设；论文未验证采纳与执行一致性。

完整读取68517字符PDF提取正文及参考文献，未核看图像或运行实验。

交通训练专用假设：单一终点/目标时间、依计划执行、所有参与者共享策略且可访问全局特征；不能外推普遍NPC自治。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [0f6b6a3dca9bfba12f314da8.txt](../texts/9f/9fa2cc4e9fb7a72661d5270f1a4da3268c91803f1f3e72a74f73ab04c8719e96.md) | 论文/讲义提取文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 48000)、[48000, 60000)、[60000, 68517) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/08-activity-transport.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/08-activity-transport.md)
- [https://doi.org/10.52825/scp.v2i.89](https://doi.org/10.52825/scp.v2i.89)
- [https://sumo.dlr.de/hugo/2021/](https://sumo.dlr.de/hugo/2021/)
- [https://www.tib-op.org/ojs/index.php/scp/article/download/89/271](https://www.tib-op.org/ojs/index.php/scp/article/download/89/271)
- [https://www.tib-op.org/ojs/index.php/scp/article/view/89](https://www.tib-op.org/ojs/index.php/scp/article/view/89)
- [https://www.youtube.com/watch?v=OF--8wm81QQ](https://www.youtube.com/watch?v=OF--8wm81QQ)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
