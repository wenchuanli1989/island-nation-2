# ROMA: Multi-Agent Reinforcement Learning with Emergent Roles

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://proceedings.mlr.press/v119/wang20f/wang20f.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Tonghan Wang; Heng Dong; Victor Lesser; Chongjie Zhang。
- 原目录日期：2020-07（沿用已有记录）。
- 主要来源：[https://proceedings.mlr.press/v119/wang20f/wang20f.pdf](https://proceedings.mlr.press/v119/wang20f/wang20f.pdf)

## 概要与项目参考

source_facts: 完全合作共享奖励的战斗环境，五随机seed与消融显示角色分工改善学习。
domino_application: 动态角色概念可参考，但神经学习执行链超出现有普通C维护范围。

## 已有机制分析

source_fact: 局部观测编码Gaussian角色embedding，由hypernetwork生成个体utility网络参数；中心mixing网络训练但执行去除。
domino_recommendation: 只提炼共享行为定义与个人角色实例分离，不直接采用角色神经网络。
source_fact: 轨迹与角色互信息使角色可识别；两两轨迹差异正则让相似责任靠近，避免全员角色坍缩。
domino_recommendation: 任务角色有稳定承诺和切换条件，健康、位置、技能变化触发局部重新分工。
source_fact: SMAC学到健康者挡火、受伤者后撤、治疗者分工、顺次牺牲单位减少溅射。
domino_recommendation: 小队合作可有替补及局部角色约束，仍需个体接受与真实执行，不能中心预测直接消耗个人资源。

## 后续行为与玩法启发

crime:
望风/实施/接应可用角色模板，原文没有犯罪或执法机制。

investigation:
embedding不构成证据/权限。

deception:
共享奖励不覆盖背叛或隐瞒个人目标。

cooperation:
健康与位置影响掩护、救援分工；拒绝、撤退、替补须另设计。

trade:
无交易机制，仅分工可用于生产。

player_intervention:
玩家改变小队资源/位置会迫使换角色，这是Domino建议。

## 适用范围与局限

实验只有数十单位，不支持10,000长期NPC。

训练的specialization遍历agent pairs，带两两矩阵与轨迹比较成本。

执行仍须encoder/decoder/local网络推理；训练数百万到两千万timesteps及replay/GRU。

学习embedding不等于可审核职业、权限或承诺定义。

行为/观测/奖励改变需再训，复现及调试成本高。

更复杂层级组织与分工交互仍待研究。

最大化所有pairs互信息会角色坍缩。

只有时间识别性提升有限，专门化损失更关键。

团队最优会牺牲个体，开放社会个人风险/拒绝权不由共享奖励覆盖。

完整读主论文文本及参考文献，载体缺正文引用的Appendix A-D，证明、网络结构与扩展maps未取得。

未看实验视频/图像或执行代码；win rate不是Domino吞吐。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [5d76ee0a35dd84596263b187.txt](../texts/81/81908151b108e34590d6cd4467a61be64ee3c7eaa72bd4ee5056e2a53d25c5d4.md) | 论文/讲义提取文本 | [0, 46275) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/05-organizations-institutions/02-roles-authority.md](../../ai-reference/13-youtube-2011-2026/05-organizations-institutions/02-roles-authority.md)
- [https://arxiv.org/abs/2003.08039](https://arxiv.org/abs/2003.08039)
- [https://proceedings.mlr.press/v119/wang20f.html](https://proceedings.mlr.press/v119/wang20f.html)
- [https://proceedings.mlr.press/v119/wang20f/wang20f.pdf](https://proceedings.mlr.press/v119/wang20f/wang20f.pdf)
- [https://sites.google.com/view/romarl](https://sites.google.com/view/romarl)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
