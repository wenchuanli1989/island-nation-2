# [BUG] Agent encounters 400 at runtime

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:7fa2a1f207a69cf4cfd655bea3326f699887dc8f8d91cccd1a7bbaeeaf290b11`。
- 已有内容：讨论正文/已载入评论。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：DengSSya，运行问题报告者。
- 原目录日期：2025-05-18（沿用已有记录）。
- 主要来源：[https://github.com/camel-ai/oasis/issues/113](https://github.com/camel-ai/oasis/issues/113)

## 概要与项目参考

Domino推论：失败状态与后续激活必须可修复/明确终结；工具或动作请求与返回一一对应；代码字面差异不可算纯Markdown等价。

## 已有机制分析

OASIS QWEN例子丢tool_call_id对应tool响应后400反复出现，重新激活仍坏；新field恢复unfenced if __name__ == "__main__":，旧成if name == "main":。error string本来已在旧正文。

## 后续行为与玩法启发

只作外部推理/执行接口失败反例，不能让模型叙述自动成为犯罪/帖子实际产出。

## 适用范围与局限

semaphore=64仅并发配置；示例激活7人、循环10步，文称30轮，与万人能力无关。

本资料未证明Domino 10000+ NPC实时成本。

error字符串、入口标识、缩进与真实源码分别保存；本地仅静态读，不把恢复guard说成运行已修复。

不能用current repaired另一评论相同guard字面行抵消original issue code block损坏；已实际读三个具体上下文。

正文称30轮、所示代码10轮；重复错误根因未独立验证，日志附件未读。

已读完整文字field，不等于完整网页所有线程/附件、完整仓库源码或已执行复现。

图片/视频引用没有在本reader进行视觉或观看验证。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [84ba92af96935e6c20a27fdf-6045ed3b4ce3.txt](../texts/11/113abc29d2661a0ba8b7d8886654f6b45ba952bda84db2b5f438f482f99deadd.md) | 讨论正文/已载入评论 | [0, 3024) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/07-oasis-social-actions.md](../../ai-reference/12-community-2016-2026/09-learning-generative/07-oasis-social-actions.md)
- [https://github.com/camel-ai/oasis/issues/113](https://github.com/camel-ai/oasis/issues/113)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
