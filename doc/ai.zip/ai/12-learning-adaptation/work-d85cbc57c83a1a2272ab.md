# Simulating Emotions With an Integrated Computational Model of Appraisal and Reinforcement Learning

- 分类：机器学习、强化学习与适应性。
- 资料标识：`doi:10.1145/3613904.3641908`。
- 已有内容：论文/讲义提取文本。
- 当前前100：第 89 项；[结合认知评价与强化学习的情绪模拟](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/089-d85cbc57c83a.md)。
- 原目录作者：Jiayi Eurus Zhang; Bernhard Hilpert; Joost Broekens; Jussi P. P. Jokinen。
- 原目录日期：2024-05-08（沿用已有记录）。
- 主要来源：[https://doi.org/10.1145/3613904.3641908](https://doi.org/10.1145/3613904.3641908)

## 概要与项目参考

Distinct mechanism for goal-relative emotion and accumulated boredom/irritation, connecting task result events to preferences and relationships. No executor/lifecycle/institution/social-belief implementation.

## 已有机制分析

source_facts:
MDP/converged tabular Q-learning provide state-action values and transition estimates. Suddenness = one minus normalized transition frequency; goal relevance = bounded absolute TD update; conduciveness maps signed TD update to [0,1]; power uses action-value spread.

A linear SVM maps four appraisal values to happiness/boredom/irritation using theory-derived synthetic profiles. Its penalty is calibrated to human rating precision/spread rather than directly minimizing emotion prediction error. A present-and-prior moving window captures persistence.

Experiment 1: 27 participants, one post-task report, R²=.78/RMSE=.13. Experiment 2: 45 participants, four reports, R²=.86/RMSE=.19, initial model emotions taken from average human starting ratings. Boredom deviates; discussion limits intentionally manipulated text quizzes and three emotions.

domino_recommendations:
Appraise only NPC-observed outcomes against that NPC's goal/expectation and perceived alternatives. Failed promises or blocked routes can change irritation without committing assets or assigning legal blame.

Use compact inspectable profile functions and bounded history first. Per-NPC MDP/Q-learning/SVM training is optional research, not necessary for initial emotional causality.

## 后续行为与玩法启发

Domino suggestions: player's broken deliveries increase subjective irritation; diverse rewarding work reduces boredom. Deceptive reports can change perceived appraisal while leaving facts unchanged, enabling later investigation/correction. Cooperation affects emotion through actual outcomes, and crime, discovery, blame, sanction remain separate. The source does not implement these social/criminal mechanisms.

## 适用范围与局限

Four-value appraisal plus fixed window can be O(1) per subscribed event with O(N) bounded storage. Original state/action/transition tables and policy training can explode in open worlds if copied to every one of 10,000 NPCs. Use relevant sparse observations and no all-NPC per-frame emotion pass/all-pair blame; no NPC benchmark in paper.

Reward scale, event abstraction, power formula and window length require content tuning. Explain each update using goal/expectation/outcome. Persist bounded emotion separately from actual business effects; any real-ms decay is a Domino extension. Extracted formula symbols need original verification.

Equal Q values may mean ignorance or similar alternatives, not literal inability.

Actual-world appraisal makes unaware/deceived NPCs omniscient.

Normalizing three ratings to sum 1 loses absolute emotional intensity and makes mixed low/intense feelings indistinguishable.

Three GUI emotions do not establish long-term fear/grief/guilt/social blame.

Converged policy and human-initialized emotions narrow the independent predictive claim.

Full 64,130-character extracted paper including references/appendices read, not PDF diagram visual audit.

Formula symbols partly question marks; prose supports mechanism but exact implementation formulas require original verification.

72 humans in HCI tasks, not game effectiveness or 10,000-NPC scale proof.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [989ccd0329f529ef62dbc7c0.repaired.txt](../texts/0f/0fbf26788f96a58d97ce1bea77dd76b6098b53401dfc392cb3c8e1dc081f3379.md) | 论文/讲义提取文本 | [0, 64130) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/01-decisions-needs/04-personality-emotion.md](../../ai-reference/13-youtube-2011-2026/01-decisions-needs/04-personality-emotion.md)
- [https://doi.org/10.1145/3613904.3641908](https://doi.org/10.1145/3613904.3641908)
- [https://jyu.finna.fi/Record/jyx.123456789_94912](https://jyu.finna.fi/Record/jyx.123456789_94912)
- [https://jyx.jyu.fi/bitstream/handle/123456789/94912/3613904.3641908.pdf?isAllowed=y&sequence=-1](https://jyx.jyu.fi/bitstream/handle/123456789/94912/3613904.3641908.pdf?isAllowed=y&sequence=-1)
- [https://programs.sigchi.org/chi/2024/program/content/147014](https://programs.sigchi.org/chi/2024/program/content/147014)
- [https://www.youtube.com/watch?v=qV_KnUwJxwg](https://www.youtube.com/watch?v=qV_KnUwJxwg)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
