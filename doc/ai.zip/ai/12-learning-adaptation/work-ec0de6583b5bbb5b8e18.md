# KILL_REWARD is not being used in Battle and Battlefield #61

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/farama-foundation/magent2/issues/61`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：McStevenss；MAgent2 用户／问题报告者，未据此认定为维护者。
- 原目录日期：2025-07-09（沿用已有记录）。
- 主要来源：[https://github.com/Farama-Foundation/MAgent2/issues/61](https://github.com/Farama-Foundation/MAgent2/issues/61)

## 概要与项目参考

一个具体的配置存在但效果规则缺失的社区反例，适合提醒执行闭环；不足以确认MAgent2实现缺陷。

## 已有机制分析

source_facts: McStevenss于2025-07-09提交问题，页面状态Closed；正文明确说自己不确定是bug还是设计。
问题称Battle/Battlefield把KILL_REWARD放入options与reward range，却未像combinedarms生成实际给agent奖励的规则。
本载体没有回复、修复说明、规则源码或复现输出；Closed本身不说明已修复。
domino_recommendations: 将动作/制度参数定义、执行器真实效果和统计展示分开审阅；声明工资/奖励额度不等于执行器已经支付。
任务成功必须由真实领域操作结果产生，不能仅由timer到期、配置存在或计划预测认定。

## 后续行为与玩法启发

source_facts:
报告涉及战斗击杀奖励，没有社会制度或玩家互动设计。

domino_recommendations:
委托赏金、交易返款、破坏惩罚都要由执行结果触发且避免重复；法律裁决另有执行主体，不能直接把判定当资金扣除。犯罪物理行为与是否被观察、是否获罪仍分别记录。

## 适用范围与局限

无吞吐、人数、内存或复杂度数据。

万级NPC的报酬应在受影响结果上结算，不能由每帧全体扫描奖励配置推断效果。

保留配置→规则→实际结果的可追踪位置，排查同名常量是否仅被统计层引用。

用Closed状态或reward range的值证明奖励已经实际发放。

重复消费成功事件导致双重付款；只存声明额度使恢复后不知是否已结算。

完整读882字符问题载体；未读环境源码、评论、修复提交或实验。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [0505279b1740581b92b1660f.txt](../texts/d3/d379eb9b12154bc20453baaa6b4c66797d0892218b8172b211cf22d71520bd70.md) | 讨论正文/已载入评论 | [0, 882) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/03-social-learning-environments.md](../../ai-reference/12-community-2016-2026/09-learning-generative/03-social-learning-environments.md)
- [https://github.com/Farama-Foundation/MAgent2/issues/61](https://github.com/Farama-Foundation/MAgent2/issues/61)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
