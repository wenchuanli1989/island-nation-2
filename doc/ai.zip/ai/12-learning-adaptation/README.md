# 机器学习、强化学习与适应性

本类收录 94 条已有资料记录。当前前100中的条目优先列出，随后按题名排列。依据资料题名、来源主题与已有正文机制分析归类；跨领域资料在详情页保留关联链接。

[资料总目录](../README.md)

| 资料与概要 | 已有内容范围 | 当前前100 |
|---|---|---:|
| [Simulating Emotions With an Integrated Computational Model of Appraisal and Reinforcement Learning](work-d85cbc57c83a1a2272ab.md) | 论文/讲义提取文本 | 89 |
| [Add action masking documentation, update usage scripts](work-4d20072b173cf7776311.md) | 文章/文档正文 |  |
| [Add openai_api_base option (Voyager PR #70)](work-4d55d160e392ffda422c.md) | 讨论正文/已载入评论 |  |
| [An Organizationally-Oriented Approach to Enhancing Explainability and Control in Multi-Agent Reinforcement Learning](work-3027f78c01968acb16bb.md) | 论文/讲义提取文本 |  |
| [An Organizationally-Oriented Approach to Enhancing Explainability and Control in Multi-Agent Reinforcement Learning](work-5556485d95914f62459e.md) | 论文/讲义提取文本 |  |
| [An Organizationally-Oriented Approach to Enhancing Explainability and Control in Multi-Agent Reinforcement Learning](work-7d3b1b1bf2c9779fcc8c.md) | 已有摘要/简介文本 |  |
| [Building AI Speeders with Machine Learning in Star Wars Outlaws \| AI and Games #80](work-c242c02dc6108834a703.md) | 字幕/转录文本 |  |
| [Can't run simulation "TOKEN LIMIT EXCEEDED" error](work-5a8bc4ffb1fbcf6ff2ab.md) | 讨论正文/已载入评论 |  |
| [Can't run simulation "TOKEN LIMIT EXCEEDED" error #141](work-088e9f49342bde4f01c2.md) | 讨论正文/已载入评论 |  |
| [CleanRL #477 Possible inconsistencies with the PPO implementation](work-903d29b88abe3db0b831.md) | 讨论正文/已载入评论 |  |
| [Closing the Affective Loop via Experience-Driven Reinforcement Learning Designers](work-9cad53c7cdff015bbb23.md) | 已有摘要/简介文本 |  |
| [Closing the Affective Loop via Experience-Driven Reinforcement Learning Designers](work-ddbcdddecb3b5782a26a.md) | 论文/讲义提取文本 |  |
| [Closing the Affective Loop via Experience-Driven Reinforcement Learning Designers (2024)](work-5a6bd5651af5686826ec.md) | 论文/讲义提取文本 |  |
| [Contest run provenance: making model drift detectable with per-run output fingerprinting (Concordia issue 271)](work-2ceffe0222c8e939b240.md) | 讨论正文/已载入评论 |  |
| [Contest run provenance: making model drift detectable with per-run output fingerprinting · Issue #271 · google-deepmind/concordia · GitHub](work-db503a2d1cbc77156b5c.md) | 文章/文档正文 |  |
| [Continuous Time Continuous Space Homeostatic Reinforcement Learning (CTCS-HRRL) : Towards Biological Self-Autonomous Agent](work-d50d806c01a09133e4cc.md) | 论文/讲义提取文本 |  |
| [Deep Dive: Gymnasium Step API](work-3dd153a83564d9df2dba.md) | 文章/文档正文 |  |
| [Deep Dive: VectorEnv Autoreset](work-c377a4d62f4ed2456d8b.md) | 文章/文档正文 |  |
| [Democratizing Generative Agent-Based Simulation for Sustainable Development Goals](work-11fc835de0d673b08f2e.md) | 文章/文档正文 |  |
| [Emergent Bartering Behaviour in Multi-Agent Reinforcement Learning](work-ee500ce8a7dd5c41971c.md) | 文章/文档正文 |  |
| [Evaluation during training (sample-factory #302)](work-251c296d51d21f20cde0.md) | 讨论正文/已载入评论 |  |
| [Failed to start the simulation with customized map](work-0dd6ae95b44a699028e1.md) | 文章/文档正文 |  |
| [Failed to start the simulation with customized map](work-87685694e667191cb78c.md) | 讨论正文/已载入评论 |  |
| [Failed to start the simulation with customized map](work-a1ff00668eae561c80a5.md) | 讨论正文/已载入评论 |  |
| [Fix turn-order corruption when an actor is removed mid-simulation (Concordia PR #298)](work-e92a65c9b7336781490f.md) | 讨论正文/已载入评论 |  |
| [Harden tool policy runtime and malformed decision handling](work-5269b3383fdcd1ca09a1.md) | 讨论正文/已载入评论 |  |
| [Hierarchical Multi-Agent Skill Discovery](work-54e59cf6d87d01e41b8e.md) | 文章/文档正文 |  |
| [How Forza's Drivatar Actually Works \| AI and Games #60](work-416ceed94e36e601fd2b.md) | 字幕/转录文本 |  |
| [Imitation learning vs. offline reinforcement learning — Sergey Levine](work-018a9b924b43d61a296b.md) | 字幕/转录文本 |  |
| [KILL_REWARD is not being used in Battle and Battlefield #61](work-ec0de6583b5bbb5b8e18.md) | 讨论正文/已载入评论 |  |
| [LLGuidance: Making Structured Outputs Go Brrr (June 11, 2025)](work-24935fc55b7e6cfd9245.md) | 文章/文档正文 |  |
| [Learning Task Requirements and Agent Capabilities for Multi-agent Task Allocation](work-226ff57386a82475862e.md) | 论文/讲义提取文本 |  |
| [Learning from My Partner’s Actions: Roles in Decentralized Robot Teams](work-09976cba12dd3734516b.md) | 文章/文档正文 |  |
| [Learning from My Partner’s Actions: Roles in Decentralized Robot Teams](work-888461a88a8a47ace6c7.md) | 文章/文档正文 |  |
| [ML-Agents Beta 0.3.0](work-4c2500bacad0ed792837.md) | 文章/文档正文 |  |
| [Melting Pot and the Reverse-Engineering Approach to Multi-Agent Artificial General Intelligence](work-622545d2c5f9a2215491.md) | 文章/文档正文 |  |
| [Melting Pot: an evaluation suite for multi-agent reinforcement learning](work-4802d99f648146fae53c.md) | 文章/文档正文 |  |
| [MineRL sample-efficient reinforcement learning challenge—back for a second year—benefits organizers, as well as larger research community](work-2bdbb81a1d2fc601092c.md) | 文章/文档正文 |  |
| [Minimap in Adversarial Pursuit](work-e0b96469ed11d557ac59.md) | 讨论正文/已载入评论 |  |
| [Misc. bug: Nested `allOf` in JSON Schema Generates Wrong Grammar](work-e747d924aafa3127e72d.md) | 文章/文档正文、讨论正文/已载入评论 |  |
| [Modeling long-term nutritional behaviors using deep homeostatic reinforcement learning](work-e2f6a7ea8d2824c3412b.md) | 论文/讲义提取文本 |  |
| [Multi-agent Reinforcement Learning in Sequential Social Dilemmas](work-d7df1db5a13d250eb1d4.md) | 论文/讲义提取文本 |  |
| [NewVersion: Fixes & Improvements (e.g. Cost Assessment&Tracking, Azure, +more)](work-bf12daaca414642291a3.md) | 讨论正文/已载入评论 |  |
| [PettingZoo #652 — Error with agents being done at different times](work-8f572f3f0c9b655c34d5.md) | 讨论正文/已载入评论 |  |
| [PettingZoo 1.12.0 API changes](work-d5d88e9522db304eb94e.md) | 文章/文档正文 |  |
| [PettingZoo PR #1071 — Permit AgentIDs other than str](work-c3593e6faa8f63a0c1e3.md) | 讨论正文/已载入评论 |  |
| [PettingZoo PR #953 — Add action masking documentation, update usage scripts](work-92593f4d551abc32978d.md) | 讨论正文/已载入评论 |  |
| [PettingZoo issue #889: reset() got an unexpected keyword argument return_info](work-91d818e97b4370f71977.md) | 讨论正文/已载入评论 |  |
| [Possible inconsistencies with the PPO implementation](work-1bfb3ab119708e6593a3.md) | 讨论正文/已载入评论 |  |
| [Possible inconsistencies with the PPO implementation](work-3a88e4b6ea888936e38f.md) | 文章/文档正文 |  |
| [Prompt Efficiency - Using Structured Generation to get 8-shot performance from 1-shot.](work-57c04a54eafc20593955.md) | 文章/文档正文 |  |
| [RODE: Learning Roles to Decompose Multi-Agent Tasks \[分派身份元数据；恢复正文题名不可辨\]](work-6ee511d8003c053e7668.md) | 关联链接；现有文本不可用或只有目录 |  |
| [RODE: Learning Roles to Decompose Multi-Agent Tasks — demo page](work-6d73968017ccab663d26.md) | 文章/文档正文 |  |
| [ROMA: Multi-Agent Reinforcement Learning with Emergent Roles](work-8aaf265da994e6da058c.md) | 论文/讲义提取文本 |  |
| [ROMA: Multi-Agent Reinforcement Learning with Emergent Roles](work-a95cc2d2b570ad29ae68.md) | 论文/讲义提取文本 |  |
| [ROMA: Multi-Agent Reinforcement Learning with Emergent Roles — project site](work-49adf06f220fb1d1bd60.md) | 文章/文档正文 |  |
| [Reflexion: Language Agents with Verbal Reinforcement Learning](work-465bd5dc9844d577658c.md) | 论文/讲义提取文本 |  |
| [Removing specific skills during training](work-d54f349bc2a82822099a.md) | 讨论正文/已载入评论 |  |
| [Sample Factory #29: \[Q?\] How to max fps?](work-00d1de4af516761ac608.md) | 讨论正文/已载入评论 |  |
| [Simulating Emotions With an Integrated Computational Model of Appraisal and Reinforcement Learning — Finna/JYX record](work-afb42244363a3a604bd0.md) | 已有摘要/简介文本 |  |
| [Simulating Machine Learning Agents inside a game engine (obtained post)](work-2a047336a97756a4eccf.md) | 讨论正文/已载入评论 |  |
| [Structured Decoding in vLLM: a gentle introduction](work-6f4e40f7ec8e432a5642.md) | 文章/文档正文 |  |
| [Supervised Learning of Behaviors — CS 285, Sergey Levine](work-c0864cf24d2ad50ab214.md) | 论文/讲义提取文本 |  |
| [The 37 Implementation Details of Proximal Policy Optimization](work-3087843d7a0c7a9ba885.md) | 文章/文档正文 |  |
| [Tool call support (generic + native for Llama, Functionary, Hermes, Mistral, Firefunction, DeepSeek) w/ lazy grammars](work-49dc0dfd666bd4d3f14d.md) | 讨论正文/已载入评论 |  |
| [Unity at GDC - Unity Machine Learning: ML-Agents 0.3](work-2e800756a0bf697cb2a4.md) | 字幕/转录文本 |  |
| [Using Deep Reinforcement Learning to Coordinate Multi-Modal Journey Planning with Limited Transportation Capacity](work-446bb9f0d35faccaf72e.md) | 论文/讲义提取文本 |  |
| [Using Deep Reinforcement Learning to Coordinate Multi-Modal Journey Planning with Limited Transportation Capacity](work-c8f222aa2eacc1cadd11.md) | 已有摘要/简介文本 |  |
| [Variational Offline Multi-agent Skill Discovery](work-4eee52d883895f98b99a.md) | 论文/讲义提取文本 |  |
| [Variational Offline Multi-agent Skill Discovery（论文页摘要）](work-101a4ec8caf69d3f4f6d.md) | 已有摘要/简介文本 |  |
| [Variety in Autonomous Playtesting: a Case Study on Reinforcement Learning for NHL26](work-ba6bed709ff354a2dab6.md) | 字幕/转录文本 |  |
| [Voyager #157: Fails with small models including llama3-8b](work-7f64c057979c7ef7412b.md) | 讨论正文/已载入评论 |  |
| [Voyager PR #70：Add openai_api_base option](work-dd04f683eaf28e71daaf.md) | 正文/源码节选 |  |
| [WARNING - Failed to dispatch block: 'NoneType' object is not subscriptable](work-2dcd79f01b00b20e6759.md) | 讨论正文/已载入评论 |  |
| [Why 'Bowie Knife99' is a Bug in Forza's Drivatar System \| AI and Games #85](work-8d31068763ab67bbb7b5.md) | 字幕/转录文本 |  |
| [Work with ollama](work-fda5a15bae50626e07fc.md) | 讨论正文/已载入评论 |  |
| [\[2021 TGDF\] 表演型遊戲 AI — 格鬥遊戲之應用（戴文凱）— 说明与文字问答](work-59f600cb054cf8e866e6.md) | 文章/文档正文 |  |
| [\[Announcement\] MineRL version 0.1.14!](work-27cb992f63e3816e26f2.md) | 讨论正文/已载入评论 |  |
| [\[BUG\] Agent encounters 400 at runtime](work-547ba3fdc35fe0ac3672.md) | 文章/文档正文 |  |
| [\[BUG\] Agent encounters 400 at runtime](work-e21bd78a2712c8a2a3ab.md) | 讨论正文/已载入评论 |  |
| [\[Bug Report\] TypeError: reset() got an unexpected keyword argument 'return_info'](work-9c6a3545d3c83f2096d2.md) | 讨论正文/已载入评论 |  |
| [\[Bug Report\] TypeError: reset() got an unexpected keyword argument 'return_info'](work-fead3ae470a392c6aa73.md) | 文章/文档正文 |  |
| [\[Proposal\] Permit AECEnv and ParallelEnv to have AgentIDs other than str](work-48ad9e8f683e5c4d0a9c.md) | 文章/文档正文 |  |
| [\[Proposal\] Permit AECEnv and ParallelEnv to have AgentIDs other than str](work-e2eadfec88d6337d84fa.md) | 讨论正文/已载入评论 |  |
| [\[Proposal\] Permit AECEnv and ParallelEnv to have AgentIDs other than str #1070](work-0076df7330b07a1f62bf.md) | 讨论正文/已载入评论 |  |
| [\[Q?\] How to max fps?](work-039066da7c80d1cb8539.md) | 文章/文档正文 |  |
| [\[Q?\] How to max fps?](work-3d87e8dc76b34675189a.md) | 讨论正文/已载入评论 |  |
| [deeprl_gfn: Modeling long-term nutritional behaviors using deep homeostatic reinforcement learning](work-c53d042920ead0ff6a92.md) | 文章/文档正文 |  |
| [fix(agent): accept 'failed' as valid StructuredSummary status](work-191026aef18836976b5a.md) | 源码/工程文本 |  |
| [fix: read trace post ids from info payload](work-a27857dde630affda119.md) | 讨论正文/已载入评论 |  |
| [generative_agents PR #186 — NewNewVersion: More Fixes & Improvements](work-f16ae705b867d682b306.md) | 讨论正文/已载入评论 |  |
| [vllm max length breaking structured generation #1173](work-eea025ed2283ae3daefb.md) | 讨论正文/已载入评论 |  |
| [在运行 HurricaneMobility 评估脚本时，程序提示缺少 groundtruth 文件](work-a681c774ac1b2c300d28.md) | 文章/文档正文 |  |
| [多智能体强化学习(2/2)：三种架构 Multi-Agent Reinforcement Learning](work-41c6376ee0375aa49552.md) | 论文/讲义提取文本 |  |
