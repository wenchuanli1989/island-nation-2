# [Bug Report] TypeError: reset() got an unexpected keyword argument 'return_info'

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:5170c2bd251260dfc4aa85c426d9d0821b77723ea8b7a71bf40580b0e5991fb4`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：elliottower（问题报告者、贡献者）；jjshoots（配套修复作者）；code-juicer（修复评审与合并者）。
- 原目录日期：2023-02-28（沿用已有记录）。
- 主要来源：[https://github.com/farama-foundation/pettingzoo/issues/889](https://github.com/farama-foundation/pettingzoo/issues/889)

## 概要与项目参考

残差与上述完整field归并；不按差异载体增加作品数量。

## 已有机制分析

RLlib调用reset(return_info=True)不合PettingZoo/Gymnasium接口；去参数仍误把按agent字典拆obs/info，示例改为return obs,{}。恢复<locals>/<lambda>栈标记与表格行格式，机制及代码原已在旧文本。

## 后续行为与玩法启发

仅模拟训练接口参考，无犯罪/玩家机制。

## 适用范围与局限

残差自身不构成任何额外性能证据。

原文历史版本明确：Ray2.3.0/PettingZoo1.22.3等；不要当当前API指南。

部分环境返回infos而部分不返回导致适配假设错；修复例子未由本任务运行。

仅残差carrier已全文；完整field另有独立条目、范围与SHA。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [be8ec93e4aba3da8dabeb7d1-dade41a94a8c.txt](../texts/b7/b799aec3b7cc2e907184e12a7fb4d873dc35d6b1fad25e5ab1c57f1bd3932dbf.md) | 文章/文档正文 | [0, 852) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md](../../ai-reference/12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md)
- [https://github.com/Farama-Foundation/PettingZoo/issues/889](https://github.com/Farama-Foundation/PettingZoo/issues/889)
- [https://github.com/Farama-Foundation/PettingZoo/pull/890](https://github.com/Farama-Foundation/PettingZoo/pull/890)
- [https://github.com/farama-foundation/pettingzoo/issues/889](https://github.com/farama-foundation/pettingzoo/issues/889)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
