# Tool call support (generic + native for Llama, Functionary, Hermes, Mistral, Firefunction, DeepSeek) w/ lazy grammars

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/ggml-org/llama.cpp/pull/9639`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：ochafik（llama.cpp 贡献者／PR 作者）。
- 原目录日期：2024-09-25（沿用已有记录）。
- 主要来源：[https://github.com/ggml-org/llama.cpp/pull/9639](https://github.com/ggml-org/llama.cpp/pull/9639)

## 概要与项目参考

Domino建议：未来若有限NPC对话或剧情草案用本地LLM，可把它输出限制为少量声明式意图，交执行层复核目标/资源/时空/许可；grammar只约束语法。
当前核心NPC任务模板/执行闭环没有必要引入模型、服务或多模型模板兼容层，此篇适合可选LLM接口参考而非核心前100机制。

## 已有机制分析

原文：lazy grammar 在特定文本/特殊token触发前允许普通输出，触发后按tool schema约束；必需tool_choice和泛用JSON模式使用不同语法策略。
原文：原生格式处理器负责Llama/Functionary/Hermes/Mistral等模板和调用解析；minja提供最小Jinja实现降低模板兼容维护成本；JSON schema支持范围有条件。
原文：给出非streaming调用例与测试/模型量化限制、触发误匹配、部分token保留、字符串转义、streaming和corner cases TODO；正文后半为社区讨论/变更引用。

## 后续行为与玩法启发

可选对话、诈骗说辞、证词草案可能受益结构化输出；原文未提供行为真实性、记忆、博弈、调查链或玩家玩法。

## 适用范围与局限

没有NPC或10000+成本证据；逐NPC推理的模型内存/KV cache/生成token和批量调度远超过简单C函数。

正文提到KV cache保存/复用只作TODO，不能据此主张规模可用。

多格式解析、模板/模型/量化/触发规则带显著版本维护成本；一个固定输出契约优于无条件引入八格式。

测试涵盖真实模型/none/parallel/required但部分慢测默认跳过；本轮只读讨论未审阅diff或运行。

schema合规不意味着工具选择正确、资源足够、ID存在或权限适当；结构化犯罪动作仍须物理与执行约束。

触发误匹配、early termination、字符串转义/模式支持不全、模型只思考不调用在原文有明确TODO；网页加载错误夹杂不使有效正文失效。

全文31966字符PR讨论载体，含有效说明与评论，不等于PR源码全文、已合入现状或全部测试证据。

不联网/不执行文中build指令；评审不做当前模型推荐。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [f620cd5edbd069f0d1b53f5c.txt](../texts/17/17981efc8779dc685810ebd06538cc52307e6ded91ea60c109b069cf93205958.md) | 讨论正文/已载入评论 | [0, 16000)、[16000, 31966) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/09-offline-symbolic-action-constraints.md](../../ai-reference/12-community-2016-2026/09-learning-generative/09-offline-symbolic-action-constraints.md)
- [https://github.com/ggml-org/llama.cpp/pull/9639](https://github.com/ggml-org/llama.cpp/pull/9639)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
