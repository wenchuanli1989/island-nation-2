# vllm max length breaking structured generation #1173

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/dottxt-ai/outlines/issues/1173`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：just-cameron（原问题报告者）。
- 原目录日期：2024-09-25（沿用已有记录）。
- 主要来源：[https://github.com/dottxt-ai/outlines/issues/1173](https://github.com/dottxt-ai/outlines/issues/1173)

## 概要与项目参考

Domino建议：若未来LLM离线生成模板或少量交互提出symbolic候选，必须检查完成原因、完整语法/模式和当前世界可行性，只有统一执行者验证后可提交效果。
这是一条集成故障反例，直接提醒接口预算单位/默认值应明确，当前有限C模板没有必要引入生成栈。

## 已有机制分析

源事实：作者使用Outlines JSON schema生成，输出在people/name中途停止并引发JSONDecodeError；量化Phi模型max_model_len=1024不决定输出token预算。
源事实：维护者检查response stop reason为length，SamplingParams.max_tokens=16；调用层max_tokens=None没有覆盖vLLM integration现有sampling_params，因此上层默认与后端默认不一致。报告者确认显式处理预算后问题修复。

## 后续行为与玩法启发

source_fact:
正文只做人名地址电话抽取，没有NPC或犯罪。

domino_recommendation:
未来自动写出的诈骗对白/证词只能是内容提议，不据部分JSON写世界事实；实际行为仍核验资源、主体和权限。

NPC生成谈判、骗局、调查建议可能产生截断行动参数；不接受半个JSON修补为真实交易/盗窃。可保留草案失败及重新选择，话语和世界效果分开。

## 适用范围与局限

source_claim:
没有吞吐或NPC规模数据。

domino_assessment:
vLLM模型上下文/推理成本远超当前C有限状态；不因structured output便适合10000 NPC逐次规划，最多离线内容生产。

提高max_tokens能防部分截断却增加每次推理延迟/缓存与成本；不能把10000NPC逐轮大输出作为免费扩展。文中只有一次小数据抽取，无并发或万人成本。

复现依赖大量Python/GPU包与固定旧版本；issue无可见根因回复或修复PR，Closed只是状态。

API adapter要在入口记录实际后端预算、stop reason与版本，模式校验不是生成必成功保证；预算只限候选生成，不能与现实毫秒业务截止期混淆。

无需复制帖子200多项环境依赖清单；固定少数依赖与失败可观察性比依赖数量有价值。

受限解码尚未闭合对象却因长度停止。

解析成功也不证明地址来自输入或领域行动可执行。

默认值补齐截断指令会形成未获授权行动。

schema约束仅约束允许token路径，长度停止仍可能输出不闭合结构；JSON有效也不证明内容真实或参数可执行。

issue Closed不是可见patch/当前版本已全面修复证明，末段讨论仍解释None没有覆盖integration默认。

报告输出名字Emily与输入Ada不匹配，文章聚焦截断，不提供抽取事实准确性保证。

完整本地issue页面文字；仅原报告可见，不包含根因分析或修复确认。

历史版本bug不作为当前Outlines/vLLM行为结论；未运行示例。

完整读修复后的冻结issue正文、trace和可见评论；未核读外链integration源码、执行复现或验证当前库状态。

范围很窄，可作为生成结果失败边界关联证据，不独立优先于当前生命周期/玩法机制资料。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [13e66b92a1a69ec0d49da3fd.repaired.txt](../texts/d6/d6c391f7106cbc8e160b30a731f547d4653d1403702ddf2d425ed8bdbd99731e.md) | 讨论正文/已载入评论 | [0, 11500)、[11500, 12373) |
| [13e66b92a1a69ec0d49da3fd.txt](../texts/df/df7446cb3b54d542a7e6c87429270502873f01693f6dea7a0f47612219424827.md) | 讨论正文/已载入评论 | [0, 9998) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/09-offline-symbolic-action-constraints.md](../../ai-reference/12-community-2016-2026/09-learning-generative/09-offline-symbolic-action-constraints.md)
- [https://github.com/dottxt-ai/outlines/issues/1173](https://github.com/dottxt-ai/outlines/issues/1173)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
