# Multi-agent Reinforcement Learning in Sequential Social Dilemmas

- 分类：机器学习、强化学习与适应性。
- 资料标识：`arxiv:1702.03037`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Joel Z. Leibo; Vinicius Zambaldi; Marc Lanctot; Janusz Marecki; Thore Graepel。
- 原目录日期：2021-05-15（沿用已有记录）。
- 主要来源：[https://arxiv.org/abs/1702.03037](https://arxiv.org/abs/1702.03037)

## 概要与项目参考

domino_recommendation: 合作/破约/偷窃从可执行任务序列产生：到场、等待、行动、真实资源竞争及收益分配，不能先定一个合作 bool 再直接结算。有限近期模板足以表达不同合作实现。
domino_recommendation: 需求/风险/承诺选择使用可解释规则；以资源丰度、伙伴可信度、协调时间和实际成本作玩法参数。可离线小场景比较行为率和世界效果，但不要求每 NPC 在线 DQN。

## 已有机制分析

source_fact: SSD 将合作/背叛定义为时间延展 policy，而非一个原子 C/D 按钮；同一囚徒困境收益矩阵可掩盖不同空间协调和实现学习成本。ΠC/ΠD 以行为度量阈值分组，未覆盖全部策略。
source_fact: Gathering 收苹果才得分，beam 标记对手两次使其暂离，无攻击直接奖励；改变苹果重生与被击中退出步数，40M steps 训练后稀缺/长移除期更易产生攻击。此 conflict-cost 是被移除后损失机会，并非司法惩罚。
source_fact: Wolfpack 用实际捕获时 capture radius 内伙伴人数给 group reward；出现一起找猎物或找到猎物后等伙伴两种合作实现。增大半径/组收益更合作。
source_fact: 独立 DQN 把其他学习者当非平稳环境，局部 RGB 观察、8 动作、1000 step episode、replay 限量更新。更大 network 在 Gathering 增背叛、Wolfpack 减背叛，作者归因于不同策略的协调/动作实现难度。

## 后续行为与玩法启发

crime:
稀缺可使排挤/抢夺具有工具性收益；动作可物理成立仍有主观风险和制度后果，不能用 morality 候选硬过滤消除冲突。

deception_investigation:
把行为观察、攻击实际效果和后来机构裁决分开；论文没有欺骗、证词或归因模型，不能从 learned aggression 推出这些能力。

cooperation:
多人狩猎、搬运、护送可先结伴或等人到场；拒绝/迟到/取消须改变真实任务结果，贡献和附近站位需分开。

player_interaction:
玩家调资源补给、集团奖金、路线/集合成本可改变竞争与合作；需可见证据与可干预行为链，不能仅奖励函数变更。

## 适用范围与局限

实验主要两名学习者，Wolfpack 加猎物；不存在万级 NPC 验证。

每 NPC 100k 以上 replay 与独立模型、40M 训练步不符合当前单机万级预算；原论文不是 C23 事件驱动执行器方案。

应只在局部伙伴/设施做稀疏竞争；全员互配、全体重复模拟 payoff 矩阵会膨胀。

保持收益、合作度量和实际行为独立观测；同 payoff 不代表同实现或同维护成本。

论文描述性实验不是承诺真实社会心理规律；network size 的 cognitive capacity 是解释映射。

采用可追踪模板/分配规则可保留冲突机制，省去在线学习非平稳性与调参成本。

“更聪明就更合作”不成立：网络规模在两种环境作用相反。

单纯互助奖励可能给未贡献但恰在半径内的 NPC 奖励；Domino 要明确贡献/合同/领取状态。

高 γ 可更重视消灭对手后的未来垄断收益，不保证长期主义稳定合作。

只看总 reward 将 missed arrival、目标争抢和 coordination 失败压成同一个 C/D 结果。

已全读提取的论文正文/参考文献；公式版式和图表文本提取可能失真，未核看 PDF 图片，未复现实验。

相关演讲/演示视频是同作品关联载体，不能算新的独立作品；本项未观看。

论文不提供参与者生命周期、存档、司法调查或万级调度实现。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [84000d5fdb0bdd3bb4c8471b.txt](../texts/98/989f0b9e41d0751162a5d306e99d891b1ab91722a41f98ee22b267809645d53f.md) | 论文/讲义提取文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 47699) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/05-organizations-institutions/06-cooperation-collective-action.md](../../ai-reference/13-youtube-2011-2026/05-organizations-institutions/06-cooperation-collective-action.md)
- [https://arxiv.org/abs/1702.03037](https://arxiv.org/abs/1702.03037)
- [https://arxiv.org/pdf/1702.03037](https://arxiv.org/pdf/1702.03037)
- [https://deepmind.google/blog/understanding-agent-cooperation/](https://deepmind.google/blog/understanding-agent-cooperation/)
- [https://www.youtube.com/watch?v=brvXEaoA9dI](https://www.youtube.com/watch?v=brvXEaoA9dI)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
