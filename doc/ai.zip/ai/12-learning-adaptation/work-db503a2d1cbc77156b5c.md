# Contest run provenance: making model drift detectable with per-run output fingerprinting · Issue #271 · google-deepmind/concordia · GitHub

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:eb2718305ec517627bc8ee921a387a182fcb0dbf029a457a908fda3306c50911`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：topeuph-ai（外部提案者，关联复现工具作者）。
- 原目录日期：2026-05-17（沿用已有记录）。
- 主要来源：[https://github.com/google-deepmind/concordia/issues/271](https://github.com/google-deepmind/concordia/issues/271)

## 概要与项目参考

闭合本地残差文字阅读/来源定位；不重复统计既有独立作品。

## 适用范围与局限

本补片不单独提供万级NPC性能证据。

全文对照paired：Merkle per-scenario/agent指纹、content/bundle区分和所有提问均已有，只是Markdown格式和链接差异；不能新增算同一提议。

不能把标题、摘要、链接、提议或社区报告提升为原作品完整机制/代码/运行证明。

语义对照确认核心段落已在旧paired正文；标记/链接格式差异不能创造新正文缺口。

已读完整所分配残差；未读的全篇/外链/图像/附件仍保持缺口，原paired载体其他读者覆盖须由根汇总。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [72140f2e8808a8fd2202f882.txt](../texts/8a/8a2aa28def2b246a80018f90d58c373fb60baf1d8f765f7e2bc52083e32c863d.md) | 文章/文档正文 | [0, 2611) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/08-concordia-adjudication.md](../../ai-reference/12-community-2016-2026/09-learning-generative/08-concordia-adjudication.md)
- [https://github.com/google-deepmind/concordia/issues/271](https://github.com/google-deepmind/concordia/issues/271)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
