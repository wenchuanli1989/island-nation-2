# Variational Offline Multi-agent Skill Discovery（论文页摘要）

- 分类：机器学习、强化学习与适应性。
- 资料标识：`identity-limited-unit:2514a9c24ebab6178481cf19db4b9e212f217ced2e0bbdc4d6af8deea73cd665`。
- 已有内容：已有摘要/简介文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Jiayu Chen; Tian Lan; Vaneet Aggarwal。
- 原目录日期：2025（沿用已有记录）。
- 主要来源：[https://ijcai.org/proceedings/2025/538](https://ijcai.org/proceedings/2025/538)

## 概要与项目参考

Domino建议：少量可复用共同活动模板和必要角色是可借思路；不因摘要引入MARL训练或组织直接控制个人。

## 已有机制分析

源摘要事实：提出VO-MASD-3D/Hier autoencoder，dynamic grouping识别潜在子组，同时提取时间/群体skill，可用offline multitask数据迁移。
作者主张：StarCraft性能优于已有hierarchical MARL、稀疏奖励学习更易；本页无算法、组函数、规模或数值。

## 后续行为与玩法启发

可探索协同偷窃/伏击/议价的小组任务，但摘要未说明个人拒绝、取消与共同资源提交。

## 适用范围与局限

只有StarCraft宣称，无agent数量/推理预算/训练数据和10,000NPC证据。

学习skill须可解释前提、角色、生命周期与效果合同；这些接口未见正文，不可由摘要自动补齐。

latent subgroup统计模式不代表成员真实同意或必要角色就绪；离线技能跨任务迁移不能保证当前资源合法可用。

完整1827字符论文页面，仅摘要与metadata；未读PDF方法/实验，不能当完整论文正文。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [3cfb96f0439eb41ebdafcef1.txt](../texts/40/40c0360d520ff372fcfe67b6f106f2c423eefaeedf53a4ce217840ba289c6edb.md) | 摘要/简介 | [0, 1827) |

## 原研究概要与相关链接

- [09-frontier-papers/06-multi-agent-learning.md](../../ai-reference/09-frontier-papers/06-multi-agent-learning.md)
- [https://ijcai.org/proceedings/2025/538](https://ijcai.org/proceedings/2025/538)
- [https://www.ijcai.org/proceedings/2025/0538.pdf](https://www.ijcai.org/proceedings/2025/0538.pdf)
- [https://www.ijcai.org/proceedings/2025/538](https://www.ijcai.org/proceedings/2025/538)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
