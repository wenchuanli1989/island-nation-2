# Emergent Bartering Behaviour in Multi-Agent Reinforcement Learning

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://deepmind.google/blog/emergent-bartering-behaviour-in-multi-agent-reinforcement-learning/`。
- 已有内容：文章/文档正文。
- 原目录作者：Mike Johanson, Edward Hughes, Finbarr Timbers, Joel Leibo；DeepMind 研究者。
- 原目录日期：2022-05-16（沿用已有记录）。
- 主要来源：[https://deepmind.google/blog/emergent-bartering-behaviour-in-multi-agent-reinforcement-learning/](https://deepmind.google/blog/emergent-bartering-behaviour-in-multi-agent-reinforcement-learning/)

## 概要与项目参考

Domino建议：以少量技能、偏好、库存、可达资源和局部交易机会产生目标候选，让合作收益来自真实互补稀缺；无需在万人NPC运行期部署深度RL。
Domino建议：区分目标报价/预期套利、双方承诺、预约货物和实际交货/付款；最后一步核库存与双方条件后原子提交，移动与运输耗时用现实单位。

## 已有机制分析

官方2022研究介绍：Fruit Market中的代理在物理地图上采苹果/香蕉、找伙伴交易、消费；每人擅长生产一种而偏好另一种，创造互惠交换动机。
作者报告深度RL从经验学会生产、消费与交易，改变树出现概率改变供求；水果分区域生长时形成不同地区价格，一些代理学习跨区运输套利。
作者把此环境用于研究经济社交挑战；正文没有实际议价动作协议、奖励函数、网络架构或数量/时间基准。文末只说将随下一次Melting Pot发布，并非本轮核验已发布实现。

## 后续行为与玩法启发

Domino建议：贸易路线、协作分工、价格差、玩家供给干预可产生可观察经济故事；附近情报影响价格信念，不能全地图自动共享真实库存。

Domino建议：盗运、欺骗货物数量、劫路与合同争议可保留为行为选择；目击/证词、账簿调查、关系信誉与制度惩罚分层，不把非法路线物理删除。

## 适用范围与局限

正文没有代理数、训练成本或推理吞吐；价格分区与套利涌现不证明10,000+ NPC可实时运行，DRL训练/多代理交互尤其不能直接套用。

Domino建议：局部市场候选/有限库存订单与稀疏关系，批次更新行情摘要；避免全体两两议价O(N²)和每NPC保存全部市场历史。

稳定交易生命周期、物品单位、所有权/可用量与执行时间，将生产/消费模板和价格策略分离；扩展物品不必新增独立决策框架。

环境发布计划只保留历史主张；具体算法需要对应论文或代码证据，不用博客宣传代替实现。

在两个水果、互补技能偏好的设置中有收益，不意味着复杂信贷、产权、诈欺或制度会自然学习出来。

共享真实价格与资源会使NPC全知；目标套利乘预计价差入账会创造未发生财富。

RL奖励和世界资源守恒未在正文展开，不能推断无重复交易、抢占资源或学习不稳定问题。

完整实际读4816字符官方介绍；未读取链接论文、Fruit Market/Melting Pot源码或图像曲线。

经济合理/供求曲线/套利均为作者报告，正文缺实验数值及万人数据。

未联网核验2022后的发布或现状。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [4e366348ab9439718f59633e.txt](../texts/9f/9f38ef69dc78b2c38e63defadd098bacc6c56b23b3ea1f7cf7234e075434c499.md) | 文章/文档正文 | [0, 4816) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/03-social-learning-environments.md](../../ai-reference/12-community-2016-2026/09-learning-generative/03-social-learning-environments.md)
- [https://deepmind.google/blog/emergent-bartering-behaviour-in-multi-agent-reinforcement-learning/](https://deepmind.google/blog/emergent-bartering-behaviour-in-multi-agent-reinforcement-learning/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
