# PettingZoo PR #1071 — Permit AgentIDs other than str

- 分类：机器学习、强化学习与适应性。
- 资料标识：`saved-original-url:https://github.com/farama-foundation/pettingzoo/pull/1071`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：pimpale（提案与实现贡献者）；elliottower（配套 PR 评审与合并者）。
- 原目录日期：2023-08-19（沿用已有记录）。
- 主要来源：[https://github.com/Farama-Foundation/PettingZoo/pull/1071](https://github.com/Farama-Foundation/PettingZoo/pull/1071)

## 概要与项目参考

source_scope: Python多agent环境接口类型修改，非NPC行为规划。
domino_recommendation: 很窄的参考：实体ID类型、全体结果容器与单人物结果要在接口上明确分离，维持既有uint ID->index，不需为C引擎引入Python包装或旧兼容分支。

## 已有机制分析

source_fact: PR把AECEnv与ParallelEnv generic化为AgentID，不再强制str；测试复制会新增/终止agent的示例环境使用非字符串ID，评论建议以wrapper复用测试。
source_fact: Parallel返回按AgentID索引的多agent observation/reward/termination/info字典；AEC last只返回当前agent的一条info，info内部业务字段仍可字符串键，不能误嵌套为所有agent。
source_fact: 去掉ObsDict/ActionDict别名后Shimmy等外部项目受损；作者和维护者最终同意加回两行别名。Python泛型运行时错误通过future annotations规避。

## 后续行为与玩法启发

间接可支持调查/交易/协作参与者的稳定ID定位，但本篇没有犯罪、关系、协同执行或玩家干预机制。

## 适用范围与局限

未讨论10,000人运行时间；Python dict与wrapper只是接口，不证明稀疏调度。

Domino不应将每tick全体dict作为大量NPC消息协议，可传少量值快照/有界事件。

单人info与全体info错误是可读类型注解能捕获的具体合同歧义。

历史兼容修补是PettingZoo生态需求，Domino独立新项目不需要复制该兼容策略。

将业务info键当AgentID会导致类型错和错误路由。

CI过并不证明下游API无破坏，评论在合并后发现Shimmy错误。

15483字符讨论完整读取，但大多数inline diff加载失败，只见少量类型签名；不能冒称完整env代码审计。

来源map提案标题来自issue1070，载体为PR1071，按PR身份处理；无规模或强玩法核心机制。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [0a01b3fa7069cc64be170b8d.txt](../texts/51/51387a99f3063b6c832e4ce241ccfc0780ce3a3db0a45389d9fd1262bb7f8fb0.md) | 讨论正文/已载入评论 | [0, 11500)、[11500, 15483) |

## 原研究概要与相关链接

- [12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md](../../ai-reference/12-community-2016-2026/09-learning-generative/01-pettingzoo-environment.md)
- [https://github.com/Farama-Foundation/PettingZoo/issues/1070](https://github.com/Farama-Foundation/PettingZoo/issues/1070)
- [https://github.com/Farama-Foundation/PettingZoo/pull/1071](https://github.com/Farama-Foundation/PettingZoo/pull/1071)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
