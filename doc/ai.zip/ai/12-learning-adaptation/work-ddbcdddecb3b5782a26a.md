# Closing the Affective Loop via Experience-Driven Reinforcement Learning Designers

- 分类：机器学习、强化学习与适应性。
- 资料标识：`arxiv:2408.06346v1`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Matthew Barthet; Diogo Branco; Roberto Gallotta; Ahmed Khalifa; Georgios N. Yannakakis。
- 原目录日期：2024（沿用已有记录）。
- 主要来源：[https://arxiv.org/html/2408.06346v1](https://arxiv.org/html/2408.06346v1)

## 概要与项目参考

domino_recommendation: 可借生成器/可行性验证/体验评价分离用于离线设计活动模板或玩家导演试验；物理可行性与目标体验分数应是两个合同。
domino_recommendation: 导演只选择真实世界允许的事件机会，例如已有合同/冲突/巡逻配置；不能为满足紧张曲线伪造NPC犯罪、目击、资源消费和收益历史。

## 已有机制分析

source_fact: designer生成赛道，evaluator先判碰撞/回路可玩性，再用checkpoint驱动车生成状态轨迹，affect模型预测唤醒轨迹；reward为生成轨迹与目标轨迹间面积距离的负值。
source_fact: 29项game telemetry按3秒窗均值并min-max归一化；相邻窗arousal差用0.15阈值转ordinal increase/decrease/stable，训练KNN时丢stable，仅用加权近邻预测变化。
source_fact: 按score与arousal轨迹聚类为beginner/excited expert/unexcited expert；Go-Explore每次回放archive cell再扩展一个赛道块，以块数量、类型数量、Dijkstra补路径长压缩cell，轨迹最多10件。
source_fact: 遗传baseline为10parent/50offspring、50代、10runs，Dijkstra用基础块闭合环路；比较的是模拟代理+模型预测的binary arousal方向一致率。

## 后续行为与玩法启发

在未来玩家模型方向，可比较追逐/调查/交易任务的体验变化，把玩家反馈加入候选内容评估。

违法动作是否可执行由领域事实约束，是否引发紧张由玩家模型评估；制度许可不能代替物理可行性过滤。

## 适用范围与局限

搜索包含多个完整race simulations、archive回放及KNN近邻查询；未给CPU墙钟吞吐或10000NPC性能，不能逐NPC在线训练。

原文only one evaluation per track因场景相对确定；多人竞争和随机犯罪响应需多次模拟，评价成本进一步增大。

reward、cluster特征、feasibility与evaluator可分模块更换，但新领域需成套采样/标注、代理行为校准和内容表示。

低维cell压缩控制archive增长，同时可能把体验不同布局合并；需保留代表轨迹与评价来源供解释。

evaluator一直加速且忽略对手，常产生真人会避开的碰撞；它更像初学者，专家cluster预测会偏。

训练数据只一个旧赛道；生成新赛道尚未human study验证，模型一致率不能当真实玩家体验命中率。

仅arousal变化无valence/满意度，不证明高唤醒内容好玩或负体验不伤害玩法；目标分布之外难以诱发未展示过的模式。

论文称未来robustification可在线运行，当前结果不是在线闭环已验证。

完整读本地51911字符论文HTML抽取；图注已读，图像未核看，公式抽取有双重LaTeX/Unicode重复。

对Domino近期human生命周期是间接导演研究，未提供犯罪/组织事实模型或执行/存档机制。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [4d1310fc749bb5df368ee8b4.txt](../texts/66/66d8533b3a7ac14dde15126bac3ff2a625075453bcff183f5aed1d0ec7f6f9c8.md) | 论文/讲义提取文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 46000)、[46000, 51911) |

## 原研究概要与相关链接

- [10-learning-resources-methods/09-player-modeling-directors.md](../../ai-reference/10-learning-resources-methods/09-player-modeling-directors.md)
- [https://arxiv.org/abs/2408.06346](https://arxiv.org/abs/2408.06346)
- [https://arxiv.org/html/2408.06346v1](https://arxiv.org/html/2408.06346v1)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
