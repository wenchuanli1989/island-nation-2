# [patch V2 15/17] timers: Provide timer_shutdown[_sync]() — Thomas Gleixner, 2022-11-22

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`identity-limited-unit:149d7b258450a2862e7b092aa0c3d477079f479a8615756e04ad7bb5bb66f002`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Thomas Gleixner，Linux 时间子系统维护者；Steven Rostedt共同开发；Anna-Maria Behnsen参与评审。
- 原目录日期：2022-11-22（沿用已有记录）。
- 主要来源：[https://patchew.org/linux/20221122171312.191765396@linutronix.de/20221122173648.962476045@linutronix.de/](https://patchew.org/linux/20221122171312.191765396@linutronix.de/20221122173648.962476045@linutronix.de/)

## 概要与项目参考

Domino future executor终结时先禁止新续期/重挂，再停止/确认正在执行段、清空或拒绝旧事件，最后释放占用与对象；此与业务取消请求不同。
现timer只是通知而非内核callback，已出队通知要用业务ID/revision核验；不能从cancel成功推导消费者不再使用目标。
生命周期需要明确“可恢复挂起”与“永久终结不可重挂”；C状态字段/owned queue即可，不移植kernel timer API。

## 已有机制分析

timer/workqueue circular dependency：timer可queue work，work可rearm timer；delete_sync只删除/等callback，不保证不会重新arm。
shutdown将timer.function置NULL，arming函数silently discard rearm；非sync版本不等待其他CPU callback。
shutdown_sync返回三保证：未queued、callback不running、不能再enqueue；顺序shutdown_sync(timer)再destroy workqueue，才可free owner。

## 后续行为与玩法启发

玩家打断工作、同伙拒绝、嫌犯离开导致任务终结时，迟到timer或异步行为续期不能复活旧任务/再次扣资源。

犯罪调查的长期挂起仍允许未来恢复，因此不可套用永久shutdown；人物死亡/实体销毁是终结边界。

## 适用范围与局限

禁止重挂切断取消残留和循环排队，总体减少无用事件；该patch无10000计时器/NPC benchmark。

sync wait可能阻塞/死锁，必须遵守锁/context规则；非sync不构成安全回收确认。

patch直接声明同步前提和free顺序；可借清晰契约而不增加通用租约/事务框架。

业务层更适合明确拒绝续期返回码和debug因果；原kernel silent discard是特定teardown选择。

delete_sync与并发rearm同时存在时返回值意义丢失；pending=0不说明将来无callback。

sync关闭后若余下shutdown流程还依赖该timer，原顺序不可用。

拿non-sync shutdown返回当callback停止确认会造成use-after-free；当前Domino队列通知与callback模型不同。

完整mbox patch [0,8656)已读，quoted-printable换行含噪声；非完整patch series/current Linux实现审计。

不复制Linux原生线程/时钟API；迁移建议须适配Domino通知consumer模型。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [2d321edea023b9d4ca35681e.txt](../texts/cb/cb2bceefae7642f2f26730b225404567633d7751dbd72783483ab9d10559cd0a.md) | 文章/文档正文 | [0, 8656) |

## 原研究概要与相关链接

- [12-community-2016-2026/07-performance-scheduling/05-event-heaps-wheels-cancellation.md](../../ai-reference/12-community-2016-2026/07-performance-scheduling/05-event-heaps-wheels-cancellation.md)
- [https://patchew.org/linux/20221122171312.191765396@linutronix.de/20221122173648.962476045@linutronix.de/](https://patchew.org/linux/20221122171312.191765396@linutronix.de/20221122173648.962476045@linutronix.de/)
- [https://patchew.org/linux/20221122173648.962476045@linutronix.de/mbox](https://patchew.org/linux/20221122173648.962476045@linutronix.de/mbox)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
