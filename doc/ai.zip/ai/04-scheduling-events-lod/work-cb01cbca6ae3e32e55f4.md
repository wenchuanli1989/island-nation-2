# SimPy src/simpy/resources/base.py at f43816490c6f76f336ad6e457d3cab9f386894af

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`identity-limited-unit:adc5ec55202175882388450943b4333376c86517d744a4fdc2c631b73d0b6bc3`。
- 已有内容：源码/工程文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 主要来源：[https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py](https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py)

## 概要与项目参考

Domino 建议：共享服务/座位/库存/工作场地以 request_id、等待队列和条件提交协调，资源变化唤醒候选；获取请求取消与实际占用释放分开。普通 C 有界 waiter 记录和类型 ops 即可提炼，无需整体 SimPy 运行器。

## 已有机制分析

源码：Put/Get request 自身是 Event，登记 active_process，入资源 pending queue；建立对向队列唤醒 callback，并立即尝试本向请求。
源码：BaseResource 允许领域子类替换 request 类型/队列及 _do_put/_do_get；只有条件真实满足并 Event.succeed 后，从 pending queue 移除，保持队列只含未触发请求的不变量。
源码：request context manager 在退出/异常时调用 cancel，只移除未 triggered 的请求；已经触发请求不会由 cancel 自动反转，处理与已取得资源释放是不同阶段。
源码：_trigger 循环按子类返回值可提前停止，避免不必要全扫描；检查 pop(idx) 仍是当前 event，暴露队列不变量破坏。

## 后续行为与玩法启发

建议：排队购买、合作工具占用、医院容量、玩家拒绝服务/抢走资源会导致等待或失败；盗取可走真实资产提交而有不同合法性后果。

建议：参与者拒绝可移除 pending request，但已交付物品或已进场活动要显式业务终结/归还。

## 适用范围与局限

没有万人基准；默认 list 的 remove/pop(idx) 需移动队列元素，集中排队可 O(Q)；每个触发还可能试多条 request。

资源 callback 驱动优于每 NPC 每帧轮询全部容量，但须合并事件并限制热点资源队列工作预算。

SimPy 此模块是单环境事件语义，未给 C23 多线程共享资源安全实现。

统一 request/event 与领域 _do ops 分离有利增加不同容量资源；capacity 的实际校验在子类，不由 BaseResource 属性自动保证。

建议保存业务 waiting/acquired/released 状态与资源/任务 ID，运行 callback/Process 指针加载后重建。

triggered 后 cancel 不归还已取得资源；若把 cancel=release 会丢占用或返还两次。

pending cancel 移除后仍无 cancelled flag；再次 cancel 或 context manager 后重复取消可尝试 remove 不在队列的请求，不能直接假定幂等。

子类若不触发 event 却修改资源，或返回值与公平性规则不符，会造成丢唤醒/阻塞；父类抽象不能保证业务正确。

完整读 repaired 文本载体，SHA 与 batch一致；未另看 raw 前身或子类 Resource/Store/Container。

仅此源码的接口/队列机制，未审计 SimPy 整体 scheduler、Event.succeed callback 顺序或运行性能。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [82d3ff96d0d0c3f26d4ea7f0.repaired.txt](../texts/91/915e6b66e26e573fdd7740a876eeae224284e09ad43d5bece67eec78092c22b0.md) | 源码/工程文本 | [0, 9730) |

## 原研究概要与相关链接

- [11-open-source-projects/09-event-scheduling/simpy.md](../../ai-reference/11-open-source-projects/09-event-scheduling/simpy.md)
- [https://gitlab.com/api/v4/projects/team-simpy%2Fsimpy/repository/commits/f43816490c6f76f336ad6e457d3cab9f386894af](https://gitlab.com/api/v4/projects/team-simpy%2Fsimpy/repository/commits/f43816490c6f76f336ad6e457d3cab9f386894af)
- [https://gitlab.com/team-simpy/simpy](https://gitlab.com/team-simpy/simpy)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/LICENSE.rst](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/LICENSE.rst)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/core.py#L165-212](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/core.py#L165-212)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py#L274-311](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py#L274-311)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py#L217-240](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py#L217-240)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/resource.py#L168-224](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/resource.py#L168-224)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/rt.py#L60-91](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/rt.py#L60-91)
- [https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py](https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
