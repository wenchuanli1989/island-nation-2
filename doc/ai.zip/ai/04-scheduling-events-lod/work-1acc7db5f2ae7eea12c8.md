# System scheduling

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://github.com/bevyengine/bevy/discussions/2747`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：davidscherer（自述新用户，提案作者）；alice-i-cecile、Ratysz 等 Bevy 贡献者参与讨论。
- 原目录日期：2021-08-30（沿用已有记录）。
- 主要来源：[https://github.com/bevyengine/bevy/discussions/2747](https://github.com/bevyengine/bevy/discussions/2747)

## 概要与项目参考

Domino建议：物理/人物/组织阶段建立明确读写发布点，业务写入顺序可追踪；同阶段独立批次才并行。
目前单写入者+只读规划优先，不因Bevy讨论迁移ECS或建通用soft dependency求解器。

## 已有机制分析

原文提议：区分严格after与as_if_after，前者禁止时间重叠，后者只保证冲突数据像按序执行；可交换系统集合显式声明。
原文讨论：跨插件label公开交错点；锁定调度顺序/置换歧义系统辅助复现；类型访问并非总能代表真实数据依赖，内部可变性与事件通道是反例。
原文末段：soft-edge直接删除非冲突边会丢A→B→C传递依赖，需闭包或等价算法；闭包可能O(S²)，数据冲突检查还要bitset相交。

## 后续行为与玩法启发

付款、资产转移、犯罪动作、目击事件和制度反应的发布顺序决定可观察因果；确定接口可使玩家干预可复现。

原文是调度设计，没有犯罪领域或NPC游戏体验证明。

## 适用范围与局限

S是system数，讨论的O(S²)不是NPC数；每NPC独立system会放大成本。

作者提议分块流水线可改善cache/降低join尾部浪费，维护者主张先重系统内部par_for_each，均无benchmark。

Domino可分批独立人物计算，但共享服务竞争及跨批知识更新要明确发布，不能当作天然可交换。

可视化依赖图、说明读写与阶段含义比重复维护大串标签更易查错。

线程排程、随机种子、世界快照不同；复制外部资源检查可交换性有实际限制。

默认歧义可随硬件/插件组合产生难复现错误；过度全串行又浪费并行。

运行中archetypes变化可使昨日不冲突今日冲突；社区末段澄清当时scheduler是archetype-aware，前面维护者误解得到修正。

类型别名/通道隐藏读写、跨插件遗漏label、as_if的传递闭包缺失都破坏串行等价；不能只看函数签名证明安全。

完整阅读本地2021帖子/回帖快照，页面包含GitHub壳错误字样但主体有效；不是2026 Bevy API或合并实现证据。

提议与维护者评议不是运行验证，本轮未执行或联网。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [31885e731e44a8a9e8675bfc.txt](../texts/9c/9c69c52f81eb83eedb5955902a8e92f1743b80ec1212c568a4914b8f67a7b75a.md) | 讨论正文/已载入评论 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 41638) |

## 原研究概要与相关链接

- [12-community-2016-2026/07-performance-scheduling/03-bevy-scheduling-deferred.md](../../ai-reference/12-community-2016-2026/07-performance-scheduling/03-bevy-scheduling-deferred.md)
- [https://github.com/bevyengine/bevy/discussions/2747](https://github.com/bevyengine/bevy/discussions/2747)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
