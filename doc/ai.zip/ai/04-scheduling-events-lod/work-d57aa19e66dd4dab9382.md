# Discrete-event simulation in Python — Rémi Varloot, LINCS, 7 March 2025

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://www.lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Rémi Varloot / Nokia Bell Labs。
- 原目录日期：2025-03-07（沿用已有记录）。
- 主要来源：[https://www.lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf](https://www.lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf)

## 概要与项目参考

Domino 建议：普通C存任务阶段/子行动结果/等待对象ID，用定时或外部事件恢复，不每帧遍历所有NPC；共享ops与实例进度分开。
Domino 建议：到期事件携带实例ID/修订，仅负责唤醒；执行者重新检查占用/资源和子步骤结果，再提交真实效果，不能按计划模拟时间跳跃结算收益。
Domino 建议：本作generator是程序计数器思想的说明，不导入Python生成器；可序列化C实例字段才能存档恢复。

## 已有机制分析

源事实：优先队列条目(when,counter,what)按到期和递增counter排同刻事件；原子事件可安排未来事件，主循环弹出并推进模拟时间。
源事实：PendingResponse让调用方注册完成回调，GeneratorHandler把返回响应的yield挂起点与send结果恢复相连；StopIteration.value成为父响应结果。wait由no_op_generator到期解决。
源事实：周期loop装饰器完成一次调用后再schedule(time+every)，测量采样与运动事件可用不同节奏；未来Join等待全部、Race等待首个，作者建议resolved时安排now而非直接wake。

## 后续行为与玩法启发

协作：邀约等待参与者回应可像PendingResponse，Join聚合多方准备，Race处理回应或期限先到；拒绝、逾时、取消及已启动协作不同分支。

调查/欺骗/交易：等待证人、结果、交付/付款与超时可共用等待协议，但真实性和资产效果另由领域执行器记录；玩家阻路/拒绝参与可唤醒重选。

## 适用范围与局限

优先队列调度约O(logE)每事件，事件数E应随活跃任务而非每帧N扩张；本文N=10下载peer演示没有万级基准。

大量同时到期、递归wake回调与Race未释放输家会制造突发/残留；应合并同对象通知、队列化ready并设批次预算。

同刻counter提供稳定顺序利于复现；运行时间需_ms等单位以及冻结共基准。

单回调PendingResponse、异常、重复解决、订阅前已解决、取消均未完整实现；当前C协议需明确而非照搬演示。

reset在stop边界清空所有事件，适合实验不等同保存/续跑，持久化不能沿用。

Race(timeout,generator)只说明首个完成，不代表迟到方动作已经停止；必须停止确认和占用释放。

仿真time直接跳到t不能迁入Domino累计未冻结现实时间来产生离线收益。

闭包/generator隐式状态难序列化，恢复后可能重复实际效果，必须显式阶段和已提交进度。

完整读取本地PDF文字提取，部分长代码行在归档中被截短，缩进/公式和图像未核验；不等同观看映射视频。

取消、释放、持久化、重复通知与异常方案只是Domino建议，不能表述为源代码现有能力。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [d6da5ec262a19ef8065fc8e9.txt](../texts/44/44ad6bf4f873b0ba73b81f9a1c2b36338f2db72e0cd8712e9e6821e0df92396d.md) | 论文/讲义提取文本 | [0, 10014) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/07-performance-scheduling/06-discrete-events-timers.md](../../ai-reference/13-youtube-2011-2026/07-performance-scheduling/06-discrete-events-timers.md)
- [https://lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf](https://lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf)
- [https://www.lincs.fr/events/python-tricks-for-discrete-event-simulation/](https://www.lincs.fr/events/python-tricks-for-discrete-event-simulation/)
- [https://www.lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf](https://www.lincs.fr/wp-content/uploads/2025/03/discrete-event-simulation.pdf)
- [https://www.youtube.com/watch?v=Fd9EazfKNvU](https://www.youtube.com/watch?v=Fd9EazfKNvU)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
