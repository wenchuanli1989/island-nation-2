# uv_timer_t — Timer handle

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://docs.libuv.org/en/v1.x/timer.html`。
- 已有内容：文章/文档正文。
- 主要来源：[https://docs.libuv.org/en/v1.x/timer.html](https://docs.libuv.org/en/v1.x/timer.html)

## 概要与项目参考

Domino 推论：timer通知与任务实际推进分开，迟到时按有效elapsed_ms计算进度，而非按回调次数发收益。文中libuv stop语义不能覆盖本项目cancelled_flag、已入队通知和消费身份检查合同。

## 已有机制分析

源事实：定时器可单次或重复；重复按event loop当前now重装，不补偿回调开销。50ms间隔/17ms回调示例下一次约33ms后，其他工作拖延则尽快触发。
源事实：start的timeout/repeat以毫秒计，timeout=0在下一循环迭代触发；活动timer可被start重设，start本身不更新loop的now。
源事实：stop取消libuv此handle后续回调；again用repeat且未start会失败；回调里set_repeat不会改变已经按旧repeat安排的下一次。get_due_in返回相对loop now的剩余时间，到期0。

## 后续行为与玩法启发

错过服务窗口、到期债务与追逐截止点可用现实ms表达；实际动作未执行时不能因timer到期视为成功。此手册本身没有犯罪玩法。

## 适用范围与局限

无10000timer/NPC性能数据。大量同周期timer可能形成唤醒突发；需要有限活动timer和事件队列预算，不为每个需求每帧重复注册。

区分已安排deadline、当前repeat、loop now和业务累计未冻结ms；更改业务timer按当前项目cancel后schedule。不要跨库假设停止等同资源静止。

回调开始时更改repeat不立即改变下一次触发，依赖立即变化会产生一轮误差。

到期剩余0不代表回调已执行，loop晚到不会自动补齐业务效果。

libuv是API参考，不是项目C23 timer实现或多线程取消安全证明。

完整2559 raw字符API文档；未运行libuv或项目timer。

基础参考证据清楚，但没有新增完整NPC机制或万级测量。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [b887eb00ddf1cfeb5f66a9ab.txt](../texts/c4/c4abdd96c6fdee279b801b1ad8ffb3884541f1455393b6ef59316b3268279798.md) | 文章/文档正文 | [0, 2559) |

## 原研究概要与相关链接

- [https://docs.libuv.org/en/v1.x/timer.html](https://docs.libuv.org/en/v1.x/timer.html)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
