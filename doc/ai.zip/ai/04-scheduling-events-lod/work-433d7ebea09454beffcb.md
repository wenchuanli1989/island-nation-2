# C++ Concurrent Queues — P0260R1 (2017-02-05)

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html`。
- 已有内容：文章/文档正文。
- 原目录作者：Lawrence Crowl; Chris Mysen。
- 原目录日期：2017-10-15（沿用已有记录）。
- 主要来源：[https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html)

## 概要与项目参考

任务事件调度、背压、停机排空边界直接相关；提供语言无关契约而非C23实现或当前仓库行为证明。

## 已有机制分析









## 后续行为与玩法启发

source_facts:
没有玩法模型。

domino_suggestions:
调查报告、协作响应、付款请求和取消通知经队列时须区分已接收与真实效果完成。

高峰犯罪/交易事件可延后与合并，但不能丢弃决定资产或责任的必要结果。

## 适用范围与局限

固定容量buffer限制队列内存，但集中到期/全NPC事件仍需事件合并与分批策略。

锁/无锁、空载/争用成本是独立权衡，文中无万级NPC基准或确定性调度证明。

不能让每NPC持有复杂引用端或每事件重型动态分配，建议小按值消息+ID/revision。

制定empty/full/stopped与push失败所有权规则，禁止队列引用逃逸。

原文实际R1，映射标题R2且同作品urls含R1/R2；不宣称已读R2差异。

草案概念段wait_pop有empty返回文字，而后正式effects明确等待；实现契约须自行消歧。

只设stop但不唤醒condition variable会让空/满阻塞线程永久等待。

is_empty检查与下一步销毁间生产者还可能push，形成竞态。

并发push_front不恢复原顺序，不能undo已经传播的经济效果。

try_push仍可能因mutex阻塞；lock-free不自动意味着业务顺序正确。

元素复制/析构锁内重入队列会死锁。

完整本地45645字符R1正文及修订历史已读；未读本任务以外R2载体、未查现行标准或执行实现。

本文为2017提案，不能作为当前C++标准已采纳能力，更不是C23队列API。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [207b38f4ea36845051ec3307.txt](../texts/d2/d2aedc16a3c4de41273c7b84a27ae854f8d59238b7fa9d929063af38441d6c4a.md) | 文章/文档正文 | [0, 45645) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/08-concurrency-reliability/01-queue-backpressure-shutdown.md](../../ai-reference/13-youtube-2011-2026/08-concurrency-reliability/01-queue-backpressure-shutdown.md)
- [https://open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html](https://open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html)
- [https://wg21.link/p0260r2](https://wg21.link/p0260r2)
- [https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r1.html)
- [https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r2.html](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2017/p0260r2.html)
- [https://www.youtube.com/watch?v=jozHW_B3D4U](https://www.youtube.com/watch?v=jozHW_B3D4U)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
