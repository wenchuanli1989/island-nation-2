# Advanced AI for Games: Influence Maps

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps/`。
- 已有内容：文章/文档正文。
- 原目录作者：Adam Clarke。
- 原目录日期：2021-04-01（沿用已有记录）。
- 主要来源：[https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps](https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps)

## 概要与项目参考

Domino建议：共享只读局部机会/风险图可辅助少量目标候选，写/发布/读阶段应明确，避免当前借用数组或半清空图跨线程读。
Domino建议：图中的高值点只是预计机会，真实路线与容量/物品/动作成功需另检查；现有Floyd权重不等于距离/ETA。

## 已有机制分析

原文个人实现：共享二维影响网格按阵营/威胁/声音分层，人物截取局部working map加减组合，再选择最高值位置；移除某阵营图可表示改变敌我考虑。
原文个人实现：预先为半径/衰减函数算stamp，运行时涂入共享图，避免每格距离sqrt；manager按清图->全员写->读阶段调度，think周期200ms。
原文个人实现：局部最大值线性扫描从随机起点开始，减少等值时总偏一个方向；Dave Mark的de-stamping优化作者明确尚未实现。

## 后续行为与玩法启发

Domino建议：逃逸避开巡逻、调查沿声音/目击线索、选择安全会面/交易地点，玩家改变路线或盟友关系可改变局部候选。

个人信念图应只反映其观察/传言，不从客观世界图直接给全知；欺骗可更改可信来源而不是改变真实巡逻位置。

## 适用范围与局限

原文无NPC数/FPS实测；每frame全清共享grid+全员stamp写仍昂贵，working map采样和最大值每人物按局部面积扫描。

Domino建议：只为热点区域/活跃域建有界图，按位置/事实修订局部更新并分批；共享stamp有益但不能证明万级成本，作者de-stamp欠缺须保留。

网格、stamp、图层组合与决策/移动解耦，C数组容易局部实现；地图粒度/半径/发布代数须统一。

缓存图通常由业务事实重建；影响值不能替代必须持久化的证言/目击/交易记录，局部随机tie-break需稳定随机合同。

顺序不明会读刚清空或重复写图；错层/过时信息把人物引向不可达/危险地点。

半径按移动速度估计不能保证将到达或被目击；同值随机可变外观不是更准确的社会因果。

避敌图无法自动表达法律、同意、欺骗归因或连续资产结算。

完整5028字符博客正文；未核UE4代码、截图或演示视频，性能为作者设计解释非测试记录。

关联Dave Mark GDC原谈未在此载体通读，不能把其全系统优化归给本文。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [163509ed1859842cce4440a4.txt](../texts/f8/f8f10f7b20db214d689e48f7526df3eb5ada8b0c81a1d631bb6a108f0a15cc47.md) | 文章/文档正文 | [0, 5028) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/09-influence-environment.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/09-influence-environment.md)
- [https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps](https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps)
- [https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps/](https://adamgameprogramming.wordpress.com/2021/04/01/advanced-ai-for-games-influence-maps/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
