# GAMA Developing Extensions — Version 2025-06

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://gama-platform.org/wiki/DevelopingExtensions`。
- 已有内容：文章/文档正文。
- 主要来源：[https://gama-platform.org/wiki/DevelopingExtensions](https://gama-platform.org/wiki/DevelopingExtensions)

## 概要与项目参考

Ancillary extensibility architecture overview, lacking lifecycle, population-cost or gameplay methods.

## 已有机制分析

source_facts: The overview describes runtime OSGI plugins declaring contributions plus Java annotations collected at compile time and compiled into GAML structures.
Extensions may add species/types/files/skills/operators/statements/control architectures/displays; scheduling policies and other internal structures are described as hardwired future openings.
domino_recommendations: A small typed behavior definition/ops registry can be an analogous explicit extension boundary; no Java/OSGI/GAML runtime is needed for the initial C23 project.

## 后续行为与玩法启发

crime:
No concrete content.

deception_investigation:
No concrete content.

cooperation_player_interaction:
Custom operators could encode future domains; this page does not demonstrate them.

## 适用范围与局限

No scheduling implementation or 10000 NPC benchmark; scheduling extension is explicitly future in this snapshot.

Keep extension schema and contribution declarations explicit; avoid dynamic plugin infrastructure when finite compiled definitions suffice.

Available extension points do not establish efficient decision-making or safe effect commits.

Treating future opened scheduling as current capability would misread the page.

Complete short overview [0,1306) read; linked plugin/operator/control-architecture pages and code not inspected.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [165a94990b380d81077ba0e6.txt](../texts/5b/5b2cdd093f6300ef0978e9a97e8f74c927ffb6cdea4a6ab389f8f032da666993.md) | 文章/文档正文 | [0, 1306) |

## 原研究概要与相关链接

- [https://gama-platform.org/wiki/DevelopingExtensions](https://gama-platform.org/wiki/DevelopingExtensions)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
