# Faster Scheduling — Matthew Rocklin (Dask/Coiled), 2020-07-21

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`identity-limited-unit:bb9857f6296d7dc3dabc09f0b5ec4272256358a5de4a99131df1f214d739fe8e`。
- 已有内容：文章/文档正文。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：Matthew Rocklin（Coiled，Dask维护者）。
- 原目录日期：2020-07-21（沿用已有记录）。
- 主要来源：[https://blog.dask.org/2020/07/21/faster-scheduling](https://blog.dask.org/2020/07/21/faster-scheduling)

## 概要与项目参考

Domino推论：先把人物candidate planning、queue/wakeup、state commit、日志/观察成本分阶段核算，避免把总吞吐差全部归因于队列或C语言。

有限近期任务模板共享静态定义，批次只携带ID/少量值，减少每人复制完整task图；公共状态机与消息/调度机制分离有利维护。

## 已有机制分析

原文把调度成本分为graph generation、optimization、serialization、communication、update_graph、schedule、worker delivery、worker work八阶段，强调启动延迟和短task之间gap是不同问题。

原文建议让high-level graphs保持紧凑表示至scheduler，减少生成/传输；为此需高层cull/slice/fusion替代原低层优化。

原文提出worker提前接收高度可信、未ready的任务以减少后续dispatch gap，同时保留任务分离的diagnostics；是speculative placement提案，不是提前执行或结果提交。

原文将scheduler networking与internal state machine分离，便于单独profile和局部低层优化；强调维护社区与dashboard状态接口成本，反对为慢就盲改语言/多scheduler。

## 后续行为与玩法启发

只间接帮助密集工作/互动到期峰值的处理；原文没有犯罪、知识、关系、玩家互动机制。

任务可提前排布但执行前必须验证资源/参与者/位置、取消和图版本；不能借speculation让未发生动作结算。

## 适用范围与局限

作者讨论millions of tasks、10–100TB及1–5%受影响用户估计，非10000NPCbenchmark；主要Dask分布式网络成本不属于Domino单宿主默认设计。

本文是rough future acceleration plan，没有实施后latency/throughput/memory对照；可提炼减少小task overhead的思路，不能引用成已验证加速数值。

保持一个明确状态机和观察接口，改调度实现时保留可见状态；维护多个核心实现会分裂工作并失去dashboard，原文已有具体警告。

Domino不需要引入Dask、高层graph通用框架或分布式scheduler；只在真实开销数据出现时采用批次和共享定义。

只重写低层语言不能减少所有graph/communication阶段成本。

分布式调度在耦合依赖/全局决策场景难以保持质量；一地域一线程/多个写入者会带来额外一致性成本。

高层紧凑表示可能损失既有culling/fusion，优化前后必须确保执行语义；speculative任务仍可取消并不得提交未就绪效果。

全文blog source已读，未阅读linked issue/ery code，也不查询当前Dask状态。

原始计划事实与Domino推荐分离；无引擎运行或效能验证。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [5501135134d67661e0f82533.md](../texts/e8/e8b90c4a459ed05a23c563676aba3335cc7bb3fc4970d2617cec008c85516c01.md) | 文章/文档正文 | [0, 10500)、[10500, 14003) |

## 原研究概要与相关链接

- [12-community-2016-2026/07-performance-scheduling/09-scale-benchmarks-measurement.md](../../ai-reference/12-community-2016-2026/07-performance-scheduling/09-scale-benchmarks-measurement.md)
- [https://blog.dask.org/2020/07/21/faster-scheduling](https://blog.dask.org/2020/07/21/faster-scheduling)
- [https://raw.githubusercontent.com/dask/dask-blog/gh-pages/_posts/2020-07-21-faster-scheduling.md](https://raw.githubusercontent.com/dask/dask-blog/gh-pages/_posts/2020-07-21-faster-scheduling.md)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
