# Unreal Engine Game Optimization on a Budget

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://tomlooman.com/unreal-engine-optimization-talk/`。
- 已有内容：文章/文档正文。
- 原目录作者：Tom Looman。
- 原目录日期：2022（沿用已有记录）。
- 主要来源：[https://tomlooman.com/unreal-engine-optimization-talk](https://tomlooman.com/unreal-engine-optimization-talk)

## 概要与项目参考

Domino 建议：找出human持续全扫、局部寻路、社会事件和到期峰值分别消耗多少，再决定分批、候选限制或更新间隔；此轮禁止运行测试，文章的profiling流程只记录为后续实施方法。

需要持续保持真实资源/进度的业务层可减重复决策，视觉姿态/音画可按重要度变化；不能把卸载或低频模拟当作未发生消费、犯罪和工资的证据。

记录含task类型、人群数量、积压长度、事件原因的轻量上下文可让成本尖峰解释清楚；不要开启每NPC海量DEBUG来代替性能计数。

## 已有机制分析

作者文章是45分钟演讲的逐章节文字伴读；先用Game/Render/GPU异步瓶颈定位与打包构建测量，再通过必要trace channels、自定义stat和bookmark把帧峰值与加载/GC/玩法转折关联。
DumpTicks与listtimers用于找不必要的每帧工作；Significance Manager按游戏相关距离/数量bucket给对象重要度，减少tick、query、动画和音画更新，而非默认所有对象保持全精度。
对碰撞只保留实际需要的QueryOnly、每帧合并移动旋转、精简bounds计算；通过HLOD、距离/灯光剔除与level LoadNotVisible/Visible不同状态减少渲染查询和内存。
文末讨论动画更新率/压缩、资产硬引用依赖、影子代理与调试工具，明确Nanite与非Nanite许多路径不同；部分数字是作者某项目的观察。

## 后续行为与玩法启发

玩家附近的追逐/调查可提高感知与表现更新精度，但远处盗窃/交易仍须受真实资产、时间、参与者和提交规则约束。

重要度可包含玩家契约、当前共同活动、目击事件和危险状态而不只是距离；阻断路线或NPC拒绝应使相关任务局部唤醒。

## 适用范围与局限

文章没有10000 NPC规模数据，主要UE渲染/组件成本；动画压缩倍数与内存减半是特定内容/库数据，不能映射Domino AI吞吐。

重要度本身若每帧对全部人和所有玩家做复杂查询，会增加开销；应限定低频/局部重评，限制高精度bucket并监测队列延迟。

减少tick能减少无用工作，却不能忽略业务到期、竞争与离散结果；需要晚唤醒时基于实际进度结算，不能由LOD凭空产生历史。

先增加少量领域计数/预算接口，再把重要度策略放共享调度层；具体类型声明最低响应需要，避免中央调度认识每种犯罪。

UE命令/插件不是C23实现合同，且文章含后续UE5.3/5.7更新；不可直接据此假定本项目已有SignificanceManager或渲染系统。

看不见/远距离不代表NPC无人互动；完全关掉业务tick会漏付资源、错过目击和承诺。

编辑器profiling与打包运行数值不同，作者明确准备条件；当前源码分析没有任何runtime证明。

只降低GPU或动画成本可能完全不改善CPU模拟瓶颈；按文章提醒需先定位真实瓶颈。

完整读作者文章，未观看关联演讲及图像；文章自称伴读摘要，不能代替完整演讲。

大量细节属于Unreal渲染工具与版本条件，Domino当前CPU模拟仅提取预算/诊断机制。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [8851ce9fcbc0418f2f912877.txt](../texts/d7/d76a9b0b5a7fda961269a434968724bc4718d24e6d46307a73b18ecbac0508c1.md) | 文章/文档正文 | [0, 11500)、[11500, 19682) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/07-performance-scheduling/05-ai-budget-lod.md](../../ai-reference/13-youtube-2011-2026/07-performance-scheduling/05-ai-budget-lod.md)
- [https://tomlooman.com/unreal-engine-optimization-talk](https://tomlooman.com/unreal-engine-optimization-talk)
- [https://tomlooman.com/unreal-engine-optimization-talk/](https://tomlooman.com/unreal-engine-optimization-talk/)
- [https://tomlooman.com/unrealengine-optimization-talk/](https://tomlooman.com/unrealengine-optimization-talk/)
- [https://www.jetbrains.com/guide/gamedev/links/unreal-engine-game-optimization-on-a-budget/](https://www.jetbrains.com/guide/gamedev/links/unreal-engine-game-optimization-on-a-budget/)
- [https://www.youtube.com/watch?v=G51QWcitCII](https://www.youtube.com/watch?v=G51QWcitCII)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
