# SimPy events.py (f43816490c6f76f336ad6e457d3cab9f386894af)

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`identity-limited-unit:785f96c3d12e42b9c9f949d0e508b69849ebf561e52d563ce279e1345a013976`。
- 已有内容：源码/工程文本。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 当前前100：第 21 项；[SimPy事件：阶段、失败与旧等待隔离](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/021-9bf0deeba13e.md)。
- 主要来源：[https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py](https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py)

## 概要与项目参考

直接契合人类AI的事件唤醒、取消旧等待、成功/失败分流及任务生命周期，是本批最强执行边界参考；源码行为清楚且可拆成局部机制，不要求采用完整SimPy或Python。

## 已有机制分析

source_facts: Event分pending、triggered、processed：succeed/fail设置状态并schedule，callbacks=None表示已经处理；失败必须由callback明确defuse，否则环境处理时再抛出。
Timeout构造即成功触发但延迟处理；Initialize用URGENT保证启动先于interrupt。Process保存当前等待target，处理成功send或失败throw后再登记下一事件，不需要每步轮询。
Interruption以高优先级事件调度，死process后续中断忽略；中断先从旧target移除_resume回调，避免旧等待完成继续恢复。
AllOf/AnyOf按已处理计数判定，嵌套condition最终构建已处理事件值；任何子事件失败均传递失败，完成后递归卸载_check回调以断开循环引用。
domino_recommendations: 用普通C状态机/ID替代Python generator：明确等待类型、执行代次、目标事件ID、终止状态和失败码。到期事件只唤醒检查，不能把Timeout的ok解释为任务真实成功。
将等待服务、合作回应、超时或警报表为小型any/all等待集合；抢占时撤销旧订阅并用代次拒绝旧事件，参与者拒绝和真实占用释放由领域执行器确认。
存档保存可恢复任务状态与等待条件，再重建订阅；不保存callback指针或生成器栈。

## 后续行为与玩法启发

犯罪中等待锁打开/同伙就位可用AllOf；潜入完成、警报、玩家阻断、超时用AnyOf，但取消等待不等于门关闭/资产回滚。交易/调查等待邀请、答复或证据到达，拒绝可显式失败并触发替代任务；合作终结需每方实际停止与资源释放。

## 适用范围与局限

登记后按实际事件唤醒可避开每帧10000全员决策，总代价受活跃等待边/事件数量支配；events.py没有scheduler实现或万级benchmark，不能从此证明堆复杂度/线程安全。callback remove为Python线性list查找，嵌套条件递归访问O(依赖边数)，同刻10000 timeout仍集中爆发；C应限制等待扇出、合并通知/分批预算。 当前timer取消需线性扫命令/堆/业务队列，后台投递失败abort；SimPy事件机制不能自动解决这些集成压力。

共用事件状态契约和失败原因，领域效果仍单一执行入口；区别取消订阅、取消任务、停止确认、进度结算与占用释放。AnyOf完成后的其他底层事件仍可能继续存在，要明确归属和取消策略；持久化ID/代次而非函数对象。

Timeout在构造时triggered，不代表任务完成；将调度成功直接支付工资会提前结算。

只改task状态不卸载旧target的恢复回调，旧事件会重新推进被取消任务。

AnyOf不是第一个成功获胜：某依赖失败也会让整个条件失败，需按业务设计成功/拒绝/超时含义。

condition只删check callback，并不取消底层动作或释放领域资源；process中断也不证明物理动作已停止。

完整events.py文字[0,23146)已读，不是SimPy整仓源码审计。

没有core scheduler/resource实现、实际多线程或持久化代码；不外推线程安全、资源释放或运行容量。

映射至累计未冻结现实_ms是Domino建议，源代码的SimTime没有项目时间单位承诺。

经本轮code-baseline核对：human无任务执行/收益结算/恢复闭环，timer尚未生产集成；所列C状态、代次、释放与存档方案均为建议。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [098cd9d6377e4a484ac114e9.repaired.txt](../texts/b5/b58a8ee5df683cfd0cfc0afa0a5e3e78db16cad0ca01694b693cc6914002b570.md) | 源码/工程文本 | [0, 23146) |

## 原研究概要与相关链接

- [11-open-source-projects/09-event-scheduling/simpy.md](../../ai-reference/11-open-source-projects/09-event-scheduling/simpy.md)
- [https://gitlab.com/api/v4/projects/team-simpy%2Fsimpy/repository/commits/f43816490c6f76f336ad6e457d3cab9f386894af](https://gitlab.com/api/v4/projects/team-simpy%2Fsimpy/repository/commits/f43816490c6f76f336ad6e457d3cab9f386894af)
- [https://gitlab.com/team-simpy/simpy](https://gitlab.com/team-simpy/simpy)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/LICENSE.rst](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/LICENSE.rst)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/core.py#L165-212](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/core.py#L165-212)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py#L274-311](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py#L274-311)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py#L217-240](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/base.py#L217-240)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/resource.py#L168-224](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/resources/resource.py#L168-224)
- [https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/rt.py#L60-91](https://gitlab.com/team-simpy/simpy/-/blob/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/rt.py#L60-91)
- [https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py](https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/src/simpy/events.py)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
