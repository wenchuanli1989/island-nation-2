# NetLogo Dynamic Scheduler Extension — Colin Sheppard

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://github.com/colinsheppard/dynamic-scheduler-extension`。
- 已有内容：文章/文档正文。
- 主要来源：[https://github.com/colinsheppard/Dynamic-Scheduler-Extension](https://github.com/colinsheppard/Dynamic-Scheduler-Extension)

## 概要与项目参考

Domino推论：用due_ms事件和外部变化唤醒替代当前无工作全量重扫，读only task定义与每人少量timer/状态；同到期业务排序需明确，执行者仍检查真实条件。
事件引用使用entity/task ID和修订版本，消费时检查当前状态；到期仅通知，不代表动作成功或资源可用。

## 已有机制分析

原文schedule objects支持agent X在time Z执行task，减少每tick遍历休眠agent做条件测试；支持add、add-shuffled、repeat与dispatch。
原文同一时间按add顺序FIFO；agentset默认不shuffle，可显式add-shuffled；未来agent死后事件silent skip。
原文go一直处理到队列empty；repeat或task重新schedule可能永不结束，go-until按halt-time截断是推荐入口。

## 后续行为与玩法启发

NPC睡眠、工作分段、约会超时、受害者延迟发现和调查线索到期可复用唤醒机制；原文没有相应犯罪业务。

玩家取消/打断使旧唤醒无效，但停止确认与占用释放仍独立，不能像死agent事件一样一律丢掉cleanup。

## 适用范围与局限

避免无用O(N*ticks)轮询是具体机制，schedule运行成本取决于有效events；README未说数据结构/复杂度，无10000benchmark。

作者报告不shuffle在简单benchmark约15%提升，未给硬件/模型数据，不能宣称总体AI提升15%。

大量重复event与同步due峰值可积累；需有界batch/预算，freeze/offline不快进结算，tick语义换为累计未冻结real_ms。

少数create/add/repeat/go-until API清楚；借机制即可，不需NetLogo/JAR依赖。

记录同到期插入顺序和业务优先；存档保存业务due状态而重建runtime schedule，不把闭包或timer ID持久化。

go等待empty在repeat/自我新建event时可无限loop；go-until也不能替代同时间自循环与批次budget。

死agent事件silent skip可能遗漏资产/参与者占用清理，Domino终结仍需可靠cleanup。

不shuffle节省时间会改变公平性与结果；按业务选activation ordering而非盲追15%。

全文README载体读完含GitHub navigation；未读src/benchmark/example，不对最新NetLogo兼容性判断。

没有删除/cancel primitive的具体契约或存档实现；不可替代完整task生命周期。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [8a67339cb5ad5d23499b61e7.txt](../texts/ed/ed769044e5f6398a4ce8cffa9336c73b4d34a0b21cf7cbbe6ea4fb7678a4c122.md) | 文章/文档正文 | [0, 7805) |

## 原研究概要与相关链接

- [https://github.com/colinsheppard/Dynamic-Scheduler-Extension](https://github.com/colinsheppard/Dynamic-Scheduler-Extension)
- [https://github.com/colinsheppard/dynamic-scheduler-extension](https://github.com/colinsheppard/dynamic-scheduler-extension)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
