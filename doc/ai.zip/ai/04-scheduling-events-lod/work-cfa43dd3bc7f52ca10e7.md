# BehaviorTree.CPP commit ba1d475f46d768fa0acd16639c9025ecf263ac4d: TimeoutNode/DelayNode halt and timer reset

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://github.com/behaviortree/behaviortree.cpp/commit/ba1d475f46d768fa0acd16639c9025ecf263ac4d`。
- 已有内容：源码/工程文本。
- 原目录作者：chrisjaxy（提报者）；Davide Faconti / facontidavide（维护者，评论 authorAssociation=COLLABORATOR）。
- 原目录日期：2023-08-02（沿用已有记录）。
- 主要来源：[https://github.com/BehaviorTree/BehaviorTree.CPP/commit/ba1d475f46d768fa0acd16639c9025ecf263ac4d](https://github.com/BehaviorTree/BehaviorTree.CPP/commit/ba1d475f46d768fa0acd16639c9025ecf263ac4d)

## 概要与项目参考

Domino建议：每次激活明确创建/取消计时身份并重置本次状态，用task activation revision隔离旧事件；取消定时器、停止行为和重新可启动需要不同生命周期步骤。
到期回调只投递值事件并唤醒业务拥有者，拥有者核验任务版本/终态后处理；不直接把BT.CPP回调里haltChild的跨线程写法迁到单状态写入者架构。

## 已有机制分析

源事实：TimeoutNode/DelayNode halt重置timeout_started_/delay_started_，cancelAll后调用DecoratorNode::halt；防止重新进入时继承旧计时启动状态。TimeoutNode实现从模板头迁到cpp并更新factory/tests类型。
源事实：首次tick启动计时并置RUNNING，超时回调若aborted立即返回，避免析构期间访问成员；否则持timeout_mutex检查child仍RUNNING，标child_halted、haltChild并emitWakeUpSignal。
源事实：后续tick在child_halted时清started并返回FAILURE；child正常结束时清started，释放timeout_mutex再timer.cancel，重新持锁resetChild，以避取消等待回调同锁的风险。

## 后续行为与玩法启发

限时谈判、盗窃被打断、合作邀请超时和逃逸重试可共用计时/唤醒/终态处理；超时是失败/等待决定，实际已盗取资产或已消耗体力仍需按进度结算。

玩家取消后重新邀请同一NPC不能继承旧倒计时或被旧回调杀死；对方停止确认和占用释放后才可转取消完成。

## 适用范围与局限

定时唤醒可减少忙轮询，但每节点独立TimerQueue+mutex的设计对10000NPC成本无数据；Domino宜共享timer与有界业务队列并合并人物唤醒。

源码只显示语义修复与类型调整，测试diff没有可见新halt后重启回归场景，也没有吞吐/内存bench。

公共decorator halt处理便于一致取消；Domino把通用started/current_timer/revision/stop边界集中，行为类型只实现领域停止/释放。

C23 atomics/mtx合同需重新设计；mutex unlock/cancel/relock是该库具体死锁边界，不可按表面行序照抄。

timer aborted回调返回不证明外部执行的动作已经停止；haltChild本身也不等于远程/物理动作取消确认。

恢复存档不能保存TimerQueue内部对象或裸this指针；重建计时事件必须基于已保存业务状态，避免重复效果。

列表中源码是完整可见commit diff，lookup关联issue题名不是载体实际标题，不把它标为整issue讨论或整个TimeoutNode历史。

完整读取冻结commit页面提取diff12593字符，包含旧/新代码及可见测试改动；没有运行测试、读TimerQueue/DecoratorNode内部或issue全部讨论。

机制可直接启发可恢复中断边界，不能据此宣称库或Domino已验证所有取消竞争。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [243685dea9d1d1f5f15a177d.txt](../texts/a7/a7f91d48db9bf86563f21bc5a065469e03db60ca5697af3b703c8f196f1844d3.md) | 源码/工程文本 | [0, 11500)、[11500, 12593) |

## 原研究概要与相关链接

- [12-community-2016-2026/02-execution-interruption/08-timeout-retry-failure.md](../../ai-reference/12-community-2016-2026/02-execution-interruption/08-timeout-retry-failure.md)
- [https://github.com/BehaviorTree/BehaviorTree.CPP/commit/ba1d475f46d768fa0acd16639c9025ecf263ac4d](https://github.com/BehaviorTree/BehaviorTree.CPP/commit/ba1d475f46d768fa0acd16639c9025ecf263ac4d)
- [https://github.com/BehaviorTree/BehaviorTree.CPP/issues/624](https://github.com/BehaviorTree/BehaviorTree.CPP/issues/624)
- [https://github.com/BehaviorTree/BehaviorTree.CPP/issues/624#issuecomment-1669143789](https://github.com/BehaviorTree/BehaviorTree.CPP/issues/624#issuecomment-1669143789)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
