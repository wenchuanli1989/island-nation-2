# A better unrestricted work schedule — explanation and replies

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`reddit-post:fhsmtz`。
- 已有内容：正文/源码节选。
- 主要来源：[https://www.reddit.com/r/RimWorld/comments/fhsmtz/comment/fkd3dek/](https://www.reddit.com/r/RimWorld/comments/fhsmtz/comment/fkd3dek/)

## 概要与项目参考

已有资料的概要见下方原研究笔记及正文；未补写未经材料支持的结论。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [note.md](../texts/b1/b1c1a895c16f9c8987b77234eac6b263165391455c92f538713a369c743397ef.md) | 正文/源码节选 | 已有载体；范围见原记录 |

## 原研究概要与相关链接

- [https://www.reddit.com/r/RimWorld/comments/fhsmtz/comment/fkd3dek/](https://www.reddit.com/r/RimWorld/comments/fhsmtz/comment/fkd3dek/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
