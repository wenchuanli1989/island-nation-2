# PARIS: A Polynomial-Time, Risk-Sensitive Scheduling Algorithm for Probabilistic Simple Temporal Networks with Uncertainty

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://people.csail.mit.edu/psantana/data/files/articles/2016_ICAPS_paris.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Pedro Santana; Tiago Vaquero; Cláudio Toledo; Andrew Wang; Cheng Fang; Brian Williams。
- 原目录日期：2016（沿用已有记录）。
- 主要来源：[https://people.csail.mit.edu/psantana/data/files/articles/2016_ICAPS_paris.pdf](https://people.csail.mit.edu/psantana/data/files/articles/2016_ICAPS_paris.pdf)

## 概要与项目参考

Domino 建议：近期计划中的任务时长应带知识类型与来源；未知调查、合作等待用有限上下界/超时，已有稳定样本的路程或制作任务可用保守经验分位数。当前没有必要导入 LP 求解器；若将来跨多个参与者严格交货/会合窗口的约束组合确实变复杂，可用小范围 PSTNU 调度，输出仍是只读计划。

## 已有机制分析

源事实：PSTNU 允许已知分布的 PSTC 与仅知上下界的 STCU 共存，不在无数据时猜分布；strong policy 在执行前固定全部可控事件时间，区别于利用已发生时长的动态调度。
源事实：把每个事件写为可控根时间加 contingent path；计算两个事件差值时取消共享 contingent duration，剩余项取上下界，得到 strong controllability 的线性约束。
源事实：对概率时长选择外加区间以恢复强可控性，用 Boole 不等式汇总区间外尾部概率为风险上界；该上界不要求时长独立。只有集合界的 STCU 不允许 squeeze，因为真实概率质量可能全落入被挤掉的区间。
源事实：均匀分布风险恰线性；单峰分布以分段常数 pdf 构造分段线性尾概率上界，单调系数加最小风险目标免用整数变量。优化分割点用有上限的梯度迭代；机会约束要求上界不超过 theta。
源事实：其它线性目标用风险+M·目标的 surrogate，目标退化有 |Cu|/M 上界；文中列出 single-mode approximation 与 chance constraints 均可能不完备。

## 后续行为与玩法启发

Domino 建议：合作生产、走私交货、警卫巡查空档、调查会合和玩家限时合同可形成风险选择；玩家增加支援/阻塞路线改变时长知识或窗口，NPC 可解释为何换方案。

Domino 建议：风险是 NPC 的时序预测，不是犯罪被发现概率、法律裁决或成功奖励；计划安排会合不等于参与者同意，实际到场与真实提交分别确认。

## 适用范围与局限

作者证明的是 LP 编码/求解对网络规模多项式，非10000 NPC总吞吐。ROVERS 4380个问题为2至10 rover、每个1至10顺序任务；Python/Gurobi 与 Lisp/Ipopt 的实验差距受实现与求解器影响。每人每次重规划调用 LP、每分布最多12000 partition迭代仍代价大；Domino宜局部多人任务才用，复用分布分割、合并事件、限制网络大小和到期批次。

上下界、概率模型与实际观测分开，记录模型版本与风险上界，避免不可解释超参数。原始 PDF 数学抽取有上下标错位，应核对公式图像后才实现。强调度缺乏执行中反馈，不可当通用恢复执行器。

chance-constrained 无解可能只是保守 union bound 的 gap 或单峰区间限制，不证明真实计划不存在。

ROVERS 2840 strong policies 中911把概率时长挤成单点，作者明确其几乎必失败；找到强 policy 不等于可接受风险。

模型误差不计入 scheduling risk；实际时长分布漂移、参与者临时拒绝与未建模资源争用会破坏保障。

风险上界不要求独立，但某个评估真实风险实验特意假设独立；不可把这个实验假设推广为算法全局事实。

全文核读45,267字符的论文抽取文本，未核看 PDF 图像/版式或运行代码。

多项式不等于适合每人每帧；没有 Domino资源竞争、存档恢复或万级人口实测。

抽取覆盖参考文献，正文机制与实验可读；公式符号和图中曲线值仍需原 PDF 核看。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [139a1cf91ba5f6c9c4a66783.txt](../texts/2a/2adee36255f1600f893a6ea2136ef8c6eb9e1a3d4267f591cdbfc9c4c5175cb4.md) | 论文/讲义提取文本 | [0, 45267) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/02-planning-execution/04-temporal-planning.md](../../ai-reference/13-youtube-2011-2026/02-planning-execution/04-temporal-planning.md)
- [https://ojs.aaai.org/index.php/ICAPS/article/view/13761](https://ojs.aaai.org/index.php/ICAPS/article/view/13761)
- [https://people.csail.mit.edu/psantana/data/files/articles/2016_ICAPS_paris.pdf](https://people.csail.mit.edu/psantana/data/files/articles/2016_ICAPS_paris.pdf)
- [https://www.icaps-conference.org/recording/paris-a-polynomial-time-risk-sensitive-scheduling-algorithm-for-probabilistic-simple-temporal-networks-with-uncertainty/](https://www.icaps-conference.org/recording/paris-a-polynomial-time-risk-sensitive-scheduling-algorithm-for-probabilistic-simple-temporal-networks-with-uncertainty/)
- [https://www.youtube.com/watch?v=-OEGevwNQLU](https://www.youtube.com/watch?v=-OEGevwNQLU)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
