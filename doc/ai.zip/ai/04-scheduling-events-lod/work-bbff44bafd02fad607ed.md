# MATSim commit: ThreadScheduling renamed TaskScheduling with eager/backoff configuration

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://github.com/matsim-org/matsim-libs/commit/33b28352ffda93036797b5660f66cc9d9b9cc883`。
- 已有内容：源码/工程文本。
- 主要来源：[https://github.com/matsim-org/matsim-libs/commit/33b28352ffda93036797b5660f66cc9d9b9cc883](https://github.com/matsim-org/matsim-libs/commit/33b28352ffda93036797b5660f66cc9d9b9cc883)

## 概要与项目参考

Domino 建议：human 没有工作时等待事件/标准条件变量，先决定业务调度，再选择空闲等待策略；不能把忙扫当作持续有效模拟。

## 已有机制分析

完整 visible diff 将 ThreadScheduling 的类型、配置字段、getter/setter 与测试名称改为 TaskScheduling。
文档描述 eager / BusySpin 需要每个线程有可用 core；backoff 在空闲时逐步 yield / park，并为默认值。
构造线程池时依 enum 选择 BusySpinIdleStrategy 或 BackoffIdleStrategy；测试 diff 修改默认值与 XML roundtrip 名称。

## 后续行为与玩法启发

空闲等待本身不产生犯罪玩法；及时唤醒对追逐、报警和资源变化响应有间接意义。

## 适用范围与局限

free core 前提和 oversubscription 约束在注释中明确；实际 backoff 实现不在 diff 内，没有延迟、吞吐或万级测量。

配置名和选择分支需保持语义一致，C23 使用 thrd / mtx / cnd / 原子 API。

本任务未运行测试，diff 中的测试变更只能证明验证意图。

线程多于可用 core 时 busy spin 可能抢占有效工作；只改配置名不会修复工作队列或唤醒缺陷。

map kind 为 discussion_snapshot，但实际 carrier 是提交 diff；不推广成整个 MATSim 的行为规划实现。

backoff/BusySpin 类实现及运行证明未覆盖，也未执行 diff 测试。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [e6b8085f55ece00d723b54ab.txt](../texts/6b/6b2b44623ad8ab65da6b3bbb13a161141ab4126298e256e01e2ae3c6d66a5706.md) | 源码/工程文本 | [0, 4584) |

## 原研究概要与相关链接

- [11-open-source-projects/03-navigation-environment/matsim.md](../../ai-reference/11-open-source-projects/03-navigation-environment/matsim.md)
- [https://github.com/matsim-org/matsim-libs](https://github.com/matsim-org/matsim-libs)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/LICENSE](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/LICENSE)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/controler/AbstractController.java#L148-L173](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/controler/AbstractController.java#L148-L173)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/population/PlanImpl.java#L41-L65](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/population/PlanImpl.java#L41-L65)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/router/TripRouter.java#L229-L270](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/router/TripRouter.java#L229-L270)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/scoring/functions/CharyparNagelActivityScoring.java#L209-L244](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/scoring/functions/CharyparNagelActivityScoring.java#L209-L244)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/scoring/functions/CharyparNagelLegScoring.java#L104-L145](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/core/scoring/functions/CharyparNagelLegScoring.java#L104-L145)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/withinday/replanning/replanners/NextLegReplanner.java#L57-L77](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/withinday/replanning/replanners/NextLegReplanner.java#L57-L77)
- [https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/withinday/utils/EditTrips.java#L708-L728](https://github.com/matsim-org/matsim-libs/blob/33b28352ffda93036797b5660f66cc9d9b9cc883/matsim/src/main/java/org/matsim/withinday/utils/EditTrips.java#L708-L728)
- [https://github.com/matsim-org/matsim-libs/commit/33b28352ffda93036797b5660f66cc9d9b9cc883](https://github.com/matsim-org/matsim-libs/commit/33b28352ffda93036797b5660f66cc9d9b9cc883)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
