# Supporting Thousands of NPCs in Kingdom Come: Deliverance & Kingdom Come: Deliverance 2

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`gdcvault:1035718`。
- 已有内容：摘要/简介、论文/讲义提取文本。
- 当前前100：第 2 项；[《天国：拯救》系列数千NPC的分级执行与切换预算](../../ai-reference/17-npc-fullread-top100-2026-10-07/profiles/002-7d1bc475ee3c.md)。
- 原目录作者：Petr Smrcek / Warhorse Studios。
- 原目录日期：2026（沿用已有记录）。
- 主要来源：[https://gdcvault.com/play/1035718](https://gdcvault.com/play/1035718)

## 概要与项目参考

Domino建议：10,000+目标必须说明每层真实业务精度和成本；借鉴分级状态/动作切换生命周期、热点预算、标准重复选择逻辑C化和共享距离采样。
保留身份、实际位置、已执行效果/进度与资源竞争；远层不能不执行交易却自动得收益，不能凭计划造消费、犯罪或目击历史。需要复杂交互时晋升局部精度并确认旧动作cleanup后再启动。

## 已有机制分析

原文Petr Smrček/GDC2026：KCD2共2400 NPC、Kuttenberg约1400；Close最多70可见/150m，Middle最多400或600m并保精确位置/状态与完整AI，Far仅代码选行为、沿路径移动、约10m位置精度，不模拟行为执行/物品状态且无感知。
Far行为选择把MBT重复的Time of Day/NPC properties/constraints/deterministic chance配置在脚本、执行在代码；crime保有representation并触发切到Middle，但讲义未展开犯罪表示/触发算法。
LOD切换是多阶段：MBT gracious cleanup、budget、defer、resource streaming，当前切换中角色仍占资源，要等待并保额外切换预算；desired LOD依距离+hysteresis、预算和约束，距离round robin约每10帧缓存。
AI移线程后的Set/Get不同步用AI transform缓存和具授权线程/帧段的延迟操作；作者列操作顺序、匿名传播和代码扩散代价。城市可见区域与soft vision breakers配合70 Close上限，不能只靠遮挡。

## 后续行为与玩法启发

强证据主题：全世界位置和后果让玩家不在场也有持续世界，crime触发提高精度、快旅行不跳过encounters、skip time仍模拟犯罪/危险/任务进度。

玩家犯罪、封路、诱导、交易或集合大量人群可触发局部晋升；维持有限感知听众与真实资产效果，记录拒绝/失败和后果，不能只让距离决定业务重要性。

室内追逐/目击可借visibility areas按必要局部区域细化；讲义城市设计用视线阻断配合预算，提供玩法/场景结构对性能的约束实例。

离屏犯罪发生、目击和报告的保留是Domino原创需求；此摘要未展示犯罪、时间跳跃或警察机制。

## 适用范围与局限

作者报告1400城市60FPS、Close70、Middle400及AI各项ms；这是不同精度的作者场景结果，不是1400或10000完整行为逐帧等精度仿真，本轮未复现。

Far内存低于50kB约原25%，释放75kB角色/25kB物理/30kB大AI等；人物身份/业务保留要另计，不能按商用引擎组件内存乘数预测Domino。

10帧距离缓存降低全员多系统扫描，但会有采样滞后；LOD处理0.8ms(+130%)和导航0.7ms(+600%)揭示优化会转移成本；多级切换峰值、拥挤聚集和多人观察范围需另预算。

source_claims:
作者概览称KCD2近2400NPC、约一半单城、数量四倍；未给CPU、内存、硬件、测量负载或LOD成本。

domino_assessment:
数量是作者规模主张，2400也不是万人单机证明；城市集中比均匀离屏更难，应独立测活跃人数和事件密度。

行为通用选择放C、内容仍可配置，避免脚本每处LOD branching膨胀；同一公共start/wait/suspend/resume/cleanup ops承载不同精度执行。

desired LOD与actual LOD、switching阶段和资源占用分别记录，按现实ms统计CPU等待/响应年龄；无需完整ECS迁移或使用商业框架API。

LOD切换应保持同一执行/存档契约是建议；本文只给让脚本不感知LOD的目标，不证明具体维护成本。

Far明确不模拟item handling/perception，直接照搬会失去经济和犯罪因果；仅crime representation不足以证明远处犯罪成本与目击正确性。

同一帧多人晋升仍占旧资源，可瞬间超Close/内存预算；单一LOD flag或瞬间替换会漏cleanup/占用。

动物无身份可spawn即可和士兵无行为sprite是该游戏特定裁剪，不能默认用于有亲属、资产、承诺的Domino人物。

城市soft遮挡保证可见人数上限，玩家自发聚集/多人跨区可能打破；远层约10m位置不可用于门槛、接触、精确目击结算。

账号并发登出提示/会员说明只是访问状态，实际可读Overview不等同讲座全文。

调低更新频率若漏掉承诺、时间完成或目击会改变玩法；原讲是否解决这些未知。

完整读取69页讲义可提取文字[0,9289)，含多次揭示/纯图页标题；未看视频、图内蓝图/布局或演示帧率。

保留商业游戏作者自报规模、精度和时延，未变成Domino已有能力；crime representation、gracious cleanup和LOD选择具体算法细节缺正文展开。

完整分配页面已读；仅官方Overview和站点导航，无原讲文字/视频或具体测量。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [document-text.txt](../texts/24/24386556465ff8f64ffe365773de5526bb4d47e74aa394490ae6d923d877944f.md) | 论文/讲义提取文本 | [0, 9289) |
| [9975d4e8d8ee9323cc9ee9b4.txt](../texts/6d/6d276aeadaec9430eb5addd1485a3f81d42fcca06fee658ccc421076b6c9671d.md) | 摘要/简介 | [0, 2903) |

## 原研究概要与相关链接

- [02-planning-execution/04-temporal-daily-scheduling.md](../../ai-reference/02-planning-execution/04-temporal-daily-scheduling.md)
- [https://gdcvault.com/play/1035718](https://gdcvault.com/play/1035718)
- [https://gdcvault.com/play/1035718/](https://gdcvault.com/play/1035718/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
