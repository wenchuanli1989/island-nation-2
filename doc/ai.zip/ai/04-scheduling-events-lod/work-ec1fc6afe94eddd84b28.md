# NPCs completing different actions based on a schedule — r/godot

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`reddit-post:15b7ee3`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：u/WildsEdge。
- 原目录日期：2023-07-27（沿用已有记录）。
- 主要来源：[https://www.reddit.com/r/godot/comments/15b7ee3/](https://www.reddit.com/r/godot/comments/15b7ee3/)

## 概要与项目参考

明确未加载室内与时间推进的生活日程缺口，有助现有同楼简化未来按场景细化；证据仅评论与主帖媒体占位，不能证明实现。

## 已有机制分析

source_facts: 主帖只有Picture/Video占位，未提供媒体内容；作者回复说明仅设起终点，用AStar生成路径，背景spawn/despawn只是可能后续。
评论提出日程与时间跳过/地图加载后传送到目标；作者明确时间跳过尚需工作，未加载室内也须记录离楼时机和加载后状态。
另评论回忆Rain World渲染与AI分层，表示自己想在Godot实现；没有官方来源或已实现性能。
domino_recommendations: 仿真任务/地点/进度独立于视图或建筑渲染，加载界面从保存的真实状态建立展示。
日程目的地与路径执行分开；计划在哪不代表实际已到，恢复/冻结不能以传送或补完资源代替有效移动/服务进度。

## 后续行为与玩法启发

source_facts:
无犯罪/调查；只有生活日程与背景NPC讨论。

domino_recommendations:
玩家进入房屋、睡眠或远离场景时，潜入、偷窃、封锁、证词和共享资源后果仍应连续；必要局部房间/权限场景提升空间精度，不假设同建筑任意位置可通。

## 适用范围与局限

没有NPC数量、CPU/内存或算法复杂度；每人AStar按目的改变触发而非每帧重算是建议。视图分离能省绘制成本但不能省真实业务争用，10000人长期状态仍需稀疏待办、局部事件和预算。

仿真实体与渲染实例解耦有稳定边界，调试与存档一致更容易；加载/卸载不应销毁业务活动。原文Godot代码未给，计划传送方案不适用于Domino真实时间/路线模型。

地图加载时把NPC放在该做的事附近可能穿过封锁、逃过追捕、虚造目击/消费。

背景spawn/despawn不能实现同一人物资产和承诺连续。

RainWorld/Stardew/KingdomCome内容是评论回忆，未核官方源码/演讲，不当游戏事实。

完整读3323字符partial可见评论载体；未读主帖图片/视频或未加载回复，不能宣称完整作品观看。

本地保留内容从推荐区前截断，没有完整代码、室内/时间跳过实现或万人结果。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [s2-15b7ee3-visible.md](../texts/96/966aa1a621901017634998caf0cf584c0a4834aeba570971225a8b99ce14dd0a.md) | 讨论正文/已载入评论 | [0, 3323) |

## 原研究概要与相关链接

- [14-three-sites-2026-10-04/03-world/commute-budget/content/s2-15b7ee3-visible.md](../../ai-reference/14-three-sites-2026-10-04/03-world/commute-budget/content/s2-15b7ee3-visible.md)
- [https://www.reddit.com/r/godot/comments/15b7ee3/](https://www.reddit.com/r/godot/comments/15b7ee3/)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
