# Unreal Engine Game Optimization on a Budget

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`youtube:G51QWcitCII`。
- 已有内容：字幕/转录文本。
- 原目录作者：Tom Looman。
- 原目录日期：2022（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=G51QWcitCII](https://www.youtube.com/watch?v=G51QWcitCII)

## 概要与项目参考

Domino建议：分别度量候选生成、路线查询、任务执行、日志/存档成本，并用任务/事件标记关联玩家干预造成的峰值。
到期唤醒仍需批量预算与错峰，不能把持续全员扫描改成同刻10000个timer就宣称优化；重要性分桶可用于展示/感知频率。

## 已有机制分析

原文先分CPU游戏线程、渲染线程、GPU瓶颈，用时间线、分类内存/加载报告及玩法bookmark把成本关联到操作。
dump ticks/list timers检查无用工作；高于帧率的timer可一帧执行多次，重活仅挪timer会造成尖峰，可时间切片限制每帧数组项数。
significance manager由项目计算重要性并按桶决定tick/查询精度；远处动画降频，父bounds复用和合并位置旋转更新减少重复移动/overlap。
distance culling、HLOD/streaming降低待判断对象数量；可见性查询也有成本且延迟一帧。

## 后续行为与玩法启发

玩家附近追捕、潜入、目击等活动提高局部观察/空间精度；正在远处履约的合同或团伙行动按事件推进并保持后果，不因不可见而取消真实业务。

玩家移动、封路或邀请会改变相关活动优先级；可用相关性桶防止附近高价值互动被万人背景扫描挤压。

讲座本身没有犯罪、信念或社交决策机制；这些映射属于 Domino 的调度建议。

追逐、调查、协作现场提高局部观察/动画精度，保留场外资产转移和任务进度的真实执行。

玩家阻路或群体集会可制造突发工作，应可观察取消/重选原因而非帧卡顿。

## 适用范围与局限

按万人每帧距离打分仍是 O(N)，相关性管理不能自动消除全员成本；宜用地域/活动索引筛出候选并让桶更新低频、有界。

time slicing 增加响应延迟，集中到期会排队；要为玩家即时互动和停止确认保留预算，并合并重复唤醒。

本文给个别项目优化经验和 compression speed 主张，未证明 10000 NPC 日常模拟吞吐；GPU/HLOD 收益不等同 CPU 业务模拟收益。

减少候选对象通常比每对象查询更便宜；significance每帧遍历仍O(N)，需要局部/事件索引，字幕不证明NPC万级。

渲染和资源压缩数字属于Unreal具体项目/作者叙述，不能推导C23模拟吞吐。

预算与统计集中，类型自己声明重评条件、重要活动状态与需要的观察精度；不要给所有行为散落距离 if。

维护对象分组默认值和例外，讲座末段建议批量修改、编辑器检查防止旧资源设置漂移；Domino 可转成共享模板与配置校验。

profiling 开销需计入，诊断日志不宜默认在每 NPC 热循环输出。

统一类型默认配置与显式例外，配合检查规则防止资源设置漂移；有限profiling通道避免测量本身加重负担。

Domino可提炼批量调度与作用域计时思想，无需引入Unreal manager/渲染体系。

把昂贵循环搬到高频 timer 可能同帧多次执行且出现更大的峰值。

只按玩家距离关停业务会让犯罪、支付、目击因果和同一存档在视野外失真。

错误复用父 bounds、过早剔除或加载阈值会漏掉玩家可见武器/空间；此处是表现层经验，不能当物理不存在。

CPU 优化若当前 GPU 瓶颈，帧率未必改善；editor 测量可能误判资源驻留。

仅按距离停止逻辑会漏掉远处犯罪、交易、工资与观察历史；应明确哪些工作可降精度。

父bounds不含伸出的剑会错误裁剪；重活定时器同步到期、过高频timer会更慢。

编辑器内存/未cook资源和发布游戏路径不同，监测结果容易失真。

完整读 71647 字符浏览器字幕，未观看视频画面、截图、演示或核验具体控制台拼写；ASR 对专名和命令有明显误识别。

大量技巧是 Unreal 4/5 特有表现层设置，C23 Domino 仅可迁移工作预算与量测原则。

没有新增联网、性能复现、引擎构建或测试。

完整读本地0:05-59:56自动字幕；未观看视频或核看截图，API名称有自动识别错误。

主题主要是Unreal展示、资源与调试优化，行为生命周期/事实和信念模型覆盖很少。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [browser-export.txt](../texts/5d/5d5cba3e2e81cc089b2bf3a0be67966d9724e5759542f268204460f2732b9f8f.md) | 字幕/转录文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 48000)、[48000, 60000)、[60000, 71726) |
| [transcript.txt](../texts/93/93683881cc31a47ca801beec2a258b2457d493111f4b5c99bb372dcfd9a65888.md) | 字幕/转录文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 48000)、[48000, 60000)、[60000, 71647) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/07-performance-scheduling/05-ai-budget-lod.md](../../ai-reference/13-youtube-2011-2026/07-performance-scheduling/05-ai-budget-lod.md)
- [https://tomlooman.com/unreal-engine-optimization-talk/](https://tomlooman.com/unreal-engine-optimization-talk/)
- [https://tomlooman.com/unrealengine-optimization-talk/](https://tomlooman.com/unrealengine-optimization-talk/)
- [https://www.jetbrains.com/guide/gamedev/links/unreal-engine-game-optimization-on-a-budget/](https://www.jetbrains.com/guide/gamedev/links/unreal-engine-game-optimization-on-a-budget/)
- [https://www.youtube.com/watch?v=G51QWcitCII](https://www.youtube.com/watch?v=G51QWcitCII)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
