# Unreal Engine NPC AI - Alert Nearby Enemies (ALS #27)

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`youtube:madzqBGs7nw`。
- 已有内容：字幕/转录文本。
- 原目录作者：Thilina Premasiri / CodeLikeMe。
- 原目录日期：2022-02-09（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=madzqBGs7nw](https://www.youtube.com/watch?v=madzqBGs7nw)

## 概要与项目参考

Domino建议：明确观察者→报告事件→局部接收者知识→各自决定调查/援助的因果链，稀疏局部传播，不把别人报告升级为本人看见。

## 已有机制分析

原教程：看到对手的NPC在开始射击前以announce location发声，2000单位半径/强度1噪声携目标位置；BT任务通过目标blackboard key调用后finish execute success。
原教程：事件类型从脚步级0调成主要威胁1提高反应；漏传目标导致无通知，转向节点卡住后改focus service与wait，讲者演示约13分钟末恢复移动。

## 后续行为与玩法启发

喊话、警报、举报、求援可使犯罪被附近人获知，玩家遮挡/诱骗/封锁渠道能改变传播。

被转述位置不应自动产生确证身份或精准持续跟踪；接收者仍可核实或搜索。

玩家潜行可阻断通信、制造假警报或隔离目击者；接收者应保存来源/时间/置信度而不是立即全知锁定敌人。

## 适用范围与局限

只示范少量敌人，无万人数据；2000为Unreal场景单位，不能搬成Domino现实距离。

需要局部空间接收者索引与去重/冷却，防多NPC互相再广播形成事件风暴；本教程未说明。

示例仅少量敌人，2000单位听觉半径未说明索引/传播成本；万人需空间候选、事件合并/TTL与限制级联，避免全体广播。

观察事件、传播动作和BT执行任务可分模块；成功投递/收到/接受/行动结果应有不同状态。

卡住修复是作者一次演示，不得当通用UE节点根因或执行恢复合同。

警报行为可作为独立类型ops，任务成功只说明完成发出通知；告知数据和响应策略分开便于扩展。

宣布直接让所有附近角色知道玩家精准位置有全知风险，作者自己承认不自然并建议语音/动画表达，但当前没有素材。

Alert Others task立刻success只表调用结束，不能证明接收者听到、响应或到场。

同伙挡住射线并死亡的问题未在本片解决。

讲者4:13承认无可见传达时所有NPC得到精准位置可能不自然；同伴射进火线死伤和转向卡住均暴露未解决问题。

finished execute success不证明战斗/寻人成功；直接复制目标位置可能绕过遮挡/观测与欺骗空间。

来源map同载体还关联w7zs7-oI2_I/EQS Sharing Results；本正文只证明madzqBGs7nw的Alert教程，未借用第二作品机制。

完整阅读字幕，不是观看Blueprint接线或检验运行。

自动字幕误识明显，如anime/敌人、C++；关键参数为口述。

完整本地自动字幕0:00–13:39，未观看演示/Blueprint或下载源码；字幕不能证明完整视频时长。

path映射另列EQS Sharing Results w7zs7-oI2_I，实际导出头与正文只有madzqBGs7nw，已排除错误附加身份。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [transcript.txt](../texts/55/557ce94ff629c80847491595a109870c7b0ffcd700ef85188baf8d8df554d2b9.md) | 字幕/转录文本 | [0, 6939) |
| [browser-export.txt](../texts/9b/9b8e9f9c6f81b21a7c9b46b8a427d8096ebfef79345be77d8872e7928cef176f.md) | 字幕/转录文本 | [0, 7018) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/03-world-navigation/03-beliefs-information.md](../../ai-reference/13-youtube-2011-2026/03-world-navigation/03-beliefs-information.md)
- [https://www.patreon.com/posts/unreal-engine-ai-62366571](https://www.patreon.com/posts/unreal-engine-ai-62366571)
- [https://www.reddit.com/r/u_codelikeme/comments/soz7ok/](https://www.reddit.com/r/u_codelikeme/comments/soz7ok/)
- [https://www.reddit.com/r/u_codelikeme/comments/t8hdyn/](https://www.reddit.com/r/u_codelikeme/comments/t8hdyn/)
- [https://www.youtube.com/watch?v=madzqBGs7nw](https://www.youtube.com/watch?v=madzqBGs7nw)
- [https://www.youtube.com/watch?v=vRTpX9dE89c](https://www.youtube.com/watch?v=vRTpX9dE89c)
- [https://www.youtube.com/watch?v=w7zs7-oI2_I](https://www.youtube.com/watch?v=w7zs7-oI2_I)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
