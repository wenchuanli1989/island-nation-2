# The 1.9.5 Scalability Update Is Now Available!

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`identity-limited-unit:1e1a4e8222c84123f3c3bedaf9d583982c6eb3274b38351300ceb7e8de3c290b`。
- 已有内容：正文/源码节选。
- 身份范围：已保存的限定资料单元；未确认与其他条目属于同一独立作品，保留分开记录。
- 原目录作者：The Polymorph Games Team。
- 原目录日期：2023-07-11（沿用已有记录）。
- 主要来源：[https://www.polymorph.games/foundation/news/2023/07/11/the-1-9-5-scalability-update-is-now-available/](https://www.polymorph.games/foundation/news/2023/07/11/the-1-9-5-scalability-update-is-now-available/)

## 概要与项目参考

旧搬运流程提前预留固定数量，途中库存变化却不调整，导致资源与搬运行为脱节。新版允许搬运者到达前随工作场所可用量调整数量。客舍可以暂停接收新客人以控制食物压力；事件被暂缓后额外延长再次出现间隔，任务和奖励随进度阶段变化。

## 已有机制分析

source_facts: 运输者预留数量会随库存波动不合适，更新允许途中动态调整；snooze给重复事件增加50–100%间隔；暂停Hospitium阻止新访客波次；任务要求/奖励按繁荣缩放。
domino_recommendations: 草案预期与到场实际转移分开，临取重检数量/容量；只通知受影响运输者，事件挂起和未来到期重算。

## 后续行为与玩法启发

domino_recommendations:
盗窃/走私共享真实货物/行程，占用、截货/报告/调查/处罚分离；访客暂停与来者拒绝/现有客人任务不同。

## 适用范围与局限

无万级测量；避免N×所有stockpile比较，索引仅活跃运输资源依赖；任务难度缩放与算力规模分开。

任务预测量/预留量/实际量分字段，暂停原因/恢复事件可解释。

运输动态数不说明确切库存提交/取消释放时点，不能照字面提前结算。

scalability是难度缩放，不是CPU吞吐；snooze在旧业务里用游戏日，本项目业务延迟须现实_ms。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [18c7e70161c55f5f12fc7980.txt](../texts/7b/7b14e4b09d32e3dc04aebbbbc7ec9081dcde62c4d9197699ddca78c9aa5c8c07.md) | 正文/源码节选 | [148551, 159440) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/09-game-case-studies/04-songs-of-syx-city.md](../../ai-reference/13-youtube-2011-2026/09-game-case-studies/04-songs-of-syx-city.md)
- [https://www.polymorph.games/foundation/news/2023/07/11/the-1-9-5-scalability-update-is-now-available/](https://www.polymorph.games/foundation/news/2023/07/11/the-1-9-5-scalability-update-is-now-available/)
- [https://www.polymorph.games/foundation/news/wp-json/wp/v2/posts?search=villagers&per_page=30](https://www.polymorph.games/foundation/news/wp-json/wp/v2/posts?search=villagers&per_page=30)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
