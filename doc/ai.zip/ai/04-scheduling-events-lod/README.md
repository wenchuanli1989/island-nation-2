# 调度、事件、时间与仿真细节分级

本类收录 111 条已有资料记录。当前前100中的条目优先列出，随后按题名排列。依据资料题名、来源主题与已有正文机制分析归类；跨领域资料在详情页保留关联链接。

[资料总目录](../README.md)

| 资料与概要 | 已有内容范围 | 当前前100 |
|---|---|---:|
| [Supporting Thousands of NPCs in Kingdom Come: Deliverance & Kingdom Come: Deliverance 2](work-7d1bc475ee3cc7d8bee1.md) | 摘要/简介、论文/讲义提取文本 | 2 |
| [Efficient, Event-Based Simulations — David “Rez” Graham](work-ab2e90b50736de492d8a.md) | 论文/讲义提取文本 | 9 |
| [SimPy events.py (f43816490c6f76f336ad6e457d3cab9f386894af)](work-9bf0deeba13ec17306f2.md) | 源码/工程文本 | 21 |
| [Apache Kafka, Purgatory, and Hierarchical Timing Wheels](work-62b08c2cb12b75280840.md) | 文章/文档正文 | 28 |
| [Phenomenal AI Level-of-Detail Control with the LOD Trader](work-304ad6bf845fe1f86a18.md) | 论文/讲义提取文本 | 41 |
| [DAS3H: Modeling Student Learning and Forgetting for Optimally Scheduling Distributed Practice of Skills](work-5100c0434e1457a2eed7.md) | 论文/讲义提取文本 | 88 |
| [2017 US LLVM Developers Meeting — program and talk abstracts (includes XRay in LLVM abstract)](work-9f0900881cd5a234aff2.md) | 已有摘要/简介文本 |  |
| [A Primer on Repeatable Random Numbers](work-3ec14504a65d8b20a82f.md) | 讨论正文/已载入评论 |  |
| [A Primer on Repeatable Random Numbers](work-d11664af403e9cd80ff0.md) | 文章/文档正文 |  |
| [A better unrestricted work schedule — explanation and replies](work-8eaac6d3f8041086cdb2.md) | 正文/源码节选 |  |
| [About windows defender warnings](work-4368a61a856c3e734e4c.md) | 文章/文档正文 |  |
| [Advanced AI for Games: Influence Maps](work-ddce7c9cc21eb8734f57.md) | 文章/文档正文 |  |
| [Advanced System Profiling, Tracing and Trace Analysis with Perfetto in Android and Yocto](work-a16a078d469b6ae935d4.md) | 论文/讲义提取文本 |  |
| [Agent based computational project organization and process model (CPOP), Systems Engineering — Theory & Practice 33(5), 2013, 1225–1230](work-5587f247193d756b5227.md) | 论文/讲义提取文本 |  |
| [Arcanum doing well with not bringing up stuff they shouldn’t know](work-1c47d75e4e72e4640bb0.md) | 讨论正文/已载入评论 |  |
| [BehaviorTree.CPP commit ba1d475f46d768fa0acd16639c9025ecf263ac4d: TimeoutNode/DelayNode halt and timer reset](work-cfa43dd3bc7f52ca10e7.md) | 源码/工程文本 |  |
| [BehaviorTree.CPP issue #624 — After the timeoutnode is halted, the timer is not reset](work-3d047ee2445c1fc1515e.md) | 讨论正文/已载入评论 |  |
| [Boost.Asio basic_waitable_timer::cancel](work-b08981470e601994c874.md) | 文章/文档正文 |  |
| [C++ Concurrent Queues — P0260R1 (2017-02-05)](work-433d7ebea09454beffcb.md) | 文章/文档正文 |  |
| [DAS3H: Modeling Student Learning and Forgetting for Optimally Scheduling Distributed Practice of Skills](work-843afe8c7ffc2b23e470.md) | 论文/讲义提取文本 |  |
| [Data Driven Entity Component System in C++17](work-273c6460b2d9a72de436.md) | 字幕/转录文本 |  |
| [Deprecate all schedulers and be free to do whatever you want](work-26823c7e25ca42199a37.md) | 讨论正文/已载入评论 |  |
| [Dev Diary #157 - Schemes & Stories](work-a20b015b1da9ff9940e7.md) | 文章/文档正文 |  |
| [Devlog 1 - My Dream Game, NPCs, and game logic around schedules and locations](work-b33180b97b572b69abef.md) | 文章/文档正文 |  |
| [Discrete-event simulation in Python — Rémi Varloot, LINCS, 7 March 2025](work-d57aa19e66dd4dab9382.md) | 论文/讲义提取文本 |  |
| [Discrete-event simulation with SimPy](work-937c7dc41c668e66287d.md) | 论文/讲义提取文本 |  |
| [Doctoring should override all schedule by default](work-539981f40fe88d772739.md) | 讨论正文/已载入评论 |  |
| [Dynamic Level of Detail for Large Scale Agent-Based Urban Simulations (AAMAS 2011)](work-17d17d398d13b3412cef.md) | 论文/讲义提取文本 |  |
| [Fast, High-Quality Pseudo-Random Numbers for Non-Cryptographers in C++](work-cbb0b123f1626e2b46fb.md) | 论文/讲义提取文本 |  |
| [Faster Scheduling (Matthew Rocklin, Dask working notes,2020)](work-aed99c491f962088e803.md) | 文章/文档正文 |  |
| [Faster Scheduling — Matthew Rocklin (2020-07-21)](work-f732216643d35de6630a.md) | 文章/文档正文 |  |
| [Faster Scheduling — Matthew Rocklin (Dask/Coiled), 2020-07-21](work-7dd1ff04b0b40e60ecff.md) | 文章/文档正文 |  |
| [Fix incorrect pendingTimeouts in HashedWheelTimer — Netty PR #14960](work-e7d406147c56718797ae.md) | 讨论正文/已载入评论 |  |
| [Friday Facts #425 - Behind the legs](work-17c6703a7a0e55ab752c.md) | 文章/文档正文 |  |
| [GAMA Developing Extensions — Version 2025-06](work-4ba6b800dcd1abf97575.md) | 文章/文档正文 |  |
| [Game Programming: Time Slicing — Allen Chou](work-ed0af1446269754cefda.md) | 文章/文档正文 |  |
| [Go issue #37196: Timer/Ticker channels and stale values after Stop or Reset](work-388efb4a6e8165b7a025.md) | 讨论正文/已载入评论 |  |
| [HashedWheelTimer.stop() must cancel tasks.](work-cc7e6fa79f64ac6928fa.md) | 讨论正文/已载入评论 |  |
| [How AI is Actually Used in the Video Games Industry \| AI 101](work-f130fd6b0b1fe658aa44.md) | 字幕/转录文本 |  |
| [How I Made NPCs Feel Alive with Real-Time Schedules Across Multiple Scenes in Unity](work-d8d38c328eb290d7e68e.md) | 字幕/转录文本 |  |
| [How Megalodon, Kraken and Skeleton Ships Haunt the Sea of Thieves \| AI and Games #42](work-39576464b9d24466af7d.md) | 字幕/转录文本 |  |
| [How Watch Dogs: Legion's 'Play as Anyone' Simulation Works \| AI and Games Documentary](work-e0b52cc11c5d4964fa22.md) | 字幕/转录文本 |  |
| [How to set shipments scheduling](work-16b1eebaeb50529be0aa.md) | 字幕/转录文本 |  |
| [How to track NPC routines at city scale (Reddit zh11e7, archived public body/comments)](work-04def9947543a7b4dc2f.md) | 正文/源码节选 |  |
| [ICAPS 2019 Tutorials](work-f1d58448228a0c06c5d4.md) | 已有摘要/简介文本 |  |
| [Introducing Eventure: A Powerful Event-Driven Framework for Python](work-5823d069113b3791d2f0.md) | 讨论正文/已载入评论 |  |
| [Introduction to Discrete-Event Simulation Using SimPy — Chun-Chieh Huang, PyConTW 2012](work-f76b263c543f935f7d99.md) | 论文/讲义提取文本 |  |
| [Is controlling gameplay logic with animation events a poor design?](work-786d3cac265d6a8019f2.md) | 讨论正文/已载入评论 |  |
| [Linux timers patch V2 15/17: Provide timer_shutdown\[_sync\]()](work-226b6a83f4c605c370e5.md) | 源码/工程文本 |  |
| [MATSim commit: ThreadScheduling renamed TaskScheduling with eager/backoff configuration](work-bbff44bafd02fad607ed.md) | 源码/工程文本 |  |
| [Making the Tokio scheduler 10x faster](work-e6aaaf2005d527fe6446.md) | 文章/文档正文 |  |
| [Math for Game Programmers: Dark Secrets of the RNG](work-3df1d624753147badcc6.md) | 论文/讲义提取文本 |  |
| [Mitigating ecological tipping points via game-environment feedback](work-7809450dc0d547a4d397.md) | 论文/讲义提取文本 |  |
| [Multi-Actor Behavior Sequencing in The Sims 4](work-379fd9ab93c40c8313c0.md) | 论文/讲义提取文本 |  |
| [NPCs completing different actions based on a schedule — r/godot](work-ec1fc6afe94eddd84b28.md) | 讨论正文/已载入评论 |  |
| [NetLogo Dynamic Scheduler Extension — Colin Sheppard](work-84b198bde42aad9cc3b4.md) | 文章/文档正文 |  |
| [New Timer implementation](work-233c301350227db30cf6.md) | 文章/文档正文 |  |
| [New Timer implementation (Tokio 2018 Chinese translation)](work-b74003832e7152a12f1b.md) | 文章/文档正文 |  |
| [Optimization Coming in 1.0! — belts and pipes segment](work-ecb44d9ac674b4e8c61b.md) | 字幕/转录片段 |  |
| [PARIS: A Polynomial-Time, Risk-Sensitive Scheduling Algorithm for Probabilistic Simple Temporal Networks with Uncertainty](work-49f0059b7321aaa18fce.md) | 论文/讲义提取文本 |  |
| [PARIS: A Polynomial-Time, Risk-Sensitive Scheduling Algorithm for Probabilistic Simple Temporal Networks with Uncertainty](work-adf5f5c5b86d4cc116ed.md) | 论文/讲义提取文本 |  |
| [Proposal: Unified Time and Event Scheduling API](work-063130f20a2960fcb6a3.md) | 讨论正文/已载入评论 |  |
| [Queueing and Python: pip install ciw（PyCon UK 2016 slides文字层）](work-d783ef477a51fabe468c.md) | 论文/讲义提取文本 |  |
| [Repast HPC Schedule.cpp at a96c15f99589d15352523a0a710362af8997852a](work-d4b2dee3720b45e927e3.md) | 源码/工程文本 |  |
| [RimWorld Alpha 16 – Wanderlust released!](work-68ff3722d2834fcb28da.md) | 讨论正文/已载入评论 |  |
| [Schedules and priorities](work-52b1214ced61acf00a68.md) | 正文/源码节选 |  |
| [SimPy](work-21607efc477134bee2d2.md) | 源码/工程文本 |  |
| [SimPy RealtimeEnvironment, src/simpy/rt.py (f43816490c6f76f336ad6e457d3cab9f386894af)](work-4ec9046526b15a2112a2.md) | 源码/工程文本 |  |
| [SimPy commit f43816490c6f76f336ad6e457d3cab9f386894af: CHANGES.rst 4.1.2](work-e3fb5c85c7bb19df687c.md) | 文章/文档正文 |  |
| [SimPy core.py](work-b7c8fdccc8681e919248.md) | 源码/工程文本 |  |
| [SimPy core.py fixed revision f43816490c6f76f336ad6e457d3cab9f386894af](work-093574ed98ba631c5776.md) | 源码/工程文本 |  |
| [SimPy resources/resource.py (f43816490c6f76f336ad6e457d3cab9f386894af)](work-5150dd2d1ed1f30e070b.md) | 源码/工程文本 |  |
| [SimPy resources/resource.py at f43816490c6f76f336ad6e457d3cab9f386894af](work-62aee7a295f994063b9d.md) | 源码/工程文本 |  |
| [SimPy src/simpy/resources/base.py (f43816490c6f76f336ad6e457d3cab9f386894af)](work-e6262732162a02cde630.md) | 源码/工程文本 |  |
| [SimPy src/simpy/resources/base.py at f43816490c6f76f336ad6e457d3cab9f386894af](work-cb01cbca6ae3e32e55f4.md) | 源码/工程文本 |  |
| [SimPy src/simpy/rt.py — RealtimeEnvironment](work-22f047ab5e6c49f90e24.md) | 源码/工程文本 |  |
| [SimPy — Discrete event simulation for Python (overview)](work-65633fcbff1909aa0a20.md) | 文章/文档正文 |  |
| [SimPy: Time and Scheduling](work-2b57611c7e1eb21c5b8e.md) | 文章/文档正文 |  |
| [Simulation of Demand Responsive Transport using a dynamic scheduling tool with SUMO](work-a8640489934766ee9aec.md) | 论文/讲义提取文本 |  |
| [Simulation of Demand Responsive Transport using a dynamic scheduling tool with SUMO](work-b867be7e40f0817fa694.md) | 关联链接；现有文本不可用或只有目录 |  |
| [Songs of Syx in 2026](work-ec75abe69a9c12ea193c.md) | 文章/文档正文 |  |
| [System scheduling](work-1acc7db5f2ae7eea12c8.md) | 讨论正文/已载入评论 |  |
| [The 1.9.5 Scalability Update Is Now Available!](work-6448eb05b95eabebd73c.md) | 正文/源码节选 |  |
| [Tick Optimization Toolkit](work-a2c75225f18cf8d7742c.md) | 讨论正文/已载入评论 |  |
| [Tick Optimization Toolkit — Description and Documentation（实际插件文档）](work-617f594821b6c39d5893.md) | 文章/文档正文 |  |
| [Time in Agent-based models](work-1f8d01419f229db79d26.md) | 字幕/转录文本 |  |
| [Time in Agent-based models](work-43ab79a141d1cd473646.md) | 字幕/转录文本 |  |
| [USENIX ATC 2017: Visualizing Performance with Flame Graphs — Brendan Gregg](work-8c62be8bda9c96ca6358.md) | 论文/讲义提取文本 |  |
| [USENIX LISA 2012: Performance Analysis Methodology](work-eb3b537c465dc789c41f.md) | 论文/讲义提取文本 |  |
| [Unreal Engine Game Optimization on a Budget](work-ba15a969e4be95bf2ddf.md) | 文章/文档正文 |  |
| [Unreal Engine Game Optimization on a Budget](work-f91bceb5180e1ae24a03.md) | 字幕/转录文本 |  |
| [Unreal Engine NPC AI - Alert Nearby Enemies (ALS #27)](work-8fe825ea8594ae5a16dd.md) | 字幕/转录文本 |  |
| [Using Rust For Game Development — long-form draft of RustConf 2018 closing keynote](work-c8f0424316a61d9162a4.md) | 文章/文档正文 |  |
| [Version 0.8.3.1 released!](work-729d0d2f20cee94a22f9.md) | 文章/文档正文 |  |
| [What are the possible techniques to implement life simulation in a large world?](work-cdcb468a12250ec3d686.md) | 讨论正文/已载入评论 |  |
| [What do games do wrong or do right when optimizing for large numbers of NPCs?](work-4af73ac34963fa39142e.md) | 讨论正文/已载入评论 |  |
| [What makes NPC relations and interactions system good?](work-6edb085a5fe921e26032.md) | 讨论正文/已载入评论 |  |
| [Where’s Update 8? — Satisfactory significance excerpt](work-c768728a422c3fd121bb.md) | 字幕/转录片段 |  |
| [Why wont my programs schedule?](work-aad3d381676710adb52f.md) | 正文/源码节选 |  |
| [\[patch V2 15/17\] timers: Provide timer_shutdown\[_sync\]()](work-f6f8f0a31909714529cd.md) | 源码/工程文本 |  |
| [\[patch V2 15/17\] timers: Provide timer_shutdown\[_sync\]() — Thomas Gleixner, 2022-11-22](work-3c362126c66cf4adbcab.md) | 文章/文档正文 |  |
| [libuv Design overview (design.rst at b05973ed)](work-9b5d954b08e469b15c93.md) | 文章/文档正文 |  |
| [libuv src/unix/core.c at b05973ed36b2de7ca51a3dca9cfa9160b42fe34d](work-0906845445d447a16c82.md) | 源码/工程文本 |  |
| [r/gamedev 1wvvvi7 — late save/load in an NPC simulation (visible comments)](work-3b885e84e6d83fab63f3.md) | 讨论正文/已载入评论 |  |
| [simpy/__init__.py (archived version 3.0.11)](work-8fac0bb70f8e03d51545.md) | 源码/工程文本 |  |
| [static_cast compilation fails unless all combinations of states and events have react handlers defined](work-4a6d0199d819fcfb99b8.md) | 源码/工程文本 |  |
| [time: make Timer/Ticker channels not receivable with old values after Stop or Reset returns](work-aefb444804cb0624f2d3.md) | 文章/文档正文 |  |
| [time: make Timer/Ticker channels not receivable with old values after Stop or Reset returns](work-b579e958cf700ff91408.md) | 讨论正文/已载入评论 |  |
| [uv_timer_t — Timer handle](work-16aa5a4adf48945ff8f0.md) | 文章/文档正文 |  |
| [一个任务调度算法引起的性能问题](work-6c254dc13d7e88641b3b.md) | 讨论正文/已载入评论 |  |
| [时间轮计时器](work-8dc229b5af45a425f2a9.md) | 文章/文档正文 |  |

## 相关配套归档文本

这些源码、结构化讨论或论文提取文字已在原档案中判定为可用文本；未补写语义精读结论，也不计作上表的独立资料条目。

| 文本文件 | 来源与原件 | 相关研究概要 |
|---|---|---|
| [SimPy — f43816490c6f76f336ad6e457d3cab9f386894af](../texts/05/05c543ea84dbca18df4455c739d98e08d1e719e1a3aecea125a3eafcc8d8b306.md) | [来源](https://gitlab.com/api/v4/projects/team-simpy%2Fsimpy/repository/commits/f43816490c6f76f336ad6e457d3cab9f386894af) · [已保存原件](../../ai-reference/source-archive-2026-10-04/raw/4c160fcad8f41e4c90580995.json) | [SimPy](work-21607efc477134bee2d2.md) |
| [SimPy — LICENSE.rst](../texts/5f/5f09a7bdf08f239271b15df1cbe2ba7f62649f8b497988274626f48638b84802.md) | [来源](https://gitlab.com/team-simpy/simpy/-/raw/f43816490c6f76f336ad6e457d3cab9f386894af/LICENSE.rst) · [已保存原件](../../ai-reference/source-archive-2026-10-04/raw/94d875efbb8b12f99b683def.txt) | [SimPy](work-21607efc477134bee2d2.md) |

