# HashedWheelTimer.stop() must cancel tasks.

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://github.com/netty/netty/pull/14083`。
- 已有内容：讨论正文/已载入评论。
- 原目录作者：normanmaurer（Norman Maurer），Netty维护者；daschl参与评审。
- 原目录日期：2024-05-27（沿用已有记录）。
- 主要来源：[https://github.com/netty/netty/pull/14083](https://github.com/netty/netty/pull/14083)

## 概要与项目参考

Domino 建议：timer停止/取消后，残余通知与实例状态须一致，旧到期事件检查任务修订或已取消状态；保存恢复也不能复活旧通知。
Domino 建议：计时器已cancelled不自动证明NPC任务业务取消/效果回滚；拒绝、停止确认、释放占用、真实任务终结另由执行者处理。

## 已有机制分析

原讨论事实：Netty #14083 修复 HashedWheelTimer.stop() 契约，返回未处理任务之前必须把它们标为 cancelled，说明停止调度器和每个残余计时任务状态一致性都是关闭工作。
原讨论事实：PR说明加单元测试，归4.1.111.Final里程碑并在2024-05-27合并；载体未显示实质diff/测试断言，不能重建具体实现。

## 后续行为与玩法启发

支撑玩家中断交易/调查/合作后，不会因旧到期事件再次扣款或宣告成功；本PR无具体玩法实现。

## 适用范围与局限

残余计时对象的状态终结一般与残余数成正比，但这里没有停机成本、timer wheel复杂度或10000NPC实测。

stop契约明确到返回对象状态便于排查残余任务；#14083 与被修复#14081应归为同一问题/修复机制，不重复计来源。

仅停止worker却把未处理timer返回为未取消，会让调用者误以为可继续触发；删除内存也不是对外状态终结。

PR格式评论和“Add unit test”不说明取消/执行竞态已被全面验证，不能宣称其实现适合Domino。

完整读取PR会话归档 [0,4240)；页面有加载错误chrome但仍含有效作者修复说明，非空壳。

未读#14081主体、diff或测试源码；此短契约可并入对应原作审查，但不足独立前100。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [108c188937821ac7ff393c61.txt](../texts/c2/c2927adf79b63308a558a703741cc3e74cd67e39bd46c240c6c204268fc244d8.md) | 讨论正文/已载入评论 | [0, 4240) |

## 原研究概要与相关链接

- [12-community-2016-2026/07-performance-scheduling/05-event-heaps-wheels-cancellation.md](../../ai-reference/12-community-2016-2026/07-performance-scheduling/05-event-heaps-wheels-cancellation.md)
- [https://github.com/netty/netty/pull/14083](https://github.com/netty/netty/pull/14083)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
