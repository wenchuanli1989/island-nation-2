# USENIX ATC 2017: Visualizing Performance with Flame Graphs — Brendan Gregg

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://www.brendangregg.com/Slides/USENIX_ATC2017_flamegraphs/`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Brendan Gregg。
- 原目录日期：2017-08-16（沿用已有记录）。
- 主要来源：[https://brendangregg.com/Slides/USENIX_ATC2017_flamegraphs](https://brendangregg.com/Slides/USENIX_ATC2017_flamegraphs)

## 概要与项目参考

Useful performance-debugging method for the existing C23 worker/timer/queue design, especially tracing blocked execution; supplies no NPC decision or gameplay architecture.

## 已有机制分析

source_facts:
Timer sampling records stacks with deterministic low overhead and coarse accuracy; flame-graph widths represent sample presence, ancestry is vertical, and the x-axis is sorted population rather than time.

Complete stacks and native/JIT symbols must be resolved before interpretation; missing frame pointers, inlining, depth limits and symbol churn can obscure attribution.

Differential flame graphs compare profiles, while page-fault, context-switch, I/O, cache-miss and CPI event profiles expose distinct costs.

Off-CPU traces show blocked paths; off-wake and chain graphs join waker stacks to reach causal latency sources.

domino_recommendations:
When future runtime validation is authorized, distinguish hot planner/executor CPU from waits caused by queues, timers, locks or slow producers.

Use task counts/reasons and timelines with sampled stacks; a wide function is a cost location, not automatically a task correctness diagnosis.

Compare fixed representative NPC scenarios and report whole-workload wall time, tail wake latency and memory, not only normalized graph percentages.

## 后续行为与玩法启发

crime:
No direct crime mechanism; profiling could protect response latency during concentrated alarms or pursuit.

deception_investigation:
No belief or evidence mechanism.

cooperation_player_interaction:
No direct interaction; off-wake chains can help diagnose delayed group-task or player-event response.

## 适用范围与局限

Sampling misses brief rare spikes; event tracing can have high overhead at high packet/event rates.

10000 NPC capacity is not established. Off-CPU accumulated time may dominate across many idle threads without identifying a performance defect.

Population-sorted flame graphs do not preserve chronology; use timelines for synchronized wake storms.

Keep symbols and stack unwinding reliable in a profiling configuration, respecting actual tool/platform support.

Read historical flags/kernel versions as examples, not current installation requirements. Keep workload identifiers and comparable capture conditions.

Flame-chart time ordering cannot be inferred from flame-graph horizontal position.

Unknown or truncated stacks can falsely concentrate costs at leaves.

Off-CPU blocking stack often fails to show the producer/root cause.

A differential increase can reflect a different workload or fewer total samples rather than a regression.

Complete local page with 66-slide extracted keywords [0,19162) read. Graph images and linked video are not inspected.

Historical tool examples are not executed; no engine workload is profiled.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [48ae7db01d860111e36115d8.txt](../texts/a4/a4388bd3fa6765537f4cc1ced43b8b599c7836e4984ff3723e9a8b3a4faa4361.md) | 论文/讲义提取文本 | [0, 12000)、[12000, 19162) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/07-performance-scheduling/09-profiling-benchmarks.md](../../ai-reference/13-youtube-2011-2026/07-performance-scheduling/09-profiling-benchmarks.md)
- [https://brendangregg.com/Slides/USENIX_ATC2017_flamegraphs](https://brendangregg.com/Slides/USENIX_ATC2017_flamegraphs)
- [https://www.brendangregg.com/Slides/USENIX_ATC2017_flamegraphs/](https://www.brendangregg.com/Slides/USENIX_ATC2017_flamegraphs/)
- [https://www.usenix.org/conference/atc17/program/presentation/gregg-flame](https://www.usenix.org/conference/atc17/program/presentation/gregg-flame)
- [https://www.youtube.com/watch?v=D53T1Ejig1Q](https://www.youtube.com/watch?v=D53T1Ejig1Q)
- [https://www.youtube.com/watch?v=abLan0aXJkw](https://www.youtube.com/watch?v=abLan0aXJkw)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
