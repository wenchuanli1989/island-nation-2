# Game Programming: Time Slicing — Allen Chou

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://allenchou.net/2021/05/time-slicing/`。
- 已有内容：文章/文档正文。
- 原目录作者：Ming-Lun Allen Chou / 周明倫。
- 原目录日期：2021-05-27（沿用已有记录）。
- 主要来源：[https://allenchou.net/2021/05/time-slicing/](https://allenchou.net/2021/05/time-slicing/)

## 概要与项目参考

非常直接地提供人物全量忙扫可替换的有限批次进度、延后回收/发布和时间预算机制。
既适合只读候选计算也揭示10k数据项与10000完整NPC不是同一性能证据。

## 已有机制分析

source_fact: worker jobs执行raycast setup→raycast→gather，调用方延后Complete；用TimeSliceBaseIndex保存批进度，每片localIndex映射globalIndex，尾片截到NumCells，最后一片完成后换buffer并重置。
domino_recommendation: 把有限候选/感知/路径批次做成可恢复计算游标，固定输入与输出寿命和版本；队列唤醒后继续有限工作，完整结果完成才发布。
source_fact: 10% rays/片要10frames完整更新；双缓冲给一致front结果，只有保证无race才可单buffer逐段发布，提高响应但读者看到混合更新。
domino_recommendation: 陈旧观测与混合观测需明确语义；不能把部分结果当当前完整世界，更不能沿结果直接支付/犯罪/消费。
source_fact: 10k raycast例子无切片主线程0.073ms、各核合计1.87ms，10%片主线程0.044ms/各核合计0.21ms，延迟1变10frame；作者指出coroutine在main执行仍阻塞。
domino_recommendation: 预算核算每片CPU和整批成本及结果年龄，调度片数量界不等于墙钟尾延迟保证；需要回调/worker而非只给main循环yield名称。

## 后续行为与玩法启发

局部视线/危险/目击候选可分片计算，玩家潜入、诱饵、阻路后的观测延迟有可设计反馈。

真实盗窃/追捕/交易效果仍由单执行提交者按当前位置、资产和目标校验；感知过期可导致主观误判，但不能修改世界事实。

紧急玩家互动可提高相关人物预算，背景日常更新允许有限延迟，需避免长期饥饿。

## 适用范围与局限

切片减少每帧负载但总raycast量没有自动减少，10%数字是每片成本；同步到期万人仍需限制活跃集合与公平轮转。

小片调度/分配和Complete等待可占主导；每片alloc/dispose NativeArray不宜直接移到C高频工作。

长job在下一次Complete时仍可阻塞，队列积压和世界变化增加旧结果比例。

公共计算状态包含cursor/count、输入epoch、完成/取消确认和buffer ownership，业务状态另存实际progress_ms。

样例TimeSliceBaseIndex负sentinel/尾片及ReadOnly声明存在需重新检查的代码细节，本轮不执行；按机制写明确C合同。

负进度哨兵和runtimeJobHandle不能原样作存档，加载从业务事实重建。

不等最后gather结束就换/释放buffer产生race或use-after-free。

每片用不同EyePos会让完整地图来自不同时间，移动目标/道路改版时需要年龄和局部再验。

双缓冲本身不能处理写者冲突或读者回收生存期；单buffer也不是仅删swap就安全。

按帧数结算工资/需求会与Domino现实ms轴冲突；切片只是计算调度。

10800字符完整文章/代码/结尾读完，未观看嵌入视频、核看profiler截图或取得付费源码。

作者Unity raycast性能不是Domino万人性能；本文没有停止确认/存档协议，相关建议为本轮推论。

lookup将前篇Delayed Result Gathering链接混合关联，此文件全文主体是Time Slicing，不声称前篇也已核读。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [4b8867d0f89d85a57b371fda.txt](../texts/06/06fadd03d57b550ef05bb5573e7d8414a2a9247c1f3f277fccc9b69b85801a69.md) | 文章/文档正文 | [0, 10800) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/07-performance-scheduling/05-ai-budget-lod.md](../../ai-reference/13-youtube-2011-2026/07-performance-scheduling/05-ai-budget-lod.md)
- [https://allenchou.net/2021/05/delayed-result-gathering/](https://allenchou.net/2021/05/delayed-result-gathering/)
- [https://allenchou.net/2021/05/time-slicing](https://allenchou.net/2021/05/time-slicing)
- [https://allenchou.net/2021/05/time-slicing/](https://allenchou.net/2021/05/time-slicing/)
- [https://www.gamesinprogress.com/indie-game-developers/miziziziz/how-to-optimize-an-open-world-rpg-wrought-flesh-devlog-9](https://www.gamesinprogress.com/indie-game-developers/miziziziz/how-to-optimize-an-open-world-rpg-wrought-flesh-devlog-9)
- [https://www.youtube.com/watch?v=iGah8RemjE0](https://www.youtube.com/watch?v=iGah8RemjE0)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
