# Fast, High-Quality Pseudo-Random Numbers for Non-Cryptographers in C++

- 分类：调度、事件、时间与仿真细节分级。
- 资料标识：`saved-original-url:https://raw.githubusercontent.com/cppcon/cppcon2022/main/Presentations/Fast-High-Quality-Pseudo-Random-Numbers-CPPCon2022-Roth-Michaels.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Roth Michaels。
- 原目录日期：2023-01-04（沿用已有记录）。
- 主要来源：[https://raw.githubusercontent.com/CppCon/CppCon2022/main/Presentations/Fast-High-Quality-Pseudo-Random-Numbers-CPPCon2022-Roth-Michaels.pdf](https://raw.githubusercontent.com/CppCon/CppCon2022/main/Presentations/Fast-High-Quality-Pseudo-Random-Numbers-CPPCon2022-Roth-Michaels.pdf)

## 概要与项目参考

Domino建议：人物随机选择需要可保存的算法/种子/状态与稳定身份，使同一犯罪/协作问题可复现；源的种子分配与reload例子是提醒，不是Domino实现。
Domino建议：不要使用全局共享PRNG让线程调度改变人物序列；选择与效果提交分开，取消/重试不能偷偷多抽样改变实际后果。

## 已有机制分析

原文幻灯片：区分真随机、确定PRNG与低差异序列，展示rand()%6问题、生成器与分布的分工、显式种子日志和给定种子构造。
原文：SeedPod用原子递增NewSeed和CAS ClaimSeed避免载入已有实例种子后重复发放；列出Xoshiro经SplitMix64填状态、PCG和Random123 seed/counter选项。
原文：M1 Max音频情境微基准比较raw/均匀分布成本，并最终说微基准差别可能不影响实际插件，倾向便利种子与标准分布。

## 后续行为与玩法启发

Domino建议：同条件下的交易选择、目击、逃逸、调查误差可使用有界随机过程而非任意剧情；玩家复查因果应可追踪随机决策上下文。

原资料没有犯罪、证言、谣言或社交机制；随机数是这些规则的基础服务，不能独自产生玩法。

## 适用范围与局限

原基准0.963ns Xoshiro128+对3.49ns mt19937以及Dust分布组合成本仅特定M1/Xcode音频微基准，不能外推为万NPC吞吐。

Domino建议：万级短状态/共享算法避免大mt19937每人对象；先检查真实热路径与分布成本、批处理和缓存，勿以微基准代替全体性能。

统一C23小接口保存状态和单位范围，分别定义整数/实数/概率分布；显式算法版本与seed能便于复现。

需要稳定人物-ID映射，单原子seed分配仍按线程执行顺序分配；跨实现分布差异也会改变回放，源结尾提到采用同一分布实现获得可移植性。

单种子初始化mt19937不能覆盖整个状态空间，std随机分布实现差异以及按载入顺序分种子使结果漂移。

重复Fonts母版噪声大量存在，实际插件图表仅标题无数值，不能声称已核图形/听音质量或具体整体增益。

SeedPod没有完整持久化/动作进度方案；录seed不能解决已提交交易或已发生目击的恢复重复。

完整读取28155字符讲义提取文字；未看视频、听演示或核图像，部分母版噪声保留。

C++/音频案例非C23人物调度；本批次用途为补充基础工程提醒。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [bf9eefdd3bf8a2c4956a9dc9.txt](../texts/41/411b63850ebd73eea6f5d664233fc6f6b18b538efa4a0d3b7919e7a3064caeac.md) | 论文/讲义提取文本 | [0, 11500)、[11500, 23000)、[23000, 28155) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/08-concurrency-reliability/05-determinism-randomness-replay.md](../../ai-reference/13-youtube-2011-2026/08-concurrency-reliability/05-determinism-randomness-replay.md)
- [https://github.com/CppCon/CppCon2022](https://github.com/CppCon/CppCon2022)
- [https://raw.githubusercontent.com/CppCon/CppCon2022/main/Presentations/Fast-High-Quality-Pseudo-Random-Numbers-CPPCon2022-Roth-Michaels.pdf](https://raw.githubusercontent.com/CppCon/CppCon2022/main/Presentations/Fast-High-Quality-Pseudo-Random-Numbers-CPPCon2022-Roth-Michaels.pdf)
- [https://www.youtube.com/watch?v=I5UY3yb0128](https://www.youtube.com/watch?v=I5UY3yb0128)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
