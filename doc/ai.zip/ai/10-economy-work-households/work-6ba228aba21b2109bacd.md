# Unity tutorial Sims-style AI CommonAIBase.cs at a2d1ddd

- 分类：经济、工作、家庭与城市生活。
- 资料标识：`saved-repository-bundle:gamedeveducation/unitytutorial_simsstyleai@a2d1ddde1fa011b6edb585e2c1ff5906c4790246`。
- 已有内容：源码/工程文本。
- 主要来源：[https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/CommonAIBase.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/CommonAIBase.cs)

## 概要与项目参考

教程单文件让基础智能对象和个体/家庭上下文可读，包含具体生命周期缺口，整体深度不足优先入前100。

## 已有机制分析

source_facts: 个体黑板存 Fun/Energy 与 focus interaction，家庭黑板按 HouseholdID 共享 ObjectsInUse 列表。
设置 CurrentInteraction 时把物体加入家庭占用列表，清 null 时移除上次物体；Update 到 Navigation.IsAtDestination 后只调用一次 Perform 并传完成回调。
需求每帧按 trait-adjusted decay × Time.deltaTime 衰减并 clamp [0,1]；实际收益 UpdateIndividualStat 再按 trait impact 修正。
OnInteractionFinished 先 interaction.UnlockInteraction 再清当前 focus；trait 按列表顺序逐一变换值。
domino_recommendations: 可以复用需求衰减、收益修正与到达后执行的简单分层，改为累计现实 ms 懒更新。
家庭共享占用只是查询缓存；真实竞争需资源 owner/任务身份，取消和迟到回调应只释放原任务占用。
用有限类型 trait ops 与紧凑个人参数，不需 Unity UI、每人泛型大黑板。

## 后续行为与玩法启发

共享家电/工作台容量可触发等待、争夺、偷用与破坏；人物情绪和特质影响候选效用，实际占用仍要确认。

玩家打断或抢走交互物应保留真实已发生效果并释放相应占用，不能依赖迟来回调做全局清空。

风险/享受偏好与实际损失耐受、饥饿衰减分开，可让盗窃诱惑、紧张、合作选择不同；本源码没有犯罪事件实现。

排队服务、床位、机器操作或共同犯罪工具都有容量；玩家抢先占用后 NPC 执行开始须再核验。

合作、交易和受阻工作只结算已实际完成的阶段；对方拒绝或中止后释放占用。

玩家添加家具、阻断导航或共享家庭资源，可使不同偏好 NPC 选择不同。

合作或偷占物品需真正参与/所有权协议，当前家庭 GameObject 列表不支持犯罪、调查或交易资产结算。

设施容量与共享对象可支持工位、诊疗、撬锁/盗取占时、玩家阻断；持续有效进度与离散财富转移仍须不同提交接口。

源码没有协作同意、调查目击或违法许可，不能从容量锁推出社会授权。

相同食物或娱乐对不同人物有不同偏好和效果，玩家可利用人物习惯安排工作/社交；风险偏好可调犯罪意愿，但不能使缺钱、缺工具等物理约束消失。

## 适用范围与局限

文件是Unity每人物Update与UI例子，无10000NPC证明。共享列表Contains/Remove为线性扫描，不能让巨大household反复扫描；需求变化可按实际elapsed_ms及事件阈值计算，UI只服务可见检查器。

每次Apply O(TraitElement数)，没有万人测量；少量参数与预合并倍率适合扁平数组批处理。

所有traits/candidates重复遍历可能放大成本，Domino建议按stat/类型预合成并仅在特质变化时更新。

每对象每帧 Update 遍历 active performers，没有万人数据。Domino 可保留有界活跃前沿和到期事件，不能把所有 smart object 每帧轮询；Unity float deltaTime 也不是当前累计未冻结现实 ms 业务基准。

每帧多次黑板泛型查询、Traits foreach、List.Contains/Remove 与 UI Slider 更新；照搬10000角色成本高。

家庭占用列表按线性访问且无同步；稀疏家庭规模可小，但并发冲突仍需单写者提交。

每Unity对象Update扫CurrentPerformers，全体设施/角色每帧扫描仍昂贵；万人应事件到期/有界批次。

Dictionary/对象/callback开销及Time.deltaTime不适合直接照搬C现实_ms业务轴。

每次 Apply 线性扫描 Impacts；若对所有候选逐stat逐trait调用，成本随人数、候选和条目相乘。10000人应在参数变更时聚合倍率，不逐帧扫描 ScriptableObject。

源码没有10000人测量，参数读取速度和传感/候选成本均未提供。

将机会定义、占用所有者和执行状态分开；回调携带任务身份并消费时验证。文件中单线程Unity习惯不自动适合C23后台规划与数组存储。

单函数纯数值变换便于新增特质维度并解释各来源。

编辑器Range属性不是外部数据运行校验；原FormerlySerializedAs只说明Unity序列化命名，不应引入Domino历史兼容。

清理队列避免普通 foreach 直接删除，但回调可重入，需要实例世代和完成状态来防旧清理删除新实例。原文件没有存档/取消设计，不应把这个教程类当完整任务系统。

traits 有序组合可能非交换，配置次序应显式；热衰减系数可预汇总。

到达触发与完成回调分离便于扩展，但需公共退出/取消和实例 revision。

结构简单、预留与执行可见，借机制比引入smartobject框架成本低。

需要明确owner/version/超时，锁定后未启动可无限占槽；恢复不能调用Perform重置进度。

三个目标类型显式分离，增加stat和trait成本较小；静态C参数表可保留这条合同，无需Unity对象运行时。

编辑器 Range 不是运行时输入校验；倍率上限、组合策略、参数版本和效果单位需领域定义。

旧Perform回调晚到可清除新CurrentInteraction，局部文件未显示保护。

未复位StartedPerforming可能阻止后续动作；非null切换可能残留占用，但不能凭此文件宣布整教程必然失败。

共享ObjectsInUse列表不是完整事务预留、等待公平或恢复实现。

同stat多条配置倍率相乘可快速放大/压低，当前没有合并上限或归一化；默认1不证明平衡。

仅乘倍率不能生成上下文权限/信念/关系，也没有实体ID、时长和资源提交事实。

回调若重新调用 Perform 或修改字典，可能在枚举中重入；旧 cleanup 可能删除同 performer 新建立的实例。

即时 Perform 重复调用可能重复应用效果，因为预留条目和完成状态缺独立生命周期校验。

零 Duration 的校验不在本文件中；分数时长、取消与恢复的正确性不能补推。

容量检查通过不代表有路线、合法许可或对方同意。

CurrentInteraction 从非 null 换为另一个非 null 时只加新物体，不移旧占用，可能留下占用泄漏。

置 null 且 previousInteraction 为 null 时 previousInteraction.gameObject 可能空解引用。

旧回调无身份校验会清掉新的 CurrentInteraction。

StartedPerforming 未在本文件结束回调重置，下一交互能否开始依赖派生类。

重复Perform会把ElapsedTime重置0，未明确取消/恢复差异；_Duration=0持续模式比例可能无效。

完成回调可重入，若回调新Lock改变字典会破坏Update枚举；正常Unlock延迟移除不足以保证所有重入安全。

返回true但不匹配Instantaneous/OverTime分支时无效果；OnCompleted只是回调，不是世界效果验收。

重复匹配条目会多次乘，复合后可能超出标注范围；多个强化特质容易指数放大。

正负按当前值选择，无法表达阈值、情境、知识和长期承诺；只乘倍率不能产生新候选或中断当前任务。

评分变化和实际效果变化共用一个特质资产也容易被内容作者误配，须保持两者语义独立。

固定commit的完整4269 raw字符单源码文件；未执行，也未审父类/交互实现或完整仓库。

局部风险不是复现bug，不能把小Unity教程当万级方案。

完整读1605字符单文件源码，未读评分调用者、stats更新、其他教程文件或运行Unity。

可独立提取数值特质机制，但不足证明完整Sims式NPC架构；同教程其他资料按作品归并。

全文读完 3152 字符固定提交 C# 单文件，未读教程其余类或运行 Unity。

回调重入和重复效果为本文件边界上的静态推论，未运行复现。

不证明取消确认、任务保存恢复或万人性能。

完整读5229字符单文件，不等于完整教程仓库审计；派生AI和BaseInteraction可能承担缺失逻辑。

上述失败模式为本文件路径推理，未编译或运行。

Time.deltaTime 随 Unity 更新，不等于项目未冻结累计现实时钟。

SimpleInteraction.cs修复文字0–3883全文读；未读BaseInteraction/CommonAIBase/ApplyStatChanges或运行Unity。

无线程同步/跨存档/资源竞争测试，按源码可见控制流评，不宣称万人或取消正确。

完整单文件源码已读；调用方、stat定义、数值平衡、持久化和执行时机未核。

该文件提供参数化差异，未实现人物规划、犯罪后果或可恢复生命周期。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [799dddb07bffa540876b51a2.repaired.txt](../texts/02/02f8243f922a7e118a856254e806ef9e6a0df4240f0986efaeaf67d86af7c9a9.md) | 源码/工程文本 | [0, 2028) |
| [48fa1175b32188a4c1b00648.txt](../texts/10/10783112a123931accc49eb8c51712d5c87ded8d28e61458f5b20a35b0c550fa.md) | 源码/工程文本 | [0, 3152) |
| [e14ad42249a20b22272103d9.txt](../texts/76/765060fcaaeb352d07a7f234f8c1fda63319a3607a2bacbd6908e2e742667e0b.md) | 源码/工程文本 | [0, 4269) |
| [0e5dd88169ff432e3d364a18.repaired.txt](../texts/85/85f6e8bd6f31e0000f6272d237f95d303715cc6ff08d54bc83e2995ac381c4a2.md) | 源码/工程文本 | [0, 3883) |
| [c31e4cca33b7b6187c6efd1e.txt](../texts/aa/aac5e898a779111b6213ae283ee1aadff064ad09bf83a51429aae714e74ad3ab.md) | 源码/工程文本 | [0, 1605) |
| [38f485fd4a3566e43cf9a0ba.repaired.txt](../texts/c8/c8dca9047df40e5b88a2347ef3025be2c17f3db2c6bdbffa2e10f9ce15ced265.md) | 源码/工程文本 | [0, 5229) |

## 相关归档文本版本

以下是同一请求或来源已保存的修复/其他表示；转存不新增“全文精读”或独立作品的计数。

- [c31e4cca33b7b6187c6efd1e.repaired.txt](../texts/a8/a8b48f3d528b9d09d786e79d6d68c9c9c0945f01ceab9d56b3fd7674a051c570.md)
- [e14ad42249a20b22272103d9.repaired.txt](../texts/d2/d2c2c4fc021f6ae03d3b1e178cbafa39190cc16b15b95c95c2b14cf065b7bfbe.md)
- [48fa1175b32188a4c1b00648.repaired.txt](../texts/f2/f2d628598d1345404ce17c78a81f21e254b26714a5361439b1516f28885cb5da.md)

## 原研究概要与相关链接

- [https://github.com/GameDevEducation/UnityTutorial_SimsStyleAI/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/Traits/Scripts/Trait.cs](https://github.com/GameDevEducation/UnityTutorial_SimsStyleAI/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/Traits/Scripts/Trait.cs)
- [https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/CommonAIBase.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/CommonAIBase.cs)
- [https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/SimpleInteraction.cs](https://github.com/gamedeveducation/unitytutorial_simsstyleai/blob/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/SimpleInteraction.cs)
- [https://raw.githubusercontent.com/gamedeveducation/unitytutorial_simsstyleai/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/CommonAIBase.cs](https://raw.githubusercontent.com/gamedeveducation/unitytutorial_simsstyleai/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/CommonAIBase.cs)
- [https://raw.githubusercontent.com/gamedeveducation/unitytutorial_simsstyleai/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/SimpleInteraction.cs](https://raw.githubusercontent.com/gamedeveducation/unitytutorial_simsstyleai/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/SmartObjects/Scripts/SimpleInteraction.cs)
- [https://raw.githubusercontent.com/gamedeveducation/unitytutorial_simsstyleai/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/Traits/Scripts/Trait.cs](https://raw.githubusercontent.com/gamedeveducation/unitytutorial_simsstyleai/a2d1ddde1fa011b6edb585e2c1ff5906c4790246/Assets/Systems/Traits/Scripts/Trait.cs)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
