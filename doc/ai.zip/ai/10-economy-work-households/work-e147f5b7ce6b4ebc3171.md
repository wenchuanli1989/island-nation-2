# Is Inequality Inevitable?

- 分类：经济、工作、家庭与城市生活。
- 资料标识：`saved-original-url:https://www.scientificamerican.com/article/is-inequality-inevitable/`。
- 已有内容：文章/文档正文。
- 原目录作者：Bruce M. Boghosian。
- 原目录日期：2019-11-01（沿用已有记录）。
- 主要来源：[https://www.scientificamerican.com/article/is-inequality-inevitable/](https://www.scientificamerican.com/article/is-inequality-inevitable/)

## 概要与项目参考

Domino 建议：用该玩具模型理解反馈、随机路径和初期优势对长期财富分布的影响，作为经济参数压力实验，不替代具体生产、消费、工资、借贷及资源转移。
财富总量/交易双方守恒、债务界限、实际结算与分布统计应分开；模型随机exchange不能变成NPC计划期自动收益。
制度再分配、财富优势可作为独立领域规则，经统一执行者提交实际资产变化。

## 已有机制分析

源机制：yard-sale模型随机选两代理，以较贫者财富的一部分为交易风险；单次算术期望可能为正，但重复乘法路径的典型财富下降。小初始差异经重复交易可集中财富；作者援引模拟与数学证明。
源机制：每代理向均值迈chi比例的一步，等价富者净支付、贫者净接受的再分配，稳定纯模型；zeta按财富差/均值偏置交易赢率，zeta>chi时作者给出部分寡头财富份额1-chi/zeta。
源机制：仿射模型用S=kappa×平均财富的临时平移允许负净财富，交易后移回；三个参数通过既有财富分布的inverse problem拟合，而非由个体聪明/勤奋计算。

## 后续行为与玩法启发

税制、救济、继承、融资优势、赌场/风险交易可形成玩家可调整的长期反馈；玩家改变价格、合同和执法会影响真实交易与局部经济机会。

诈骗或非法夺取应作为独立可行的动作与实际损失来源，不能在贫富分布模型中凭随机coin直接制造犯罪/受害事实。

## 适用范围与局限

随机配对每次可O(1)，但原叙述每次交易后全员再分配直译为O(N×T)；10000人宜按现实时间批量结算真实制度支付，并明确均值/总量维护责任。

数百万/亿次1000人随机交易是模型实验，不是帧级决策或万人AI预算；稀疏实际交易不能为了匹配分布强加全体两两配对。

chi/zeta/kappa少量参数便于探索和可视化，但实际行为效果、税费流向及债务清偿需单独业务定义。

保留参数来源、种子与拟合/预测区别；不用分布拟合精度替代机制校验。

算术平均盈利与多数路径损失并不矛盾，错误把期望工资/风险收益当每人可实现结果会失真。

文章明确纯yard-sale无法解释实测分布；其自由市场宏大结论来自简化假设，不能当所有经济制度的已证因果。

加税不等于自动再分配：政府收入、支出和人到人转移不能混同。

同时需要生产、商品效用、退出/选择、空间与技能时，单一随机财富交换不足以表达玩家因果。

全文21912字符含正文及订阅壳，未读取数学证明论文、数据或图表图像。

1–2%与小于1/6%等精度为作者拟合主张，本轮未重算，也不是预测验证。

与个体需求规划、资源执行、犯罪认知链没有直接实现接口。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [1f36952d94a2dc0578174834.txt](../texts/f2/f24356e29093aadca9833f82362d2c721737d3cb657f3d7b22529e0a5537ff26.md) | 文章/文档正文 | [0, 21912) |

## 原研究概要与相关链接

- [06-economy-population/05-wealth-inequality.md](../../ai-reference/06-economy-population/05-wealth-inequality.md)
- [13-youtube-2011-2026/06-economy-population/05-wealth-inequality.md](../../ai-reference/13-youtube-2011-2026/06-economy-population/05-wealth-inequality.md)
- [https://doi.org/10.1038/scientificamerican1119-70](https://doi.org/10.1038/scientificamerican1119-70)
- [https://scientificamerican.com/article/is-inequality-inevitable](https://scientificamerican.com/article/is-inequality-inevitable)
- [https://www.scientificamerican.com/article/is-inequality-inevitable/](https://www.scientificamerican.com/article/is-inequality-inevitable/)
- [https://www.youtube.com/watch?v=Us_BI3mZXEg](https://www.youtube.com/watch?v=Us_BI3mZXEg)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
