# MicroWELT – Microsimulation of Disaggregated National Transfer Accounts for the Comparative Study of Welfare State Regimes

- 分类：经济、工作、家庭与城市生活。
- 资料标识：`youtube:yF0WL7ctWmk`。
- 已有内容：字幕/转录文本。
- 原目录作者：Martin Spielauer。
- 原目录日期：2021-05-18（沿用已有记录）。
- 主要来源：[https://www.youtube.com/watch?v=yF0WL7ctWmk](https://www.youtube.com/watch?v=yF0WL7ctWmk)

## 概要与项目参考

Domino人口经济可借鉴模块间保留个人关联与历史，不能把年龄分组平均值当每个人的真实消费/工资；政策效果应追到实际人物、企业和家庭。
continuous-time事件与家庭稀疏连接符合项目到期/外部事件唤醒方向；但字幕只述架构，不提供竞争风险调度细节或取消/恢复协议。
用于将来制度或经济平衡离线分析的what-if场景，比直接作为NPC行为执行器更合适。

## 已有机制分析

MicroWELT将年龄/性别之外的教育、家庭状态与个体生命历程接入NTA公共/私人转移核算；用教育和家庭构成变化区分人口合成效应与个体行为变化，避免固定今日总体均值直接投影未来。
演讲明确是continuous-time competing-risk模型，事件可在任意时刻发生；人口交互由配偶、父母孩子及迁出等链接构成。alignment可在保留个体差异风险时校准总人口投影。
模型按人口、教育、代际教育传递、健康、劳动力/退休/工时与转移指标分模块；国家版本逐步扩展移民类别、再次迁出、健康约束和家庭/机构照护，并计划整合共用代码。
支持率按有效劳动收入与有效消费关系计算；full generational accounts统计生命历程私人和公共转移现值。健康支出例子同时考虑个体年龄教育成本及教育造成的寿命差异，因此较低年度成本不必然意味着较低一生总成本。

## 后续行为与玩法启发

政策税率、教育投入、护理服务、就业和退休年龄可通过个人处境影响家庭照护、职业机会和代际冲突；玩家可改变制度或提供服务。

犯罪和欺诈可在机会/家庭压力上生成动机，但讲座没有犯罪机制；不得把教育统计相关性硬编码成个体犯罪事实。

玩家改变教育服务、家庭照护或就业机会，可造成可解释的劳动力/健康/家庭支持变化；迁移流入与长期留存不同可形成城市治理与资源压力。

该材料未提供犯罪/欺骗/调查或玩家动作系统；福利欺诈、雇佣歧视等只能在项目独立事实与执行业务上加，不由统计转移曲线自动生成。

## 适用范围与局限

连续时间减少固定周期更新潜力，但字幕没有队列算法、并发策略、每事件成本或 10000 NPC 实时性能。

配偶搜索和家庭连接若全体匹配会 O(N²)；Domino 应局部候选与稀疏亲属索引。统计队列按月/年模拟不能直接等同现实毫秒互动。

无模型人物数、硬件、事件队列复杂度或实时吞吐，不能把跨国人口投影理解为10000 NPC实时模拟验证。

万人应用宜按事件与稀疏家庭链接增量更新，昂贵what-if投影另做离线研究；演讲本身没有证明此实现。

aggregate alignment和NTA参数是预测校准：Domino实际资产/工资/消费必须由执行提交并满足总账，不能强制总体曲线而补造微观历史。

透明参数与模块分离、数据推导脚本/场景记录有利于内容维护；不同国家/用途的扩展最终需重新整合，说明分叉模块会增加维护成本。

现实数据仅作规则校准候选；玩家控制世界需维护资产守恒、服务容量、参与者拒绝与保存的实际历史。

演讲强调开放文档、GUI参数、分析脚本、Modgen向openm++迁移与多国家共享模块；可借鉴领域模块边界与参数/结果可复现性，不建议C引擎因此迁入专用语言。

各版本健康、教育、移民增加相关参数；扩展要检验个人生命历程一致性，不只检查各模块总量相符。

总体对齐可以强制 aggregate outcomes，会压制开放世界真实因果；不可为符合人口目标而强行生成死亡、婚姻或转移记录。

讲座强调 aggregate cross-section 会误导，但 disaggregation 仍依赖健康高龄成本等假设和参数不确定性。

统计生命轨迹的低频模型不能证明街头追逐、欺骗或目击系统可运行。

教育扩张会增加收入也改变消费与在校时间，单看人口年龄结构或一项系数可能方向错误。

高教育较低年度健康成本被较长寿命抵消；不能简单用教育等级做真实个体医疗消费。

80岁以上成本数据不确定，演讲提供假设情景；非游戏行为机制，缺取消、资源冲突、存档与主观信息。

完整本地自动字幕 00:16–40:27 已读；图表、代码与项目网站没有本轮读取。

连续时间架构只由讲者口述，不含可复用调度实现；案例经济数值不作为 Domino 定量承诺。

适合作为制度/人口层补充，当前任务执行闭环与犯罪互动的直接帮助较弱。

37747字符自动英文字幕[0:16–40:27]完整读取；未观看视频/核图/读模型源或原论文，字幕将MicroWELT/Modgen等词多次识别错误。

可用性主要在经济人口分析，低于更直接解释人物决策/执行/强玩法因果的候选；不排除原论文或源码另有工程价值。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [transcript.txt](../texts/53/5313fa788106cdc13fad984e9f0bc7b10a13fba4181176bce81e273499baf3ce.md) | 字幕/转录文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 37668) |
| [browser-export.txt](../texts/94/940099f225eb3abb0ac233fb417ead49c0c15cb9d379b8792e65d3c9dc50a895.md) | 字幕/转录文本 | [0, 12000)、[12000, 24000)、[24000, 36000)、[36000, 37747) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/06-economy-population/06-population-lifecycle.md](../../ai-reference/13-youtube-2011-2026/06-economy-population/06-population-lifecycle.md)
- [https://www.oeaw.ac.at/fileadmin/subsites/Institute/VID/PDF/Colloquium/2021/Online_Colloquium_Announcement_Spielauer_20210518.pdf](https://www.oeaw.ac.at/fileadmin/subsites/Institute/VID/PDF/Colloquium/2021/Online_Colloquium_Announcement_Spielauer_20210518.pdf)
- [https://www.oeaw.ac.at/vid/events/wic-colloquium](https://www.oeaw.ac.at/vid/events/wic-colloquium)
- [https://www.youtube.com/watch?v=yF0WL7ctWmk](https://www.youtube.com/watch?v=yF0WL7ctWmk)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
