# Post-Keynesian Stock-Flow Consistent Modelling — Antoine Godin, 2015

- 分类：经济、工作、家庭与城市生活。
- 资料标识：`saved-original-url:https://www.boeckler.de/pdf/v_2015_10_22_godin.pdf`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Antoine Godin。
- 原目录日期：2015-11-06（沿用已有记录）。
- 主要来源：[https://www.boeckler.de/pdf/v_2015_10_22_godin.pdf](https://www.boeckler.de/pdf/v_2015_10_22_godin.pdf)

## 概要与项目参考

recommendation:
用执行者的成对实际资产变更维护支付、购买、工资、税与借贷约束；规划器只做预期收益和预算草案。为每种经济效果明确来源、去向和期初/期末边界，用少量守恒/平衡校验，不引入通用宏观方程求解器或数据库事务框架。

context_boundary:
经济时间推进应使用累计未冻结现实时间，存档保存余额/承诺/真实结算进度，冻结和离线不结算想象收入。货币发行和借贷若未来存在，需显式负债/发行主体，不能把所有现金总量永远固定当会计恒等式。

## 已有机制分析

source_fact: 资产/负债、每方流入/流出同时平衡，以期初余额、交易流、资金流三表连接，当前期末存量是下一期期初存量。用quadruple entry及全体系加总约束保证一致性。
source_fact: 会计恒等式与行为方程分开；行为闭合假设决定消费/投资，恒等式本身只约束资金去向，不能决定人物偏好。
source_fact: SIMEX让消费依据预期而非实际收入，现金buffer stock吸收预期误差；估计收入与实现收入分开。
source_fact: 冗余恒等式不纳入求解以免过度决定，但保留作校验；DAG中循环方程共同求解，讲义提供R包Gauss-Seidel数值实现线索。

## 后续行为与玩法启发

source_fact:
讲义分析部门与宏观政策，没有NPC、犯罪或玩家交互实现。

recommendation:
可支持偷窃、诈骗、洗钱、赊账、税收、违约、工资拖欠：真实资产转移依然落账，假报表/传言/机构审计另存主观信息。玩家可改变价格、贷款/税条款、阻断资金或追缴；裁决和实际付款分别执行。

## 适用范围与局限

author_evidence:
无万级人物或实时运行基准；模型多是聚合部门，SIM例无供给约束、无库存。

assessment:
局部转移可用有界操作与扁平余额数组；低频增量汇总部门账约O(发生的交易)。不应每NPC复制整套矩阵、全世界每帧迭代求解或者永久全量流水。

明确金额单位、符号和时间边界，区分存量、流量率、估值变化和真实转移。

同一效果统一提交成功/失败，拒绝或取消后释放预约，恢复不能重复结算；这些生命周期接口是Domino建议，讲义未实现。

会计恒等式可作不变量，行为规则仍需可解释原因和单独校准；无需为每活动新建复杂总账系统。

预算平衡不证明市场或决策模型正确，行为方程仍是理论假设。

SIM无供给/库存约束且供给等于需求；Domino生产物流必须检查真实地点、库存、产能与完成进度。

估值上涨不等于收到现金；预期工资不等于已支付。

偷窃/欺诈不能因违法而从物理候选剔除，也不能把欺诈报表当真实账。

全部本地提取文字35013字符已读，重复动画页也逐字显示；没有核看图表像素，也没有观看关联视频。

若干页面只有图题和坐标文字；期初转移/清算图没有完整视觉内容，因此不能声称所有图示机制已检验。

讲义是宏观金融模型教学，不提供Domino人物执行或保存源码。

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [1253803d46cd28b29816502c.txt](../texts/50/50b8a3575d22b24d1c8b696e13391f1bf7f3d225d54bf04a13c2422584c71dc6.md) | 论文/讲义提取文本 | [0, 35013) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/06-economy-population/04-budgets-money-conservation.md](../../ai-reference/13-youtube-2011-2026/06-economy-population/04-budgets-money-conservation.md)
- [http://www.boeckler.de/veranstaltung_imk_53337.htm](http://www.boeckler.de/veranstaltung_imk_53337.htm)
- [https://www.boeckler.de/pdf/v_2015_10_22_godin.pdf](https://www.boeckler.de/pdf/v_2015_10_22_godin.pdf)
- [https://www.youtube.com/watch?v=Iiczg7jswcQ](https://www.youtube.com/watch?v=Iiczg7jswcQ)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
