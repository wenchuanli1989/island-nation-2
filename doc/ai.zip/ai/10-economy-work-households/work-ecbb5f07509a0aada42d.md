# An agent-based model of social care provision during the early stages of Covid-19

- 分类：经济、工作、家庭与城市生活。
- 资料标识：`saved-original-url:https://pmc.ncbi.nlm.nih.gov/articles/PMC9528879/`。
- 已有内容：论文/讲义提取文本。
- 原目录作者：Umberto Gostoli; Eric Silverman。
- 原目录日期：2022-10-03（沿用已有记录）。
- 主要来源：[https://pmc.ncbi.nlm.nih.gov/articles/PMC9528879/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9528879/)

## 概要与项目参考

Strong example of scarce shared time, household links and cross-domain effects; provides family coordination and care/service economics absent from current human placeholder.

## 已有机制分析

source_facts:
Social/child care demand interacts with informal kin supply, paid care and public care. Care supply depends on status, kin distance, location, health and available time/income.

Allocation samples receiving units proportional to unmet need, then kin households proportional to supply; a two-hour unit consumes supply and meets need. Childcare is prioritized before adult social care. The lowest-wage worker compares forgone wage with paid-care price.

Infection state differs from knowledge of infection: tests affect awareness, prudent behavior and willingness to provide care. Actual care interactions are an additional exposure channel.

Income, occupation flexibility and perceived risk affect contact reduction; restrictions change both available care time and access to other households, producing coupled consequences.

domino_recommendations:
Use a shared care request with bounded kin candidates and proposed time/material offers; each person accepts and performs their own task, with actual progress consuming supply only once.

Represent health/world state, observations/tests and personal risk estimates separately; route restrictions and payer/provider refusals should invalidate only affected commitments.

## 后续行为与玩法启发

Players can fund paid care, offer transport, block routes or negotiate a provider, changing work/care opportunities and unmet need.

False claims of care completion or forged health evidence create fraud/investigation chains only if claim, observed interaction and actual delivered benefit are stored separately.

Competing family obligations can force refusal, renegotiation and lasting relationship changes instead of universally cooperative kin.

## 适用范围与局限

Sparse kin/social networks and capped degrees are suitable for local O(edges) work; population is scaled about 1:10000 of UK, which is not a 10000 fully simulated NPC performance proof.

Daily/global allocation and initial network construction can still be expensive; process only changed requests and cap allocation rounds rather than rescan everyone each frame.

Research daily/two-hour units must not override Domino's real-ms business timing or automatically create offscreen interactions.

Keep demand, supplier capacity, commitment and delivered progress separate, with ownership and cancellation release explicit.

Compose health, economics and care through structured events; avoid central executor branches for every policy or condition.

Provenance of claimed infection/need matters for future deception; engine truth should not be exposed as universal personal knowledge.

Allocation is an immediate probabilistic transfer; it omits travel/execution refusal and cannot be transplanted as task-success settlement.

Article results text conflicts about Policy1/Policy2 unmet-care direction, and sensitivity prose labels/magnitudes do not align with its table; avoid quoting precise comparative results without figures/supplement checks.

Simplifies care progression as nonrecovering, hospital supply as complete and epidemiology as pre-vaccine; purpose is proof-of-concept, not current medical advice or game-realism validation.

Full extracted article read; supplementary PDF, code and graph images not read.

Some formulas have flattened mathematical rendering; exact numerical/epidemiological results are not independently reproduced.

## 正文与已提取文本

| 保存文本 | 内容类型 | 本条资料关联的字符范围 |
|---|---|---|
| [ec4bfe75d98aac42385f5443.txt](../texts/02/023e8488829ad1b6c6e608949ce6248972eedbca97fff3f423aa33f50e9f2f3a.md) | 论文/讲义提取文本 | [0, 11500)、[11500, 23000)、[23000, 34500)、[34500, 46000)、[46000, 57500)、[57500, 58827) |

## 原研究概要与相关链接

- [13-youtube-2011-2026/05-organizations-institutions/01-family-care.md](../../ai-reference/13-youtube-2011-2026/05-organizations-institutions/01-family-care.md)
- [https://drericsilverman.com/publications/](https://drericsilverman.com/publications/)
- [https://eprints.gla.ac.uk/280086/](https://eprints.gla.ac.uk/280086/)
- [https://pmc.ncbi.nlm.nih.gov/articles/PMC9528879/](https://pmc.ncbi.nlm.nih.gov/articles/PMC9528879/)
- [https://www.nature.com/articles/s41598-022-20846-9](https://www.nature.com/articles/s41598-022-20846-9)

[返回本类目录](README.md) · [返回资料总目录](../README.md)
